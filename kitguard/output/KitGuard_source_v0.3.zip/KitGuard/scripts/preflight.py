"""Read-only demo readiness check; does not load a model or create orders."""

import argparse
import importlib.util
import json
import os
import platform
import sqlite3
import sys
from datetime import UTC, datetime
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

from kitguard import __version__
from kitguard.vision import LocalVision

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("Invalid local port")
    if args.output and args.output.exists():
        parser.error("Keep previous records; choose a new output file")
    checks = []

    def check(name, passed, detail):
        checks.append({"check": name, "passed": bool(passed), "detail": detail})

    check("python", (3, 11) <= sys.version_info[:2] < (3, 14), platform.python_version())
    dependencies = {name: importlib.util.find_spec(name) is not None for name in ("fastapi", "PIL", "mlx_vlm", "mlx")}
    check("dependencies_present", all(dependencies.values()), dependencies)
    model = LocalVision().status()
    check("model_files_present", model["available"], {
        k: model[k] for k in ("repo_id", "revision", "path", "observation_mode", "image_max_side")
    })
    assets = ["index.html", "app.js", "styles.css", "audit.js", "spatial.js", "camera.js", "demo.html", "demo.js", "demo.css"]
    missing = [name for name in assets if not (ROOT / "kitguard/static" / name).is_file()]
    check("workbench_assets", not missing, {"missing": missing})
    db_path = Path(os.environ.get("KITGUARD_DATA_DIR", ROOT / "data")).expanduser().resolve() / "kitguard.sqlite3"
    if db_path.is_file():
        try:
            with sqlite3.connect(db_path.as_uri() + "?mode=ro", uri=True, timeout=5) as db:
                integrity = db.execute("PRAGMA quick_check").fetchone()[0]
            check("local_database_integrity", integrity == "ok", integrity)
        except sqlite3.Error as exc:
            check("local_database_integrity", False, type(exc).__name__)
    else:
        check("local_database_integrity", True, "No configured database yet; normal before first launch")
    try:
        with urlopen(f"http://127.0.0.1:{args.port}/api/health", timeout=5) as response:
            health = json.load(response)
        check("running_application_version", health.get("version") == __version__, {
            "expected": __version__, "running": health.get("version"),
            "hint": "Restart the local service if it is still an older version",
        })
        check("running_model_available", health.get("model", {}).get("available") is True, {
            "available": health.get("model", {}).get("available"),
            "loaded": health.get("model", {}).get("loaded"),
            "mode": health.get("model", {}).get("observation_mode"),
        })
    except (URLError, OSError, ValueError) as exc:
        check("running_application", False, {"error": type(exc).__name__, "next": "bash scripts/run.sh"})
    result = {
        "checked_at": datetime.now(UTC).isoformat(), "version": __version__,
        "ready": all(c["passed"] for c in checks), "checks": checks,
        "scope": "Read-only files/import availability/database/HTTP readiness. No model inference, camera permission, full weight digest, accuracy, physical operation or competition eligibility is verified by this command.",
    }
    content = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(content)
    print(content)
    return 0 if result["ready"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
