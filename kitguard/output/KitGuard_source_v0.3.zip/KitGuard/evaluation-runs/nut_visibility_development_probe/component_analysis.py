"""Descriptive decomposition of the already-fixed exploratory rule; no new fit."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent
points = json.loads((root / "points.json").read_text())
rows = json.loads((root / "images.json").read_text())
parts = {}
for name, reason in [
    ("contrast_only", "dark_center_cue_not_supported"),
    ("bright_center_only", "bright_center_or_reflection"),
]:
    ids = {p["case_id"] for p in points if reason in p["review_reasons"]}
    wrong = [r for r in rows if not r["original_count_exact"]]
    correct = [r for r in rows if r["original_count_exact"]]
    parts[name] = {
        "request_review": len(ids),
        "points_request_review": sum(reason in p["review_reasons"] for p in points),
        "wrong_images_flagged": sum(r["case_id"] in ids for r in wrong),
        "wrong_images": len(wrong),
        "correct_images_flagged": sum(r["case_id"] in ids for r in correct),
        "correct_images": len(correct),
        "flagged_case_ids": sorted(ids),
        "uncovered_error_case_ids": [r["case_id"] for r in wrong if r["case_id"] not in ids],
    }
out = {
    "scope": "Post-run exploratory component analysis, not a new independent experiment or selected rule",
    "components": parts,
}
(root / "component_analysis.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps(parts, indent=2))
