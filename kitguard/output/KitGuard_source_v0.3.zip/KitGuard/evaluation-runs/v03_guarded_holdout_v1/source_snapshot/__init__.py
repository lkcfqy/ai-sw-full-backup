"""KitGuard local application."""

__version__ = "0.3.0"
