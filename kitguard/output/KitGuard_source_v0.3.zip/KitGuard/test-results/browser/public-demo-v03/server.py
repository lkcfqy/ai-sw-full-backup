"""Isolated public development-photo UI QA. No inference or production data access."""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from kitguard.app import create_app  # noqa: E402

HERE = Path(__file__).resolve().parent


class NoInference:
    def status(self):
        return {"available": False, "loaded": False,
                "label": "PUBLIC DEMO ENGINEERING QA — NO MODEL",
                "error": "No inference allowed in this isolated browser test"}

    def forbidden(self, method):
        with (HERE / "forbidden-inference.jsonl").open("a") as stream:
            stream.write(json.dumps({"unexpected_method": method}) + "\n")
        raise RuntimeError("No inference allowed in public demo engineering QA")

    def observe(self, *args, **kwargs):
        return self.forbidden("observe")

    def observe_with_context(self, *args, **kwargs):
        return self.forbidden("observe_with_context")

    def propose_revision(self, *args, **kwargs):
        return self.forbidden("propose_revision")


app = create_app(data_dir=HERE / "data", analyzer=NoInference(), demo_dataset_root=ROOT / "datasets")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8772)
