/* Real three public development images and real isolated API; never inference. */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { chromium } = require('/Users/lkc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const output = __dirname, url = 'http://127.0.0.1:8772';
const checks = [], errors = [], requests = [], explicitRequests = [], sources = [], orders = [];
const ok = (value, name) => { assert.ok(value, name); checks.push(name); };
async function api(route, body, expected = 200) {
  const response = await fetch(url + route, body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : undefined);
  const result = await response.json();
  explicitRequests.push({ route, status: response.status, method: body ? 'POST' : 'GET' });
  assert.equal(response.status, expected, JSON.stringify(result)); return result;
}
async function loadedGallery(page) {
  await page.goto(url + '/static/demo.html', { waitUntil: 'networkidle' });
  await page.waitForFunction(() => document.querySelectorAll('#samples article').length === 3 && Array.from(document.querySelectorAll('#samples img')).every(image => image.complete && image.naturalWidth > 0));
}
async function clickSample(page, index) {
  const responsePromise = page.waitForResponse(response => response.request().method() === 'POST' && response.url().includes('/api/public-demos/'));
  await page.locator('#samples article button').nth(index).click();
  const response = await responsePromise;
  assert.equal(response.status(), 201);
  await page.waitForURL(location => location.origin === url && !!location.searchParams.get('order'));
  const identifier = new URL(page.url()).searchParams.get('order');
  const loaded = await api('/api/orders/' + identifier);
  const created = { order: loaded.order, photo: loaded.order.photos.at(-1) };
  await page.waitForFunction(id => typeof state !== 'undefined' && state.initialized && state.order?.id === id, created.order.id);
  await page.locator('.photo-frame img').waitFor();
  await page.waitForFunction(() => document.querySelector('.photo-frame img')?.naturalWidth > 0);
  orders.push(created.order.id); return created;
}
(async () => {
  const browser = await chromium.launch({ headless: true, executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' });
  const context = await browser.newContext({ viewport: { width: 1440, height: 1050 } });
  const page = await context.newPage();
  page.on('pageerror', error => errors.push(String(error)));
  page.on('request', request => requests.push({ method: request.method(), url: request.url() }));
  try {
    ok((await api('/api/orders')).orders.length === 0, 'QA starts with independent empty database');
    const catalog = (await api('/api/public-demos')).samples;
    ok(catalog.length === 3 && catalog.every(sample => sample.available), 'real catalog contains three available public development samples');
    ok(catalog.map(sample => sample.sample_id).join(',') === 'bag-revision,small-part,mixed-screws', 'only the three declared development examples are accessed');
    for (const sample of catalog) {
      const response = await fetch(url + '/api/public-demos/' + sample.sample_id + '/photo');
      const bytes = Buffer.from(await response.arrayBuffer());
      const digest = crypto.createHash('sha256').update(bytes).digest('hex');
      ok(response.status === 200 && response.headers.get('content-type') === 'image/png' && digest === sample.source_sha256, sample.sample_id + ' serves the actual hash-verified PNG');
      sources.push({ sample_id: sample.sample_id, source_case_id: sample.source_case_id, source_url: sample.source_url, license: sample.license, derived_view: sample.derived_view, returned_png_sha256: digest });
    }
    await loadedGallery(page);
    ok(await page.locator('#samples article img').count() === 3, 'desktop renders all three real images');
    ok((await page.locator('footer').innerText()).includes('已使用的开发样例') && (await page.locator('footer').innerText()).includes('未拼贴或删除物体'), 'gallery explains development and derived crop provenance');
    ok((await page.locator('.notice').innerText()).includes('不能证明现场物料操作') && (await page.locator('.notice').innerText()).includes('模型可能给出错误'), 'gallery warns that public photos are not field evidence and model errors remain possible');
    for (let i = 0; i < catalog.length; i++) {
      const card = page.locator('#samples article').nth(i), source = card.locator('a');
      ok(await source.getAttribute('href') === catalog[i].source_url && (await source.getAttribute('rel')).includes('noopener') && (await card.innerText()).includes(catalog[i].license), catalog[i].sample_id + ' shows source link and license');
    }
    ok((await api('/api/orders')).orders.length === 0, 'gallery and previews create no orders');
    ok(requests.every(request => request.method === 'GET'), 'gallery and previews send no mutation or inference request');
    ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'desktop gallery has no horizontal overflow');
    await page.screenshot({ path: path.join(output, '01-desktop-gallery.png'), fullPage: true, animations: 'disabled' });
    const first = await clickSample(page, 0);
    ok(first.order.demo_source.sample_id === catalog[0].sample_id && first.order.photos.length === 1, 'first card creates its source photo and jumps to the created order');
    ok(first.order.checks.length === 0 && first.order.latest_check === null && first.order.completions.length === 0 && first.order.status === 'pending', 'creation stores no prediction or completion');
    ok(first.photo.source_sha256 === catalog[0].source_sha256 && first.photo.revision === 1 && first.order.demo_source.physical_completion_allowed === false, 'normalized photo retains source hash and demo restriction');
    ok((await page.locator('.notice-banner').first().innerText()).includes('공개 사진 데모'), 'Korean workspace shows public-photo demo banner');
    ok(await page.locator('[data-action="inspect"]').isDisabled(), 'NoInference adapter visibly disables model action');
    await page.locator('[data-action="language"][data-lang="zh"]').click();
    ok((await page.locator('.notice-banner').first().innerText()).includes('不能记录实物完工'), 'Chinese workspace states completion prohibition');
    ok(await page.locator('.notice-banner').first().locator('a').getAttribute('href') === catalog[0].source_url, 'workspace keeps source license link');
    await page.screenshot({ path: path.join(output, '02-desktop-created-order.png'), fullPage: true, animations: 'disabled' });
    const denied = await api(`/api/orders/${first.order.id}/complete`, { check_id: 'QA-no-real-check', expected_revision: 1, confirmed: true, idempotency_key: 'public-demo-browser-qa-001' }, 409);
    ok(denied.detail.includes('公开照片演示不能记录实物完工'), 'real server explicitly rejects physical completion because this is a demo');
    // This only renders a string against a transient test value, never writes or displays a fake model result.
    const guard = await page.evaluate(() => {
      const saved = state.order;
      try {
        state.order = structuredClone(saved);
        state.order.latest_check = { id: 'QA-transient-only', backend: 'mlx', valid: true, revision: state.order.revision, photo_id: state.order.photos.at(-1).id, decision: 'ready', issues: [], action: { kind: 'none', message: 'TEST' } };
        const html = renderAction(state.order); openComplete();
        return { completionButtonAbsent: !html.includes('data-action="complete"'), dialogClosed: !document.getElementById('complete-dialog').open };
      } finally { state.order = saved; }
    });
    ok(guard.completionButtonAbsent && guard.dialogClosed, 'transient rendering contract hides and blocks completion even for a ready-shaped demo check');
    await loadedGallery(page); const second = await clickSample(page, 1);
    ok(second.order.demo_source.sample_id === catalog[1].sample_id && second.photo.source_sha256 === catalog[1].source_sha256, 'second card opens correct small-part derived photo');
    await page.setViewportSize({ width: 390, height: 844 });
    await loadedGallery(page);
    ok(await page.locator('#samples img').count() === 3 && await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), '390px mobile gallery displays all images without horizontal overflow');
    ok(await page.locator('#samples article').evaluateAll(cards => cards.every(card => card.getBoundingClientRect().width <= innerWidth)), 'mobile cards fit viewport');
    await page.screenshot({ path: path.join(output, '03-mobile-gallery.png'), fullPage: true, animations: 'disabled' });
    const third = await clickSample(page, 2);
    ok(third.order.demo_source.sample_id === catalog[2].sample_id && third.photo.source_sha256 === catalog[2].source_sha256, 'mobile third card creates and opens correct mixed-screws order');
    ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'mobile created workspace has no horizontal overflow');
    ok(await page.locator('[data-action="complete"]').count() === 0, 'mobile demo offers no physical-completion control');
    await page.screenshot({ path: path.join(output, '04-mobile-created-order.png'), fullPage: true, animations: 'disabled' });
    // The requested first order is now older than two others: this checks URL selection, not newest fallback.
    await page.goto(url + '/?order=' + first.order.id, { waitUntil: 'networkidle' });
    ok(await page.evaluate(() => state.order.id) === first.order.id, 'URL order parameter selects older requested demo instead of newest order');
    const revised = await api(`/api/orders/${first.order.id}/revise`, { expected_revision: 1, requirements: { bolt: 2, nut: 2, washer: 2, bracket: 0 }, instruction: 'ENGINEERING QA structured revision; no model' });
    await page.reload({ waitUntil: 'networkidle' });
    ok(revised.order.demo_source.source_sha256 === catalog[0].source_sha256 && (await page.locator('.notice-banner').first().innerText()).includes('公开照片演示'), 'revision preserves source provenance and demo banner');
    await api(`/api/orders/${first.order.id}/complete`, { check_id: 'QA-no-real-check', expected_revision: 2, confirmed: true, idempotency_key: 'public-demo-browser-qa-002' }, 409);
    ok(true, 'revision cannot bypass server demo completion guard');
    // Controlled network failure validates recovery only; no fabricated catalog or recognition.
    await loadedGallery(page);
    await page.route('**/api/public-demos/bag-revision/orders', route => route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ detail: 'ENGINEERING QA temporary creation failure' }) }));
    await page.locator('#samples article button').first().click();
    await page.locator('#status.error').waitFor();
    ok((await page.locator('#status').innerText()).includes('ENGINEERING QA') && await page.locator('#samples article button:enabled').count() === 3, 'creation error is visible and available buttons recover');
    await page.unroute('**/api/public-demos/bag-revision/orders');
    const saved = (await api('/api/orders')).orders;
    ok(saved.length === 3 && saved.every(order => order.checks.length === 0 && order.completions.length === 0 && order.status !== 'completed'), 'all three persisted demo orders remain free of fabricated checks or completions');
    ok(!requests.some(request => request.url.endsWith('/inspect') || request.url.endsWith('/propose-revision') || request.url.endsWith('/complete')), 'browser never automatically requests model execution or completion');
    ok(!fs.existsSync(path.join(output, 'forbidden-inference.jsonl')), 'NoInference adapter recorded zero invocation attempts');
    ok(requests.every(request => request.url.startsWith(url + '/')), 'browser gallery and workspace assets stay on isolated local origin');
    ok(errors.length === 0, 'zero browser JavaScript errors');
    const sourceFiles = ['kitguard/public_demo_catalog.py', 'kitguard/app.py', 'kitguard/store.py', 'kitguard/static/demo.html', 'kitguard/static/demo.js', 'kitguard/static/demo.css', 'kitguard/static/app.js'];
    const root = path.resolve(output, '../../..');
    const hashes = Object.fromEntries(sourceFiles.map(file => [file, crypto.createHash('sha256').update(fs.readFileSync(path.join(root, file))).digest('hex')]));
    fs.writeFileSync(path.join(output, 'result.json'), JSON.stringify({ status: 'passed', passed: checks.length, checks, errors, orderIds: orders, sources, requests, explicitRequests, source_sha256: hashes, scope: 'Actual three public development PNGs and actual API with isolated database on 8772; NoInference. One transient ready-shaped rendering-only contract and one mocked creation failure, both explicitly engineering. Not model accuracy, new holdout evidence, field completion or human usability evidence.' }, null, 2));
    console.log(JSON.stringify({ passed: checks.length, errors, orderIds: orders }));
  } finally { await context.close(); await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
