# v0.3 final report QA

The completed report was built and exported through the Data plugin's formal CLI. The authored snapshot and the original historical runs remain inspectable; the frozen holdout has 59 C, 0 W, 5 U and 0 E across 64 images. Paired first-pass results are 62 C and 2 W, with no separately measured baseline latency.

- Live report: 87 assertions passed in real Chrome at desktop and 390px mobile widths. No JavaScript errors, failed loads, or application mutation requests. All six paired rows, fourteen v0.3 cohort rows, source inspection, historical scope and contained table scrolling were checked.
- Official single-file offline export: 18 assertions passed with HTTP access disabled. Zero HTTP requests; no errors or failed loads. Export is byte-identical to `output/report/KitGuard_v0.3.html`.
- Representative final screenshots were visually inspected at desktop and mobile widths. Tables and explanatory text remain readable.
- First live attempt reached a connection refusal because the previous local report server had stopped; the static server was restarted and the same QA then passed. No product change or model call resulted from that harness failure.

These are browser/engineering checks, not additional recognition samples or a human usability study. Exact hashes and check lists are in `browser-result.json` and `offline-result.json`.
