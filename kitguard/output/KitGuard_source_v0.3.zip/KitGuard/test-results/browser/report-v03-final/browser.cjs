// Live, read-only browser QA of the official Data build; not a model evaluation.
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const {chromium} = require('/Users/lkc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root = path.resolve(__dirname, '../../..'), app = path.join(root, 'reports/self-evaluation');
const build = JSON.parse(fs.readFileSync(path.join(app, 'dist/data-app-build.json'), 'utf8'));
const snapshot = JSON.parse(fs.readFileSync(path.join(app, 'dist', build.snapshot.path), 'utf8'));
const runs = snapshot.queries.v03_runs.rows, features = snapshot.queries.v03_features.rows;
const paired = snapshot.queries.v03_comparison?.rows || [];
assert.equal(snapshot.buildStatus, 'complete');
assert.equal(paired.length, 6);
const selection = snapshot.queries.v03_selection.rows.at(-1);
(async () => {
  const browser = await chromium.launch({headless:true, executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
  const page = await browser.newPage({viewport:{width:1440,height:1000}}), checks = [], errors = [], failed = [], mutations = [];
  const ok = (value, name) => {assert.ok(value, name); checks.push(name);};
  page.on('pageerror', e => errors.push(String(e)));
  page.on('requestfailed', request => failed.push(request.url()));
  page.on('request', request => {if (!['GET','HEAD'].includes(request.method())) mutations.push({url:request.url(),method:request.method()});});
  try {
    await page.goto('http://127.0.0.1:4173/', {waitUntil:'networkidle'});
    await page.locator('.kg-v03').waitFor();
    const section = page.locator('.kg-v03'), summary = page.locator('[data-component-id="v03-summary"]');
    const body = await page.locator('.kg-report').innerText();
    const current = await summary.innerText();
    ok(current.includes(selection.headline) && current.includes(selection.holdoutStatus) && current.includes(selection.selectedDefault), 'summary headline, holdout state and default match the reviewed selection');
    ok(current.includes(selection.knownLimits), 'reviewed known limits remain visible');
    ok(body.includes('v0.2 历史阶段结论') && body.includes('v0.2 冻结评测与历史细节'), 'historical v0.2 scope is labelled explicitly');
    ok(body.includes('同一次流程中的配对基线') && body.includes('不是新测得的端到端流程时间'), 'paired baseline and replay timing boundaries are explicit');
    await page.screenshot({path:path.join(__dirname,'01-desktop-current.png'),animations:'disabled'});

    const pairedComponent = page.locator('[data-component-id="v03-paired-results"]');
    const pairedCells = [];
    for (const row of await pairedComponent.locator('tbody tr').all()) pairedCells.push(await row.locator('td').allTextContents());
    ok(pairedCells.length===paired.length, 'all six same-image comparison rows are visible');
    paired.forEach((r,i)=>{
      const cells=pairedCells[i];
      ok(cells[0].trim()===r.cohort && cells[1].trim()===r.method && cells.slice(2,7).map(x=>Number(x.trim())).every((n,k)=>n===[r.images,r.correct,r.wrong,r.abstained,r.errors][k]), 'paired counts match reviewed row '+i);
      ok(cells[7].includes(r.medianMs===null?'未独立测量':(r.medianMs/1000).toFixed(2)+' 秒') && cells[8].includes(r.gate), 'paired timing and gate match reviewed row '+i);
    });
    await pairedComponent.scrollIntoViewIfNeeded();
    await page.screenshot({path:path.join(__dirname,'07-paired-comparison.png'),animations:'disabled'});
    const component = page.locator('[data-component-id="v03-runs"]');
    const table = page.getByRole('table',{name:'v0.3 候选结果与代价',exact:true});
    const rendered = [];
    while (true) {
      for (const tr of await table.locator('tbody tr').all()) rendered.push(await tr.locator('td').allTextContents());
      const next = component.getByRole('button',{name:'Next page',exact:true});
      if (await next.count() === 0 || await next.isDisabled()) break;
      await next.click();
    }
    ok(rendered.length === runs.length, 'all reviewed v0.3 cohort rows remain reachable across pagination');
    for (const row of runs) {
      const cells = rendered.find(c => c[0].includes(row.run) && c[1].includes(row.cohort));
      ok(Boolean(cells), `run/cohort row retained: ${row.run} / ${row.cohort}`);
      if (row.status !== 'completed') {
        ok(cells.slice(3).every(c => c.includes('未完成')), `incomplete score hidden: ${row.run}`);
        continue;
      }
      ok(cells[3].includes(`${row.correct} / ${row.images}`), `correct uses own cohort denominator: ${row.run} / ${row.cohort}`);
      if (row.kind === 'detector') {
        ok(cells[3].includes('仅完整计数') && cells.slice(4,7).every(c => c.trim() === '未提供'), `detector business fields remain missing: ${row.run} / ${row.cohort}`);
      } else {
        ok(cells[3].includes('正确且可执行') && cells[4].trim() === `${row.actionable} / ${row.images}` && cells[5].trim() === `${row.wrong} / ${row.actionable}` && cells[6].trim() === `${row.abstained} / ${row.images}`, `VLM counts, coverage, wrong denominator and abstentions match: ${row.run} / ${row.cohort}`);
      }
      ok(cells[8].includes((row.medianMs / 1000).toFixed(2)+' 秒') && cells[8].includes(row.timingNote), `timing and measurement boundary match: ${row.run} / ${row.cohort}`);
    }
    while (await component.getByRole('button',{name:'Previous page',exact:true}).count() && await component.getByRole('button',{name:'Previous page',exact:true}).isEnabled()) await component.getByRole('button',{name:'Previous page',exact:true}).click();
    await table.scrollIntoViewIfNeeded();
    await page.screenshot({path:path.join(__dirname,'02-desktop-runs.png'),animations:'disabled'});
    const featureTable = page.getByRole('table',{name:'v0.3 功能与验证范围',exact:true});
    ok(await featureTable.locator('tbody tr').count() === features.length, 'all reviewed feature records present');
    ok((await featureTable.innerText()).includes('工程') && (await section.innerText()).includes('不属于真人现场试验'), 'engineering fixtures distinguished from field study');

    for (const [title, queryId, searchTerm] of [
      ['v0.3 当前判断','v03_selection',selection.headline],
      ['同一批新64张：错误被挡住了多少，正确回答又损失了多少？','v03_comparison','Screws'],
      ['v0.3 候选结果与代价','v03_runs',runs.at(-1).run],
      ['v0.3 功能与验证范围','v03_features',features.at(-1).feature],
    ]) {
      await page.getByRole('button',{name:title+' actions',exact:true}).click();
      await page.getByRole('menuitem',{name:'View data source',exact:true}).click();
      await page.getByRole('tab',{name:'Data preview',exact:true}).click();
      const panel = page.getByRole('tabpanel',{name:'Data preview',exact:true});
      await panel.getByRole('textbox',{name:'Search data',exact:true}).fill(searchTerm);
      await panel.getByRole('row').filter({hasText:searchTerm}).first().waitFor();
      ok((await panel.innerText()).includes(searchTerm), `shared source inspector shows exact reviewed ${queryId} row`);
      if (queryId === 'v03_runs') await page.screenshot({path:path.join(__dirname,'03-runs-source.png'),animations:'disabled'});
      await page.getByRole('button',{name:'Close data source',exact:true}).first().click();
      await page.getByRole('button',{name:'Close data source',exact:true}).first().waitFor({state:'hidden'});
    }
    const old = page.locator('[data-component-id="report-summary"]');
    ok((await old.innerText()).includes('46 / 48') && (await old.innerText()).includes('1 / 24'), 'v0.2 historical holdout result and false-ready remain intact');
    await page.getByRole('button',{name:'全部真实图像核验运行 actions',exact:true}).click();
    await page.getByRole('menuitem',{name:'View data source',exact:true}).click();
    await page.getByRole('tab',{name:'Data preview',exact:true}).click();
    const oldPanel = page.getByRole('tabpanel',{name:'Data preview',exact:true});
    await oldPanel.getByRole('textbox',{name:'Search data',exact:true}).fill('loco_holdout_release_v1');
    await oldPanel.getByRole('row').filter({hasText:'loco_holdout_release_v1'}).waitFor();
    ok(true,'existing v0.2 source inspection still resolves historical holdout');
    await page.getByRole('button',{name:'Close data source',exact:true}).first().click();
    await page.getByRole('button',{name:'Close data source',exact:true}).first().waitFor({state:'hidden'});

    await page.setViewportSize({width:390,height:844});
    await summary.scrollIntoViewIfNeeded();
    ok(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth), '390px phone page has no horizontal overflow');
    await page.screenshot({path:path.join(__dirname,'04-mobile-current.png'),animations:'disabled'});
    await table.scrollIntoViewIfNeeded();
    ok(await table.evaluate(el=>{let p=el.parentElement; while(p && p.scrollWidth <= p.clientWidth+1) p=p.parentElement; if(!p || p===document.body || p===document.documentElement)return false; p.scrollLeft=p.scrollWidth; return p.scrollLeft>0;}), 'wide candidate table scrolls inside its own mobile container');
    await page.screenshot({path:path.join(__dirname,'05-mobile-table-scroll.png'),animations:'disabled'});
    await featureTable.scrollIntoViewIfNeeded();
    ok(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth), 'feature table keeps mobile page width contained');
    await page.screenshot({path:path.join(__dirname,'06-mobile-features.png'),animations:'disabled'});
    ok(errors.length===0 && failed.length===0, 'no browser JavaScript errors or failed requests');
    ok(mutations.length===0, 'QA made no HTTP mutations or model calls');
    const result = {passed:checks.length,checks,errors,failed,mutations,buildManifest:build,selection,scope:'Final v0.3 report UI/source verification at 1440x1000 and 390x844 against the official build snapshot. Read-only; no GPU, production data, or old delivery artifact writes; completed reviewed holdout rows inspected. These are engineering assertions, not independent model samples or user-study results.'};
    fs.writeFileSync(path.join(__dirname,'browser-result.json'),JSON.stringify(result,null,2)+'\n');
    console.log(JSON.stringify({passed:checks.length,errors,failed,snapshot:build.snapshot}));
  } finally {await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
