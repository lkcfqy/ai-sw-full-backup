"""Isolated SYNTHETIC engineering observer. No MLX/model calls or production data."""
import sys, hashlib
from pathlib import Path
from io import BytesIO
from PIL import Image
sys.path[:0] = ['/Users/lkc/Downloads/AI·SW/kitguard', '/Users/lkc/Downloads/AI·SW/kitguard/tests']
from conftest import FakeAnalyzer, REQUIREMENTS
from kitguard.app import create_app
import uvicorn
class SequenceAnalyzer(FakeAnalyzer):
    def __init__(self):
        super().__init__(); self.sequence = 0
    def observe(self, image_path, requirements, references):
        self.sequence += 1
        observed = dict(REQUIREMENTS)
        observed['washer'] = [None, 1, 2][min(self.sequence - 1, 2)]
        result = self.observation(observed, action='separate' if observed['washer'] is None else 'none')
        first = dict(observed); second = dict(observed)
        if self.sequence == 1: first['washer'] = 1; second['washer'] = 2
        photo=Path(image_path)
        b=BytesIO()
        with Image.open(photo) as im: im.transpose(Image.Transpose.ROTATE_90).save(b, format='PNG')
        result['verification']={
            'mode':'dual_orientation','same_model_correlated_calls':True,
            'counts_agree':self.sequence != 1,'clear_agreement':self.sequence != 1,
            'passes':[
                {'transform':'original','input_sha256':hashlib.sha256(photo.read_bytes()).hexdigest(),'observed':first,'issues':[],'action':{'kind':'none','message':'SYNTHETIC ENGINEERING observer pass A, not real inference','region':None}},
                {'transform':'rotate_90_ccw','input_sha256':hashlib.sha256(b.getvalue()).hexdigest(),'observed':second,'issues':[],'action':{'kind':'none','message':'SYNTHETIC ENGINEERING observer pass B, not real inference','region':None}},
            ]}
        return result
app=create_app(data_dir=Path(__file__).parent/'data',analyzer=SequenceAnalyzer())
uvicorn.run(app,host='127.0.0.1',port=8769)
