from io import BytesIO
from pathlib import Path
import json
import httpx
from PIL import Image, ImageDraw
out=Path('/Users/lkc/Downloads/AI·SW/kitguard/test-results/browser/orientation-details')
def image(seed):
    im=Image.new('RGB',(640,480),(239,242,230)); draw=ImageDraw.Draw(im)
    draw.text((25,25),f'SYNTHETIC ENGINEERING UI FIXTURE {seed}',fill='#243f36')
    draw.text((25,48),'NOT REAL VISION / NOT COMPETITION DATA',fill='#a55838')
    draw.rectangle((60+seed*8,150,210+seed*8,320),fill='#708d70')
    draw.ellipse((350,190,500,340),fill='#bacba3')
    b=BytesIO(); im.save(b,'PNG'); return b.getvalue()
with httpx.Client(base_url='http://127.0.0.1:8769') as c:
    def post(url,**kw):
        r=c.post(url,**kw); r.raise_for_status(); return r.json()
    order=post('/api/orders',json={'title':'SYNTHETIC ENGINEERING · orientation UI only','requirements':{'bolt':2,'nut':2,'washer':2,'bracket':1}})['order']
    oid=order['id']; refs={}
    for i,p in enumerate(['bolt','nut','washer','bracket']):
        order=post(f'/api/orders/{oid}/references/{p}',files={'photo':('synthetic.png',image(i),'image/png')})['order']; refs[p]=order['references'][p]['id']
    checks=[]
    for i in range(3):
        res=post(f'/api/orders/{oid}/photos',data={'expected_revision':1},files={'photo':('synthetic.png',image(i+5),'image/png')})
        res=post(f'/api/orders/{oid}/inspect',json={'expected_revision':1,'photo_id':res['photo']['id']}); checks.append(res['check'])
    post(f'/api/orders/{oid}/revise',json={'expected_revision':1,'requirements':{'bolt':2,'nut':2,'washer':3,'bracket':1},'instruction':'ENGINEERING TEST ONLY: prove historical requirements stay R1'})
    order=post(f'/api/orders/{oid}/references/bolt',files={'photo':('synthetic-new-ref.png',image(10),'image/png')})['order']
    ids={'order':oid,'first':checks[0]['id'],'improved':checks[1]['id'],'match':checks[2]['id'],'refs':refs,'new_ref':order['references']['bolt']['id']}
    (out/'ids.json').write_text(json.dumps(ids,indent=2)); (out/'order.json').write_text(json.dumps(order,indent=2,ensure_ascii=False))
    print(json.dumps({'ids':ids,'decisions':[ch['decision'] for ch in checks],'outcomes':[ch.get('evidence_feedback',{}).get('outcome') if ch.get('evidence_feedback') else None for ch in checks]},ensure_ascii=False))
