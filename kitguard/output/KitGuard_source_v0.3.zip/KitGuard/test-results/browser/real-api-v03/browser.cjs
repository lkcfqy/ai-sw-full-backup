/* Real candidate API capture. Only explicit UI inspect/proposal actions may invoke the model. */
'use strict';
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const assert = require('node:assert/strict'), {spawnSync} = require('node:child_process');
const HERE = __dirname, ROOT = path.resolve(HERE, '../../..'), BASE = 'http://127.0.0.1:8774';
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const argv = process.argv.slice(2);
function value(flag) {const i = argv.indexOf(flag); return i >= 0 ? argv[i + 1] : null;}
if (argv.includes('--help')) {
  console.log('node browser.cjs --output <same new server run directory> --execute-real-model [--language ko|zh]\n--validate-only: configuration check only, no browser, HTTP or model. Wait for root GPU-free notification before execution.');
  process.exit(0);
}
const outputArg = value('--output');
if (!outputArg) throw new Error('--output is required');
const output = path.resolve(outputArg), language = value('--language') || 'ko';
if (!output.startsWith(path.join(HERE, 'runs') + path.sep)) throw new Error('Output must be a named child of this script\'s runs/ directory');
if (!['ko','zh'].includes(language)) throw new Error('Language must be ko or zh');
if (argv.includes('--validate-only')) {
  console.log(JSON.stringify({label:'candidate real API verification',base:BASE,output,language,planned_samples:3,planned_inspections:4,planned_instruction_calls:1,planned_model_requests:5,real_execution:false}));
  process.exit(0);
}
if (!argv.includes('--execute-real-model')) throw new Error('Requires --execute-real-model after root GPU-free authorization');
const server = JSON.parse(fs.readFileSync(path.join(output, 'server.json'), 'utf8'));
assert.equal(server.base_url, BASE);
assert.equal(server.data_dir, path.join(output, 'data'));
assert.equal(server.observation_mode, 'spatial_guarded');
assert.equal(server.image_max_side, 1536);
assert.equal(sha(fs.readFileSync(__filename)),server.source_sha256['test-results/browser/real-api-v03/browser.cjs'],'Browser script must match the launched frozen source');
const out = path.join(output, 'browser');
fs.mkdirSync(out); // Never overwrite or silently resume an earlier attempt.
for (const name of ['http','screenshots','public-source','archives','orders','video']) fs.mkdirSync(path.join(out,name));
const {chromium} = require('/Users/lkc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const checks = [], errors = [], failures = [], notes = [], events = [], outcomes = [], orderIds = [], receipts = [], receiptTasks = [];
const sources = new Map(), startedAt = new Date().toISOString();
const requestStarts = new WeakMap();
let receiptIndex = 0, inspectClicks = 0, proposalClicks = 0, revisionClicks = 0, uploadActions = 0, fatal = null, activeInspection = null, activeInstruction = null, instructionOutcome = null;
function write(name, value) {fs.writeFileSync(path.join(out,name), JSON.stringify(value,null,2)+'\n');}
function ok(condition, name) {assert.ok(condition,name); checks.push(name);}
function event(kind, payload={}) {events.push({at:new Date().toISOString(),kind,...payload}); write('events.json',events);}
function saveReceipt({route,method,status,headers,requestBody,bytes,durationMs,origin}) {
  const id = String(++receiptIndex).padStart(4,'0'), contentType = headers['content-type'] || '';
  let responseBody;
  if (contentType.includes('json')) {
    try {responseBody=JSON.parse(bytes.toString('utf8'));} catch {responseBody={invalid_json:bytes.toString('utf8')};}
  }
  const extension = contentType.includes('zip') ? '.zip' : contentType.includes('png') ? '.png' : contentType.includes('jpeg') ? '.jpg' : '.body';
  const bodyFile = 'http/'+id+extension;
  fs.writeFileSync(path.join(out,bodyFile),bytes);
  const receipt = {id,at:new Date().toISOString(),origin,route,method,status,headers,requestBody,wall_ms:durationMs??null,response_sha256:sha(bytes),response_bytes:bytes.length,response_file:bodyFile,responseBody};
  write('http/'+id+'.json',receipt);receipts.push(receipt);return receipt;
}
async function get(route) {
  const begin=performance.now(),response=await fetch(BASE+route),bytes=Buffer.from(await response.arrayBuffer());
  const receipt=saveReceipt({route,method:'GET',status:response.status,headers:Object.fromEntries(response.headers),bytes,durationMs:performance.now()-begin,origin:'script read-only'});
  if(!response.ok) throw new Error(`GET ${route}: ${response.status}`);
  return {receipt,bytes,json:receipt.responseBody};
}
async function settle(page) {
  await page.waitForFunction(()=>typeof state!=='undefined'&&state.initialized&&!state.busy,{},{timeout:15000});
}
async function screenshot(page,name,fullPage=false) {await page.screenshot({path:path.join(out,'screenshots',name+'.png'),fullPage,animations:'disabled'});}
async function openAudit(page,check,name) {
  const link=page.locator(`[data-action="audit-check"][data-check="${check.id}"]`).first();
  await link.scrollIntoViewIfNeeded();await link.click();
  await page.locator('#audit-dialog .audit-detail-content').waitFor();
  const toggle=page.locator('#audit-dialog [data-action="spatial-toggle"]');
  if(await toggle.count() && await toggle.isEnabled()) await toggle.click();
  await screenshot(page,name+'-audit');
  if(check.identity_verification) {
    await page.locator('#audit-dialog .audit-identity').scrollIntoViewIfNeeded();
    await screenshot(page,name+'-identity');
  }
  await page.locator('#audit-dialog [data-action="close-modal"]').first().click();
  await page.locator('#audit-dialog').waitFor({state:'hidden'});
}
async function exportArchive(page,order,name) {
  write('orders/'+name+'.json',order);
  const href=`/api/orders/${order.id}/evidence.zip`;
  const downloadPromise=page.waitForEvent('download');
  await page.locator(`a[href="${href}"]`).first().click();
  const download=await downloadPromise,archive=path.join(out,'archives',name+'.zip');
  await download.saveAs(archive);
  const result=spawnSync(path.join(ROOT,'.venv/bin/python'),[path.join(HERE,'verify_zip.py'),'--archive',archive,'--order-json',path.join(out,'orders',name+'.json'),'--output',path.join(out,'archives',name+'-verification.json')],{encoding:'utf8'});
  fs.writeFileSync(path.join(out,'archives',name+'-verification.stdout.txt'),result.stdout||'');
  fs.writeFileSync(path.join(out,'archives',name+'-verification.stderr.txt'),result.stderr||'');
  ok(result.status===0, name+': actual ZIP equals saved API order and has valid byte hashes');
  return archive;
}
function inspectMetadata(order,check,sample) {
  const photo=order.photos.find(p=>p.id===check.photo_id);
  ok(check.backend==='mlx',`${sample}: real MLX backend recorded`);
  ok(check.runtime_identity?.observation_mode==='spatial_guarded' && check.runtime_identity?.image_max_side===1536,`${sample}: experimental mode and resolution recorded in check`);
  ok(check.runtime_identity?.observer_protocol_sha256===server.model_before.observer_protocol_sha256,`${sample}: check is bound to launched protocol hash`);
  ok(photo && photo.source_sha256===sources.get(sample).sample.source_sha256 && photo.sha256===check.photo_sha256,`${sample}: source, normalized photo and check hashes match`);
  ok(check.observation_verification?.mode==='spatial_consensus' && check.observation_verification.passes.length===2,`${sample}: actual two-pass history retained`);
  const verification=check.observation_verification;
  const candidates=verification.passes[0].objects.some(o=>['nut','washer'].includes(o.part));
  if(verification.clear_agreement && candidates) ok(Boolean(check.identity_verification),`${sample}: clear ring candidates have actual identity verification`);
  if(check.identity_verification) {
    const identity=check.identity_verification;
    ok(identity.protocol==='identity_geometry_v2' && identity.same_model_correlated_calls===true && identity.source_sha256===photo.sha256,`${sample}: identity protocol/correlation/source persisted`);
    const cropIds=identity.crops.map(c=>c.id).sort(),responseIds=identity.response.objects.map(o=>o.id).sort();
    ok(JSON.stringify(cropIds)===JSON.stringify(responseIds) && new Set(cropIds).size===cropIds.length,`${sample}: one recorded identity response per crop`);
  } else notes.push({sample,check_id:check.id,note:'No identity record was returned. Preserve actual skip/unclear/no-candidate outcome; no metadata is fabricated.'});
  ok(order.checks.some(c=>c.id===check.id && JSON.stringify(c)===JSON.stringify(check)),`${sample}: current response is also present unchanged in history`);
  ok(order.completions.length===0 && order.demo_source?.physical_completion_allowed===false,`${sample}: no physical completion is recorded`);
}
async function inspectOnce(page,sample,revision) {
  const orderId=new URL(page.url()).searchParams.get('order'),name=`${sample}-r${revision}`;
  const before=(await get('/api/orders/'+orderId)).json.order;
  ok(before.revision===revision && before.photos.at(-1).revision===revision,name+': fresh evidence is bound to requested revision');
  const button=page.locator('[data-action="inspect"]');await button.scrollIntoViewIfNeeded();
  ok(await button.isEnabled(),name+': actual inspect button is available');
  event('user_action_inspect',{sample,revision,order_id:orderId});inspectClicks++;
  const begin=performance.now();
  activeInspection={sample,revision,order_id:orderId,started:begin,http_status:null,dispatched:false};
  const pending=page.waitForResponse(r=>r.url()===BASE+`/api/orders/${orderId}/inspect`&&r.request().method()==='POST',{timeout:320000});
  await button.click();
  const response=await pending;activeInspection.http_status=response.status();
  const body=await response.json(),finished=performance.now();
  const wall=finished-(requestStarts.get(response.request())??begin),clickToResult=finished-begin;
  await settle(page);
  const order=(await get('/api/orders/'+orderId)).json.order;
  const outcome={sample,revision,order_id:orderId,http_status:response.status(),request_wall_ms:wall,actual_elapsed_ms:wall,click_to_result_ms:clickToResult,response:body,check_latency_ms:body.check?.latency_ms??null,check_id:body.check?.id??null,runtime_mode:body.check?.runtime_identity?.observation_mode??null,backend:body.check?.backend??null,decision:body.check?.decision??null,status:response.ok()?'recorded':'execution_error'};
  activeInspection=null;
  outcomes.push(outcome);write('outcomes.json',outcomes);
  await page.locator('.workspace-heading').scrollIntoViewIfNeeded();await screenshot(page,name+'-workspace');
  if(response.ok()) {
    inspectMetadata(order,body.check,sample);
    const spatial=page.locator('[data-spatial-scope="workspace"] [data-action="spatial-toggle"]');
    if(await spatial.count() && await spatial.isEnabled()) {await spatial.click();await screenshot(page,name+'-points');}
    await openAudit(page,body.check,name);
  } else {
    notes.push({sample,revision,http_status:response.status(),detail:body.detail,note:'Execution failure retained; no retry and no clear-success fallback.'});
    ok(order.completions.length===0,name+': failure did not create physical completion');
  }
  await exportArchive(page,order,name);
  ok(await page.locator('[data-action="complete"]').count()===0,name+': public demo offers no completion button');
  event('inspection_returned',{sample,revision,http_status:response.status(),decision:body.check?.decision??null,wall_ms:wall});
  if(response.status()===504) throw new Error('504: stop dispatching because background GPU work may still be running; retain this failed attempt');
  return order;
}
async function reviseBag(page,order) {
  const instruction='볼트 2개, 너트 2개, 와셔 2개, 브래킷 0개로 변경해 주세요.';
  const target={bolt:2,nut:2,washer:2,bracket:0};
  event('order_change_only',{sample:'bag-revision',from_revision:1,to_revision:2,note:'One real Korean proposal call, followed by an explicit UI approval or disclosed structured fallback. Same public PNG will be reuploaded; no physical change claimed.'});
  await page.locator('[data-action="revise"]').click();
  await page.locator('[data-action="revision-mode"][data-mode="natural"]').click();
  await page.locator('#revision-form [name="instruction"]').fill(instruction);
  ok(await page.locator('#revision-submit').isDisabled(),'proposal: approval starts disabled before any model proposal');
  await screenshot(page,'bag-revision-korean-instruction');
  const runtimeBefore=(await get('/api/health')).json.model;
  const begin=performance.now();
  activeInstruction={order_id:order.id,instruction,started:begin,http_status:null,dispatched:false};
  event('user_action_request_instruction_proposal',{order_id:order.id,instruction,expected_revision:1});proposalClicks++;
  const proposalPending=page.waitForResponse(r=>r.url()===BASE+`/api/orders/${order.id}/propose-revision`&&r.request().method()==='POST',{timeout:320000});
  await page.locator('[data-action="propose"]').click();
  const proposed=await proposalPending;activeInstruction.http_status=proposed.status();
  const responseBody=await proposed.json(),finished=performance.now();
  const requestWall=finished-(requestStarts.get(proposed.request())??begin);
  await settle(page);
  const unchanged=(await get('/api/orders/'+order.id)).json.order;
  const runtimeAfter=(await get('/api/health')).json.model;
  const requirements=responseBody.proposal?.requirements;
  const matches=proposed.ok() && responseBody.proposal?.base_revision===1 && requirements && Object.keys(requirements).length===4 && Object.entries(target).every(([part,count])=>requirements[part]===count);
  instructionOutcome={sample:'bag-revision',order_id:order.id,model_task:'instruction_proposal',instruction,expected_revision:1,intended_requirements:target,http_status:proposed.status(),actual_elapsed_ms:requestWall,request_wall_ms:requestWall,click_to_result_ms:finished-begin,response:responseBody,proposal:responseBody.proposal??null,proposal_matches_intended:Boolean(matches),status:proposed.status()===422?'clarification':!proposed.ok()?'execution_error':matches?'proposal_returned':'proposal_mismatch',runtime_before:runtimeBefore,runtime_after:runtimeAfter,fallback_used:!matches,approval:null,scope:'Actual local language-model API request. Runtime status is a before/after snapshot, not a separate per-request trace. Approval is an explicit automated UI action, not a human user study.'};
  activeInstruction=null;write('instruction-outcome.json',instructionOutcome);
  ok(unchanged.revision===1 && Object.entries(order.requirements).every(([part,count])=>unchanged.requirements[part]===count),'proposal: generating or rejecting a proposal did not alter the order');
  if(proposed.ok()) await page.locator('#proposal-result .proposal-card').waitFor();
  await screenshot(page,'bag-revision-actual-proposal-result');
  if(matches) {
    ok(await page.locator('#revision-submit').isEnabled(),'proposal: reviewed matching proposal can be explicitly approved');
    event('user_action_approve_proposal',{order_id:order.id,requirements,automated_ui_action:true});
  } else {
    instructionOutcome.fallback_reason=proposed.status()===422?'Actual API requested clarification':proposed.ok()?'Actual proposed quantities did not match the explicit instruction':'Actual proposal API failed';
    event('user_action_structured_fallback',{order_id:order.id,reason:instructionOutcome.fallback_reason,original_http_status:proposed.status(),not_model_success:true});
    await page.locator('[data-action="revision-mode"][data-mode="structured"]').click();
    for(const [part,count] of Object.entries(target)) await page.locator(`#revision-form [name="${part}"]`).fill(String(count));
    await page.locator('#revision-form [name="instruction"]').fill('자연어 제안 미승인 후 직접 수정; 공개 사진 재사용·실물 변경 없음 / 自然语言提案未获批准，改用结构表单；同一公开照片，无实物变化');
    await screenshot(page,'bag-revision-structured-fallback');
  }
  write('instruction-outcome.json',instructionOutcome);
  const pending=page.waitForResponse(r=>r.url()===BASE+`/api/orders/${order.id}/revise`&&r.request().method()==='POST');
  const approvalBegin=performance.now();revisionClicks++;await page.locator('#revision-submit').click();const response=await pending;
  const approvalBody=await response.json();
  instructionOutcome.approval={performed:true,applied:response.ok(),via:matches?'natural_proposal':'structured_fallback',automated_ui_action:true,http_status:response.status(),actual_elapsed_ms:performance.now()-(requestStarts.get(response.request())??approvalBegin),from_revision:1,to_revision:approvalBody.order?.revision??null,requirements:approvalBody.order?.requirements??null};
  write('instruction-outcome.json',instructionOutcome);
  ok(response.status()===200,`bag-revision: ${matches?'reviewed natural proposal':'disclosed structured fallback'} applied through actual approval form`);await settle(page);
  const revised=(await get('/api/orders/'+order.id)).json.order;
  ok(revised.revision===2 && revised.checks.every(c=>!c.valid),'bag-revision: historical checks invalidated by R2');
  ok(await page.locator('[data-action="inspect"]').isDisabled(),'bag-revision: R1 photo cannot directly authorize an R2 check');
  await page.locator('.workspace-heading').scrollIntoViewIfNeeded();await screenshot(page,'bag-revision-r2-needs-upload');
  const uploadResponse=page.waitForResponse(r=>r.url()===BASE+`/api/orders/${order.id}/photos`&&r.request().method()==='POST');
  const chooserPromise=page.waitForEvent('filechooser');await page.locator('[data-action="upload-photo"]').first().click();
  const chooser=await chooserPromise;uploadActions++;await chooser.setFiles(sources.get('bag-revision').path);
  const upload=await uploadResponse;ok(upload.status()===201,'bag-revision: same source reuploaded through actual file control');await settle(page);
  const saved=(await get('/api/orders/'+order.id)).json.order;
  ok(saved.photos.at(-1).revision===2 && saved.photos.at(-1).source_sha256===order.photos[0].source_sha256,'bag-revision: R2 record keeps the same public source hash');
  notes.push({sample:'bag-revision',note:'R2 uses the exact same public PNG uploaded again to satisfy the real revision/evidence contract. Only order quantities changed; this is not new field evidence or proof of adding/removing parts.'});
  if(proposed.status()===504) throw new Error('Proposal 504: structured fallback was preserved, but no later GPU request is dispatched while the original model call may still be running');
}

(async()=>{
  let browser,context,page,video;
  try {
    const health=(await get('/api/health')).json;
    ok(health.model.available===true && health.model.observation_mode==='spatial_guarded' && health.model.image_max_side===1536,'real candidate configuration is available');
    ok(health.model.observer_protocol_sha256===server.model_before.observer_protocol_sha256,'server remains on launched source protocol');
    ok((await get('/api/orders')).json.orders.length===0,'independent API database starts empty');
    const samples=(await get('/api/public-demos')).json.samples;
    ok(samples.map(s=>s.sample_id).join(',')==='bag-revision,small-part,mixed-screws' && samples.every(s=>s.available),'only three declared public development demos are available');
    for(const sample of samples) {
      const download=await get(`/api/public-demos/${sample.sample_id}/photo`);
      ok(sha(download.bytes)===sample.source_sha256,sample.sample_id+': API public PNG source hash verified');
      const file=path.join(out,'public-source',sample.sample_id+'.png');fs.writeFileSync(file,download.bytes);
      sources.set(sample.sample_id,{sample,path:file});
    }
    browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
    context=await browser.newContext({viewport:{width:1440,height:900},recordVideo:{dir:path.join(out,'video'),size:{width:1440,height:900}},acceptDownloads:true});
    page=await context.newPage();video=page.video();
    page.on('pageerror',error=>errors.push(String(error)));
    page.on('requestfailed',request=>failures.push({url:request.url(),method:request.method(),failure:request.failure()}));
    page.on('request',request=>{requestStarts.set(request,performance.now());if(activeInspection && request.method()==='POST' && request.url().endsWith('/inspect')) activeInspection.dispatched=true;if(activeInstruction && request.method()==='POST' && request.url().endsWith('/propose-revision')) activeInstruction.dispatched=true;event('browser_request',{method:request.method(),url:request.url()});});
    page.on('response',response=>{
      if(!response.url().startsWith(BASE+'/api/')) return;
      const task=(async()=>{
        const request=response.request(),buffer=request.postDataBuffer(),type=request.headers()['content-type']||'';
        const requestBody=buffer ? type.includes('json') ? JSON.parse(buffer.toString('utf8')) : {sha256:sha(buffer),bytes:buffer.length,content_type:type} : null;
        try {const bytes=await response.body();saveReceipt({route:response.url().slice(BASE.length),method:request.method(),status:response.status(),headers:response.headers(),requestBody,bytes,durationMs:performance.now()-(requestStarts.get(request)??performance.now()),origin:'actual browser'});}
        catch(error) {
          const id=String(++receiptIndex).padStart(4,'0');
          const receipt={id,at:new Date().toISOString(),origin:'actual browser',route:response.url().slice(BASE.length),method:request.method(),status:response.status(),headers:response.headers(),requestBody,wall_ms:performance.now()-(requestStarts.get(request)??performance.now()),response_file:null,response_body_unavailable:String(error)};
          write('http/'+id+'.json',receipt);receipts.push(receipt);
          notes.push({route:response.url(),note:'Browser response body unavailable (e.g. download); actual downloaded bytes saved separately.',error:String(error)});
        }
      })();receiptTasks.push(task);
    });
    for(let index=0;index<samples.length;index++) {
      const sample=samples[index];
      await page.goto(BASE+'/static/demo.html',{waitUntil:'networkidle'});
      await page.waitForFunction(()=>document.querySelectorAll('#samples article').length===3 && [...document.querySelectorAll('#samples img')].every(i=>i.complete&&i.naturalWidth>0));
      if(index===0) await screenshot(page,'00-public-gallery',true);
      event('user_action_create_public_demo',{sample:sample.sample_id});
      const createdPromise=page.waitForResponse(r=>r.url()===BASE+`/api/public-demos/${sample.sample_id}/orders`&&r.request().method()==='POST');
      await page.locator('#samples article button').nth(index).click();const created=await createdPromise;
      ok(created.status()===201,sample.sample_id+': actual endpoint created order');
      await page.waitForURL(u=>u.origin===BASE && Boolean(u.searchParams.get('order')));
      const redirectedOrderId=new URL(page.url()).searchParams.get('order');
      const initial=(await get('/api/orders/'+encodeURIComponent(redirectedOrderId))).json.order;orderIds.push(initial.id);
      ok(initial.checks.length===0 && initial.completions.length===0,sample.sample_id+': creation did not invoke a model or fabricate a check');
      await page.waitForURL(u=>u.origin===BASE && u.searchParams.get('order')===initial.id);
      await settle(page);await page.locator(`[data-action="language"][data-lang="${language}"]`).click();await settle(page);
      await page.waitForFunction(()=>document.querySelector('.photo-frame img')?.naturalWidth>0);
      ok((await page.locator('.notice-banner').first().innerText()).includes(language==='zh'?'公开照片演示':'공개 사진 데모'),sample.sample_id+': source/physical boundary banner displayed');
      let order=await inspectOnce(page,sample.sample_id,1);
      if(sample.sample_id==='bag-revision') {
        const actual=order.latest_check;
        notes.push({sample:sample.sample_id,scenario_expectation:'BOM bolt=3, public scene intended bolt=2; intended demonstration is add one bolt. This is not asserted as the model outcome.',actual_decision:actual?.decision??null,actual_bolt_difference:actual?.differences?.find(d=>d.part==='bolt')??null});
        await reviseBag(page,order);order=await inspectOnce(page,sample.sample_id,2);
      }
      write('orders/'+sample.sample_id+'-final.json',order);
      await page.setViewportSize({width:390,height:844});await page.locator('.workspace-heading').scrollIntoViewIfNeeded();
      ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),sample.sample_id+': actual mobile workspace has no page overflow');
      await screenshot(page,sample.sample_id+'-mobile');await page.setViewportSize({width:1440,height:900});
    }
    const actualPosts=events.filter(e=>e.kind==='browser_request'&&e.method==='POST');
    ok(actualPosts.filter(e=>e.url.endsWith('/inspect')).length===inspectClicks && inspectClicks===4,'exactly four explicit UI inspect actions, no automatic extra inference');
    ok(actualPosts.filter(e=>e.url.endsWith('/propose-revision')).length===proposalClicks && proposalClicks===1,'one explicit real Korean proposal request; not hidden inside four inspection calls');
    ok(actualPosts.every(e=>!e.url.endsWith('/complete')),'no physical-completion requests');
    ok(actualPosts.filter(e=>e.url.endsWith('/revise')).length===revisionClicks && actualPosts.filter(e=>e.url.endsWith('/photos')).length===uploadActions,'revision and reupload match explicit recorded UI actions');
    const finalOrders=(await get('/api/orders')).json.orders;
    ok(finalOrders.length===3 && finalOrders.every(o=>o.completions.length===0),'all three persisted public demos remain uncompleted');
    ok(errors.length===0,'no browser JavaScript errors');
    write('model-after.json',(await get('/api/health')).json.model);
  } catch(error) {
    fatal=String(error.stack||error);console.error(fatal);process.exitCode=1;
    if(activeInspection) {
      outcomes.push({sample:activeInspection.sample,revision:activeInspection.revision,order_id:activeInspection.order_id,http_status:activeInspection.http_status,request_wall_ms:null,actual_elapsed_ms:null,click_to_result_ms:performance.now()-activeInspection.started,response:null,check_latency_ms:null,check_id:null,runtime_mode:null,backend:null,decision:null,status:'execution_error',dispatched:activeInspection.dispatched,error:fatal,note:'The request did not produce a saved result before interruption. No clear outcome is inferred; the server may still be running.'});
      write('outcomes.json',outcomes);
    }
    if(activeInstruction) {
      instructionOutcome={sample:'bag-revision',order_id:activeInstruction.order_id,instruction:activeInstruction.instruction,model_task:'instruction_proposal',http_status:activeInstruction.http_status,actual_elapsed_ms:null,click_to_result_ms:performance.now()-activeInstruction.started,status:'execution_error',response:null,proposal:null,approval:null,fallback_used:false,dispatched:activeInstruction.dispatched,error:fatal,note:'No complete proposal response was saved before interruption; no model success or approval inferred.'};
      write('instruction-outcome.json',instructionOutcome);
    }
  }
  finally {
    await Promise.allSettled(receiptTasks);
    if(context) await context.close();
    if(video) {try {await video.saveAs(path.join(out,'candidate-real-api-raw.webm'));} catch(error) {notes.push({video_error:String(error)});}}
    if(browser) await browser.close();
    if(fs.existsSync(path.join(out,'candidate-real-api-raw.webm'))) {
      const conversion=spawnSync(path.join(ROOT,'.venv/bin/python'),[path.join(HERE,'finish_video.py'),'--directory',out],{encoding:'utf8'});
      fs.writeFileSync(path.join(out,'video-conversion.stdout.txt'),conversion.stdout||'');
      fs.writeFileSync(path.join(out,'video-conversion.stderr.txt'),conversion.stderr||'');
      if(conversion.status!==0) notes.push({video_conversion_exit:conversion.status,note:'Raw WebM retained; consult video conversion metadata.'});
    }
    const sourceAfter=Object.fromEntries(Object.keys(server.source_sha256).map(name=>[name,fs.existsSync(path.join(ROOT,name))?sha(fs.readFileSync(path.join(ROOT,name))):null]));
    const sourceChanged=Object.keys(sourceAfter).some(name=>sourceAfter[name]!==server.source_sha256[name]);
    const attempted=events.filter(e=>e.kind==='browser_request'&&e.method==='POST'&&e.url.endsWith('/inspect')).length;
    const attemptedInstructions=events.filter(e=>e.kind==='browser_request'&&e.method==='POST'&&e.url.endsWith('/propose-revision')).length;
    write('result.json',{label:'candidate real API verification',status:fatal?'interrupted_or_failed':outcomes.some(o=>o.status==='execution_error')||instructionOutcome?.status==='execution_error'?'completed_with_execution_errors':'completed',started_at:startedAt,finished_at:new Date().toISOString(),planned_samples:3,planned_inspections:4,planned_instruction_calls:1,planned_model_requests:5,attempted_inspections:attempted,attempted_instruction_calls:attemptedInstructions,attempted_model_requests:attempted+attemptedInstructions,explicit_inspect_clicks:inspectClicks,explicit_proposal_clicks:proposalClicks,passed_engineering_assertions:checks.length,checks,errors,failed_requests:failures,fatal,orderIds,outcomes,instruction_outcome:instructionOutcome,notes,source_sha256_before:server.source_sha256,source_sha256_after:sourceAfter,source_changed_during_run:sourceChanged,http_receipts:receipts.map(r=>({id:r.id,route:r.route,method:r.method,status:r.status,file:'http/'+r.id+'.json'})),runtime_configuration:server,scope:'Four planned UI-triggered visual inspections plus one separately counted Korean instruction proposal on three previously used public development examples. Each visual request internally uses correlated model passes; five API model requests do not mean five generation passes. Explicit approval clicks are automated UI operations, not human-study observations. Raw video includes real waiting; no speed-up, fake observations, retries, physical completion, accuracy estimate, default-adoption claim, or field validation. A failed/mismatched proposal may use a disclosed structured fallback, never counted as proposal success. R2 repeats the same source PNG, only the order changed. Crop digest metadata is preserved; crop bytes are not exported by production ZIP.'});
    console.log(JSON.stringify({status:fatal?'failed':'finished',output:out,attempted:outcomes.length,assertions:checks.length,sourceChanged,rawVideo:path.join(out,'candidate-real-api-raw.webm')}));
  }
})();
