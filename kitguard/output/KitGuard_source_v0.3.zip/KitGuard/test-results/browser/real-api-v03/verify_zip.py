"""CPU-only verification of an actual API ZIP against its saved order snapshot."""

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path, PurePosixPath


def verify(archive_path, order_path):
    expected = json.loads(order_path.read_text())
    with zipfile.ZipFile(archive_path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate archive entries")
        for name in names:
            relative = PurePosixPath(name)
            if relative.is_absolute() or ".." in relative.parts or "\\" in name:
                raise ValueError("Unsafe archive path")
        manifest = json.loads(archive.read("SHA256.json"))
        if len({item["path"] for item in manifest}) != len(manifest):
            raise ValueError("Duplicate manifest entries")
        for item in manifest:
            data = archive.read(item["path"])
            if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
                raise ValueError(f"Digest mismatch: {item['path']}")
        payload = json.loads(archive.read("evidence.json"))
        if payload["order"] != expected:
            raise ValueError("ZIP order differs from the actual saved API order")
        if payload["order"]["completions"] or not payload["order"].get("demo_source"):
            raise ValueError("Expected an uncompleted public demo")
        photos = {p["id"]: p for p in payload["photos"]}
        for photo in photos.values():
            if photo["archive_path"] != f"photos/{photo['id']}.jpg":
                raise ValueError("Unexpected photo path")
            if hashlib.sha256(archive.read(photo["archive_path"])).hexdigest() != photo["sha256"]:
                raise ValueError("Photo metadata does not match the archived bytes")
        checks = []
        for check in expected["checks"]:
            photo = photos[check["photo_id"]]
            if check["photo_sha256"] != photo["sha256"]:
                raise ValueError("Check/photo binding differs")
            identity = check.get("identity_verification")
            if identity:
                if identity["source_sha256"] != photo["sha256"]:
                    raise ValueError("Identity/photo binding differs")
                for crop in identity["crops"]:
                    if crop["source_sha256"] != photo["sha256"]:
                        raise ValueError("Crop source binding differs")
                    for key in ("crop_sha256", "pixel_crop_sha256"):
                        if not re.fullmatch("[0-9a-f]{64}", crop[key]):
                            raise ValueError("Invalid recorded crop digest")
            checks.append({"check_id": check["id"], "revision": check["revision"],
                           "mode": check.get("runtime_identity", {}).get("observation_mode"),
                           "identity_metadata_preserved": bool(identity)})
        return {"status": "verified", "archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
                "members": names, "hashed_members": len(manifest), "order_id": expected["id"], "checks": checks,
                "scope": "Archive byte hashes and stored API metadata equality only. Crop images are not included by the production exporter; their stored digest strings are preserved, not independently reverified here. Public photos do not prove physical action."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--order-json", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = verify(args.archive, args.order_json)
    with args.output.open("x") as handle:
        handle.write(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
