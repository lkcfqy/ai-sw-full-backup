# v0.3 真实 API 实录：完成与验证记录

状态：`completed`。独立 8774 服务已停止，GPU 已释放。运行明确标记为 candidate real API verification；采用结论由项目冻结研究门槛单独维护。

## 实际执行

| 操作 | 实际 HTTP / 结果 | 实际请求耗时 |
|---|---|---|
| bag-revision R1 | 200 / correct | 51.492 秒 |
| bag-revision R2 | 200 / ready | 48.922 秒 |
| small-part R1 | 200 / recapture | 21.644 秒 |
| mixed-screws R1 | 200 / ready | 15.908 秒 |
| 韩语自然语言提案 | 200 / proposal_returned，无结构回退 | 7.924 秒 |

计划 4 次视觉核验 + 1 次语言提案，实际全部执行。视觉请求内部包含同模型相关调用，不能把 API 请求数当成模型生成次数或独立样本数。86 项工程断言通过，页面 JS 异常 0、失败请求 0、源码首尾变化 false。

韩语提案实际给出 `2/2/2/0`，生成提案没有修改工单，随后脚本通过真实界面点击批准。这里的批准是自动化操作显式批准控件，不是真人实验。R1 检查随后失效；R2 重新上传同一公开 PNG 才可检查，没有新增现场照片，也没有添加或移走实物。三个工单的完成记录均为零。

小零件实际进入补拍：首轮类别为 washer，局部身份复核返回 nut，程序将 nut 和 washer 两类设为未确认。没有自动改数，也没有将拒绝/补拍隐藏成成功。

## 文件与检查

- `browser/result.json`：真实 API 回执汇总；完整请求/响应位于 `browser/http/`。
- `browser/archives/`：4 个实际下载 ZIP 全部通过字节摘要、照片绑定和工单历史一致性校验。袋装 R2 的 ZIP 还包含已失效 R1 记录；重复快照不累计为额外核验。
- `browser/candidate-real-api-raw.webm`：原始完整录像。
- `browser/candidate-real-api.mp4`：完整 H.264 MP4。两者均为 152.08 秒，未剪切、未加速、未删除等待。
- `browser/video-metadata.json`：真实编码器命令、源码来源、文件 SHA、时长与编码元数据。当前无 ffprobe，使用实际 ffmpeg -i 检查，未冒称 ffprobe。
- `browser/screenshots/` 与 `browser/visual-qa.json`：桌面、韩语提案、身份冲突及手机截图；10 张截图和 5 个录像代表帧已目视检查。

一个非阻塞显示细节：390px 小零件照片右上角的区域说明标签文字局部裁剪。完整动作说明仍保存在界面后续区域和证据中；未修改冻结 UI 掩盖这个细节。

## v1 → v2 的唯一差异

v1 在创建首个工单后，图库真实跳转导致 Chrome 丢弃创建响应的 body，脚本读 `created.json()` 失败。发生时视觉与语言模型调用均为零，工单无检查、无完成。v1 的失败 result、HTTP、2.08 秒 WebM/MP4、旧脚本及旧 PLAN_FREEZE 完整保留。

根任务明确授权后，v2 只把读取方式改为：从真实跳转 URL 取得 order_id，再 GET 实际订单。`SCRIPT_DIFFERENCE.diff` 展示三行替换；模型、提示词、图像、样例、提案和核验计划均不变，没有按模型结果选择重试。新 PLAN_FREEZE 链接旧计划 SHA 与零模型调用失败原因。

这是功能联通性、证据追溯和实际时延记录，不是新测试集，也不能证明现场物料变化、真人效率或夺冠概率。
