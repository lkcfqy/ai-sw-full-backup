"""Synthetic byte-level ZIP verifier checks only; no server, photograph or model."""

import hashlib
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from verify_zip import verify


class ArchiveChecks(unittest.TestCase):
    def fixture(self, root, *, wrong_photo_metadata=False, corrupt_member=False):
        image = b"ENGINEERING_SYNTHETIC_BYTES_NOT_A_PHOTOGRAPH"
        digest = hashlib.sha256(image).hexdigest()
        metadata_digest = "0" * 64 if wrong_photo_metadata else digest
        photo = {"id": "photo_test", "archive_path": "photos/photo_test.jpg", "sha256": metadata_digest}
        check = {"id": "check_test", "photo_id": photo["id"], "photo_sha256": metadata_digest,
                 "revision": 1, "runtime_identity": {"observation_mode": "spatial_guarded"}}
        order = {"id": "order_engineering_only", "checks": [check], "completions": [],
                 "demo_source": {"kind": "synthetic_verifier_fixture"}}
        payload = {"order": order, "photos": [photo]}
        entries = {photo["archive_path"]: image, "evidence.json": json.dumps(payload).encode(),
                   "OPEN_ME.html": b"Engineering byte verification fixture, no model result"}
        manifest = [{"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                    for name, data in entries.items()]
        archive_path, order_path = root / "test.zip", root / "order.json"
        with zipfile.ZipFile(archive_path, "w") as archive:
            for name, data in entries.items():
                archive.writestr(name, data + b"TAMPER" if corrupt_member and name.endswith(".jpg") else data)
            archive.writestr("SHA256.json", json.dumps(manifest))
        order_path.write_text(json.dumps(order))
        return archive_path, order_path

    def test_valid_fixture(self):
        with tempfile.TemporaryDirectory(prefix="kitguard-zip-cpu-") as temp:
            paths = self.fixture(Path(temp))
            result = verify(*paths)
            self.assertEqual(result["status"], "verified")
            self.assertEqual(len(result["checks"]), 1)

    def test_changed_member_fails(self):
        with tempfile.TemporaryDirectory(prefix="kitguard-zip-cpu-") as temp:
            paths = self.fixture(Path(temp), corrupt_member=True)
            with self.assertRaisesRegex(ValueError, "Digest mismatch"):
                verify(*paths)

    def test_metadata_sha_cannot_differ_from_bytes(self):
        with tempfile.TemporaryDirectory(prefix="kitguard-zip-cpu-") as temp:
            paths = self.fixture(Path(temp), wrong_photo_metadata=True)
            with self.assertRaisesRegex(ValueError, "Photo metadata"):
                verify(*paths)

    def test_history_difference_fails(self):
        with tempfile.TemporaryDirectory(prefix="kitguard-zip-cpu-") as temp:
            archive, order = self.fixture(Path(temp))
            value = json.loads(order.read_text())
            value["checks"][0]["revision"] = 2
            order.write_text(json.dumps(value))
            with self.assertRaisesRegex(ValueError, "differs from"):
                verify(archive, order)


if __name__ == "__main__":
    unittest.main(verbosity=2)
