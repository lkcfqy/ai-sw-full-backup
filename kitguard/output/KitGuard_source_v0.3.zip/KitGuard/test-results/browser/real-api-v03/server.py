"""Candidate real API verification on 8774, with a new isolated database.

Run only after the root task confirms that the GPU is free. No observations are
injected: LocalVision loads weights lazily after a real /inspect request.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
from datetime import UTC, datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="New directory inside this script's runs/")
    parser.add_argument("--model-path", type=Path, default=Path.home() / "Downloads/AI-Models/Qwen3.6-27B-4bit")
    parser.add_argument("--execute-real-model", action="store_true", help="Use only after GPU-free authorization")
    parser.add_argument("--validate-only", action="store_true", help="Check configuration only; no imports, server or model")
    args = parser.parse_args()
    output = args.output.expanduser().resolve()
    if not output.is_relative_to(HERE / "runs") or output == HERE / "runs":
        parser.error("Output must be a new named child of test-results/browser/real-api-v03/runs")
    if output.exists():
        parser.error("Output already exists; preserve the earlier attempt and select a new directory")
    model = args.model_path.expanduser().resolve()
    config = {
        "label": "candidate real API verification", "default_adoption_claim": False,
        "base_url": "http://127.0.0.1:8774", "pid": os.getpid(),
        "data_dir": str(output / "data"), "output_dir": str(output),
        "observation_mode": "spatial_guarded", "image_max_side": 1536,
        "model_path": str(model), "inference_timeout_seconds": 300,
        "created_at": datetime.now(UTC).isoformat(),
        "scope": "Three existing public development demos, no holdout images or physical completion. Same-model correlated calls; not field validation or model accuracy evaluation.",
    }
    if args.validate_only:
        print(json.dumps(config, ensure_ascii=False, indent=2))
        return
    if not args.execute_real_model:
        parser.error("Real execution requires --execute-real-model and prior root GPU-free notification")
    freeze_path = HERE / "PLAN_FREEZE.json"
    if not freeze_path.is_file():
        parser.error("No prepared script freeze exists")
    freeze = json.loads(freeze_path.read_text())
    for name, digest in freeze["script_sha256"].items():
        if Path(name).name != name or hashlib.sha256((HERE / name).read_bytes()).hexdigest() != digest:
            parser.error(f"Prepared script hash changed: {name}; preserve and explicitly refreeze before execution")
    config["plan_freeze_sha256"] = hashlib.sha256(freeze_path.read_bytes()).hexdigest()
    config["planned_inspections"] = 4
    config["planned_instruction_calls"] = 1
    config["planned_model_requests"] = 5
    # Parsing/--help/--validate-only above never import the inference module.
    sys.path.insert(0, str(ROOT))
    import uvicorn

    from kitguard.app import create_app
    from kitguard.models import PROFILES
    from kitguard.vision import LocalVision

    engine = LocalVision(model_path=model, observation_mode="spatial_guarded", image_max_side=1536)
    config["model_before"] = engine.status()
    expected = PROFILES["Qwen3.6-27B-4bit"]
    if any(config["model_before"][key] != expected[key] for key in ("repo_id", "revision")):
        parser.error("This candidate verification requires the pinned 27B profile")
    if not config["model_before"]["available"]:
        parser.error("The real pinned local model is unavailable; no substitute is allowed")
    output.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(freeze_path, output / "PLAN_FREEZE.json")
    sources = sorted((ROOT / "kitguard").glob("*.py")) + sorted((ROOT / "kitguard/static").glob("*"))
    sources += [HERE / name for name in ("server.py", "browser.cjs", "verify_zip.py", "finish_video.py")]
    hashes = {}
    for source in sources:
        if not source.is_file():
            continue
        relative = source.relative_to(ROOT)
        target = output / "source_snapshot" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        hashes[str(relative)] = hashlib.sha256(target.read_bytes()).hexdigest()
    config["source_sha256"] = hashes
    (output / "server.json").write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n")
    app = create_app(data_dir=output / "data", analyzer=engine, inference_timeout=300, demo_dataset_root=ROOT / "datasets")
    uvicorn.run(app, host="127.0.0.1", port=8774, access_log=True)


if __name__ == "__main__":
    main()
