"""Transcode the entire actual raw recording to H.264 MP4; do not cut or speed up."""

import argparse
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BUNDLED_ENCODER = ROOT / ".tools/imageio-ffmpeg/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1"
BUNDLED_SHA256 = "6d175a4743ca50256e89a8cdd731100f9cee33bd79aeea46894d209410dc6617"


def inspect_video(file, ffmpeg, ffprobe):
    if ffprobe:
        command = [ffprobe, "-v", "error", "-show_format", "-show_streams", "-of", "json", str(file)]
        probe = subprocess.run(command, capture_output=True, text=True, check=False)
        if probe.returncode == 0:
            payload = json.loads(probe.stdout)
            return {"method": "ffprobe", "command": command, "exit_code": 0, "metadata": payload,
                    "duration_seconds": float(payload["format"]["duration"])}
    # No ffprobe is bundled here. Explicitly record the different inspection tool.
    command = [ffmpeg, "-hide_banner", "-i", str(file)]
    probe = subprocess.run(command, capture_output=True, text=True, check=False)
    match = re.search(r"Duration:\s*(\d+):(\d+):([0-9.]+)", probe.stderr)
    duration = int(match[1]) * 3600 + int(match[2]) * 60 + float(match[3]) if match else None
    return {"method": "ffmpeg_input_inspection", "ffprobe_run": False, "command": command,
            "exit_code": probe.returncode, "duration_seconds": duration, "metadata_text": probe.stderr,
            "note": "ffmpeg -i without output normally exits 1. Duration is parsed from its actual container metadata at the displayed precision; this is not a ffprobe result."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, required=True)
    args = parser.parse_args()
    root = args.directory.resolve()
    raw, target = root / "candidate-real-api-raw.webm", root / "candidate-real-api.mp4"
    output = root / "video-metadata.json"
    if target.exists() or output.exists():
        parser.error("Video output exists; never overwrite a recording")
    result = {"scope": "Entire raw browser recording; no cut, speed change, waiting removal or success montage.",
              "raw": str(raw), "mp4": str(target), "status": "not_converted"}
    ffmpeg, ffprobe = shutil.which("ffmpeg"), shutil.which("ffprobe")
    if not ffmpeg and BUNDLED_ENCODER.is_file():
        if hashlib.sha256(BUNDLED_ENCODER.read_bytes()).hexdigest() != BUNDLED_SHA256:
            parser.error("Existing bundled encoder hash differs from its saved source record")
        ffmpeg = str(BUNDLED_ENCODER)
        result["encoder_provenance"] = str(ROOT / "test-results/audit/video_encoder_source.json")
    if not raw.is_file():
        parser.error("No actual raw WebM exists")
    result["raw_sha256"] = hashlib.sha256(raw.read_bytes()).hexdigest()
    if not ffmpeg:
        result["reason"] = "Existing ffmpeg not found; raw recording remains unchanged"
    else:
        result["encoder_sha256"] = hashlib.sha256(Path(ffmpeg).read_bytes()).hexdigest()
        result["ffprobe_available"] = bool(ffprobe)
        command = [ffmpeg, "-n", "-i", str(raw), "-map", "0:v:0", "-map", "0:a?",
                   "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20", "-preset", "fast",
                   "-c:a", "aac", "-movflags", "+faststart", str(target)]
        result["command"] = command
        process = subprocess.run(command, capture_output=True, text=True, check=False)
        (root / "ffmpeg.stdout.txt").write_text(process.stdout)
        (root / "ffmpeg.stderr.txt").write_text(process.stderr)
        result["ffmpeg_exit_code"] = process.returncode
        for key, file in (("raw_inspection", raw), ("mp4_inspection", target)):
            if file.is_file():
                result[key] = inspect_video(file, ffmpeg, ffprobe)
        if process.returncode == 0:
            result["status"] = "converted"
            result["mp4_sha256"] = hashlib.sha256(target.read_bytes()).hexdigest()
            before = result["raw_inspection"]["duration_seconds"]
            after = result["mp4_inspection"]["duration_seconds"]
            result["duration_difference_seconds"] = after - before if before is not None and after is not None else None
            result["duration_preserved_within_0_2_seconds"] = abs(after - before) <= 0.2 if before is not None and after is not None else None
    with output.open("x") as stream:
        stream.write(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "metadata": str(output)}))


if __name__ == "__main__":
    main()
