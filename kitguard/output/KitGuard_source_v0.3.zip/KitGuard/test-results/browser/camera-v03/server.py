"""Isolated actual API for UI capture tests. No model loaded or fake successes."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from kitguard.app import create_app  # noqa: E402


class NoInference:
    def status(self):
        return {"available": False, "loaded": False, "label": "ENGINEERING CAPTURE TEST — NO MODEL", "path": "test-only", "error": "Inference intentionally unavailable in capture UI test"}

    def observe(self, *args, **kwargs):
        raise RuntimeError("No inference permitted in camera UI test")

    def propose_revision(self, *args, **kwargs):
        raise RuntimeError("No inference permitted in camera UI test")


app = create_app(data_dir=Path(__file__).parent / "data", analyzer=NoInference())
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8771)
