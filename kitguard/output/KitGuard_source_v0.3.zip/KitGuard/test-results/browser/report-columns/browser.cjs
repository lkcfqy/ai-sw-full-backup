const fs=require('node:fs'),assert=require('node:assert/strict');
const {chromium}=require('/Users/lkc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const base=__dirname,dist='/Users/lkc/Downloads/AI·SW/kitguard/reports/self-evaluation/dist';
const manifest=JSON.parse(fs.readFileSync(dist+'/data-app-build.json','utf8'));
const snapshot=JSON.parse(fs.readFileSync(dist+'/'+manifest.snapshot.path,'utf8')),runs=snapshot.queries.benchmark_runs.rows;
(async()=>{const browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});const page=await browser.newPage({viewport:{width:1440,height:1000}});const checks=[],errors=[];page.on('pageerror',e=>errors.push(String(e)));const ok=(v,n)=>{assert.ok(v,n);checks.push(n)};
try{
 await page.goto('http://127.0.0.1:4173/',{waitUntil:'networkidle'});await page.locator('.kg-report').waitFor();
 const table=page.getByRole('table',{name:'全部真实图像核验运行',exact:true});
 ok(await table.locator('tbody tr').count()===runs.length,'each reviewed visual run retained as a separate row');
 const app=table.locator('tbody tr').filter({hasText:'loco_development_8b_app_dual_v1'}),appText=await app.innerText();
 ok(appText.includes('7 / 16')&&appText.includes('8 / 16')&&appText.includes('1 / 8'),'app-upload dual exact coverage and shared-error results distinct');
 ok(appText.includes('dual_orientation / app-upload'),'model input protocol retained');
 ok((await page.locator('.report-summary').innerText()).includes('1 / 8'),'shared error is visible in stage summary');
 ok(!((await table.innerText()).includes('0 / 0')),'zero denominator not presented as accuracy');
 const nominal=page.getByRole('table',{name:'正常构成订单下的派生任务',exact:true});
 const nominalRows=runs.filter(r=>typeof r.nominalAnomalyTotal==='number');
 ok(await nominal.locator('tbody tr').count()===nominalRows.length,'only reviewed nominal rows shown');
 for(const row of nominalRows){const cells=nominal.locator('tbody tr').filter({hasText:row.run}).locator('td');const values=await cells.allTextContents();ok(values[1].trim()===`${row.nominalNormalReady} / ${row.nominalNormalTotal}`&&values[2].trim()===`${row.nominalAnomalyFalseReady} / ${row.nominalAnomalyTotal}`&&values[3].trim()===`${row.nominalAnomalyCorrect} / ${row.nominalAnomalyTotal}`,`nominal numerators and denominators match ${row.run}`)}
 const subgroup=page.getByRole('table',{name:'分组完整计数与固定构成对照',exact:true});
 const grouped=runs.filter(r=>typeof r.normalImages==='number');ok(await subgroup.locator('tbody tr').count()===grouped.length,'only reviewed subgroup rows shown');
 for(const row of grouped){const values=await subgroup.locator('tbody tr').filter({hasText:row.run}).locator('td').allTextContents();ok(values[1].trim()===`${row.normalExact} / ${row.normalImages}`&&values[2].trim()===`${row.anomalyExact} / ${row.anomalyImages}`&&values[3].trim()===`${row.constantNominalExact} / ${row.constantNominalImages}`,`subgroup numerators and baseline match ${row.run}`)}
 const articleText=await page.locator('.kg-report').innerText();ok(articleText.includes('同模型对原图和旋转图的观察具有相关性')&&articleText.includes('不等于风险为零'),'correlation and zero-error interpretation limits explicit');
 ok(!articleText.includes('正常构成与数量异常的分组结果待汇入'),'pending placeholder removed when real data exists');
 const eng=page.getByRole('table',{name:'工程验证记录',exact:true});const et=await eng.innerText();ok(et.includes('test-results/browser/audit-details/result.json')&&et.includes('test-results/browser/evidence-feedback/result.json'),'archived engineering evidence paths displayed');ok(!et.includes('/tmp/'),'engineering evidence paths are durable');
 await table.scrollIntoViewIfNeeded();await page.screenshot({path:base+'/01-desktop-visual-runs.png'});
 await nominal.scrollIntoViewIfNeeded();await page.screenshot({path:base+'/03-desktop-nominal.png'});
 await page.getByRole('button',{name:'正常构成订单下的派生任务 actions',exact:true}).click();await page.getByRole('menuitem',{name:'View data source',exact:true}).click();await page.getByText('Overview',{exact:true}).waitFor();ok((await page.locator('body').innerText()).includes('Evidence flow'),'nominal table source inspector works');await page.screenshot({path:base+'/04-nominal-source.png'});await page.getByRole('button',{name:'Close data source',exact:true}).first().click();await page.getByRole('button',{name:'Close data source',exact:true}).first().waitFor({state:'hidden'});
 await page.setViewportSize({width:390,height:844});await nominal.scrollIntoViewIfNeeded();ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'mobile report has no page overflow');ok(await nominal.evaluate(el=>{let p=el.parentElement;while(p&&p.scrollWidth<=p.clientWidth+1)p=p.parentElement;if(!p)return false;p.scrollLeft=p.scrollWidth;return p.scrollLeft>0}),'nominal table scrolls internally on mobile');await page.screenshot({path:base+'/05-mobile-nominal.png'});
 await subgroup.scrollIntoViewIfNeeded();await page.screenshot({path:base+'/06-mobile-subgroups.png'});ok(errors.length===0,'zero browser JavaScript errors');
 fs.writeFileSync(base+'/result.json',JSON.stringify({passed:checks.length,checks,errors,scope:'Compiled report with reviewed development rows. No model calls; holdout results not supplied yet. This is a repeat of the report UI group, not independent evaluation samples.',buildManifest:manifest},null,2));console.log(JSON.stringify({passed:checks.length,checks,errors}));
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});
