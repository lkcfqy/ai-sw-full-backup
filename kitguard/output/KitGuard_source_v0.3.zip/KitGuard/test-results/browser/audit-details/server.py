"""Isolated engineering UI fixture only; no real model or production data."""
import sys
from pathlib import Path
sys.path.insert(0, '/Users/lkc/Downloads/AI·SW/kitguard')
sys.path.insert(0, '/Users/lkc/Downloads/AI·SW/kitguard/tests')
from conftest import FakeAnalyzer, REQUIREMENTS
from kitguard.app import create_app
import uvicorn
analyzer = FakeAnalyzer()
analyzer.result = analyzer.observation(REQUIREMENTS)
app = create_app(data_dir=Path('/tmp/kitguard-audit-ui-qa/data'), analyzer=analyzer)
uvicorn.run(app, host='127.0.0.1', port=8768)
