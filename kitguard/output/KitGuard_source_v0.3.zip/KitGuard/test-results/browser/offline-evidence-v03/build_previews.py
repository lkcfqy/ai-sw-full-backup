"""Re-render a COPY of the frozen demo plus explicit safety engineering fixtures."""
import hashlib
import json
import runpy
import shutil
import sys
from copy import deepcopy
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from kitguard.evidence import render_viewer

OUT = Path(__file__).resolve().parent
SOURCE = ROOT / 'output/demo/offline-evidence'
ZIP = ROOT / 'output/demo/PUBLIC_PHOTO_DEMO_evidence.zip'
hash_file = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = {str(p.relative_to(ROOT)): hash_file(p) for p in [ZIP, *SOURCE.rglob('*')] if p.is_file()}
real = OUT / 'real-demo-copy'
shutil.copytree(SOURCE, real, dirs_exist_ok=True)
payload = json.loads((real / 'evidence.json').read_text())
(real / 'OPEN_ME.html').write_text(render_viewer(payload), encoding='utf-8')
manifest = json.loads((real / 'SHA256.json').read_text())
for record in manifest:
    path = real / record['path']
    record.update(bytes=path.stat().st_size, sha256=hash_file(path))
(real / 'SHA256.json').write_text(json.dumps(manifest, indent=2)+'\n')

fixture = OUT / 'synthetic-engineering'
(fixture / 'photos').mkdir(parents=True, exist_ok=True)
image = Image.new('RGB', (640, 480), '#edf3e9')
draw = ImageDraw.Draw(image)
draw.rectangle((60, 70, 205, 155), fill='#204f43')
draw.text((34, 225), 'SYNTHETIC ENGINEERING FIXTURE ONLY', fill='black')
draw.text((34, 250), 'Not a real scene or a model prediction', fill='black')
image.save(fixture / 'photos/synthetic-photo.jpg', quality=90)
fixture_payload = runpy.run_path(str(ROOT/'tests/test_evidence_archive_v03.py'))['report_payload'].__wrapped__()
digest = hash_file(fixture/'photos/synthetic-photo.jpg')
fixture_payload['photos'][0]['sha256'] = digest
first = fixture_payload['order']['checks'][0]
first['photo_sha256'] = digest
attack = '</pre><script>alert(17)</script><img src=https://example.invalid/x onerror=alert(18)>'
first['action']['message'] = attack
first['model_label'] += ' / ' + attack
first['evidence_feedback'] = {
    'outcome':'still_uncertain', 'message': 'SYNTHETIC: one observation is still unknown. ' + attack,
    'previous_check_id':'synthetic-prior-check', 'previous_photo_id':'synthetic-prior-photo',
    'resolved_uncertainties':[], 'remaining_uncertainties':['bolt'], 'remaining_mismatches':['nut'],
    'observed_changes':[{'part':'nut','before':0,'after':1}], 'physical_action_verified':False,
}
missing = deepcopy(first)
missing.update(id='synthetic-missing-snapshot', revision=0, valid=None)
missing.pop('requirements_snapshot')
missing.pop('object_evidence')
missing.pop('observation_verification')
missing.pop('evidence_feedback')
missing['model_label'] = 'SYNTHETIC LEGACY RECORD'
missing['action'] = {'kind':'manual','message':'SYNTHETIC missing historical snapshot'}
ready = deepcopy(first)
ready.update(id='synthetic-ready', revision=9, valid=True, decision='ready')
ready['requirements_snapshot'] = {'bolt':1,'nut':1,'washer':0,'bracket':0}
ready['observed'] = deepcopy(ready['requirements_snapshot'])
ready['action'] = {'kind':'none','message':'SYNTHETIC: still requires personal physical confirmation'}
ready.pop('object_evidence')
ready.pop('observation_verification')
ready.pop('evidence_feedback')
fixture_payload['order']['checks'] += [missing,ready]
fixture_payload['order']['demo_source'] = {
    'kind':'public_photo_demo', 'sample_id':'SYNTHETIC-PROVENANCE-TEST', 'source_case_id':'synthetic-case',
    'source_url':'https://example.invalid/never-request-this', 'license':'SYNTHETIC LICENSE FIELD TEST',
    'source_sha256': digest, 'source_note':'Engineering fixture only; not an actual public dataset. '+attack,
}
fixture_payload['photos'].extend([
    {'id':'unsafe', 'archive_path':'https://example.invalid/unsafe.jpg'},
    {'id':'traversal', 'archive_path':'../../secret.jpg'},
])
(fixture / 'evidence.json').write_text(json.dumps(fixture_payload, ensure_ascii=False, indent=2)+'\n')
(fixture / 'OPEN_ME.html').write_text(render_viewer(fixture_payload), encoding='utf-8')
(fixture / 'README.txt').write_text('SYNTHETIC ENGINEERING FIXTURE ONLY. No physical or model accuracy claim.\n')
fixture_manifest = [{'path':str(p.relative_to(fixture)), 'bytes':p.stat().st_size, 'sha256':hash_file(p)} for p in [fixture/'photos/synthetic-photo.jpg', fixture/'evidence.json', fixture/'OPEN_ME.html']]
(fixture / 'SHA256.json').write_text(json.dumps(fixture_manifest, indent=2)+'\n')

after = {str(p.relative_to(ROOT)): hash_file(p) for p in [ZIP, *SOURCE.rglob('*')] if p.is_file()}
assert before == after
for entry in json.loads((SOURCE/'SHA256.json').read_text()):
    if entry['path'] != 'OPEN_ME.html':
        assert hash_file(real/entry['path']) == entry['sha256']
report = {
    'scope':'New offline report previews only. Old v0.2 ZIP and files are untouched. Real demo is public-image inference, not physical replenishment.',
    'original_files_sha256':before, 'original_files_unchanged':before==after,
    'real_payload_unchanged':hash_file(real/'evidence.json') == hash_file(SOURCE/'evidence.json'),
    'viewer_sha256':hash_file(real/'OPEN_ME.html'),
    'engineering_fixture_note':'Unknown final counts, missing snapshot, old revision, untrusted text, two-direction disagreement, original point vs rotated point, public-demo provenance.',
}
(OUT/'preview-provenance.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'real':str(real/'OPEN_ME.html'), 'synthetic':str(fixture/'OPEN_ME.html'), 'original_files_unchanged':True}))
