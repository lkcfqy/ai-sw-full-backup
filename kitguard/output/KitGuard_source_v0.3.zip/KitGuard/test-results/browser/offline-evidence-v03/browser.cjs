const fs = require('node:fs');
const assert = require('node:assert/strict');
const {pathToFileURL} = require('node:url');
const {chromium} = require('/Users/lkc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const base = __dirname;
(async () => {
 const browser = await chromium.launch({headless:true, executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', args:['--disable-gpu']});
 const results=[];
 try {
  for (const sample of ['real-demo-copy','synthetic-engineering']) {
   for (const [device,viewport] of [['desktop',{width:1440,height:900}],['mobile',{width:390,height:844}]]) {
    const context = await browser.newContext({viewport,deviceScaleFactor:1,offline:true});
    const page=await context.newPage();
    const checks=[],requests=[],errors=[],dialogs=[];
    const ok=(value,label)=>{assert.ok(value,`${sample}/${device}: ${label}`);checks.push(label)};
    page.on('request',r=>requests.push({url:r.url(),method:r.method()}));
    page.on('pageerror',e=>errors.push(String(e)));
    page.on('dialog',async d=>{dialogs.push(d.message());await d.dismiss()});
    await page.goto(pathToFileURL(`${base}/${sample}/OPEN_ME.html`).href,{waitUntil:'load'});
    ok(await page.evaluate(()=>navigator.onLine===false),'Chrome context is offline');
    ok(await page.locator('script,iframe,form,button').count()===0,'no script, frame, form or mutation controls');
    await page.locator('details').evaluateAll(els=>els.forEach(el=>el.open=true));
    await page.locator('img').evaluateAll(async els=>{els.forEach(img=>img.loading='eager');await Promise.all(els.map(img=>img.decode()))});
    const images=await page.locator('img').evaluateAll(els=>els.map(el=>({src:el.getAttribute('src'),width:el.naturalWidth,height:el.naturalHeight,complete:el.complete})));
    ok(images.length>0 && images.every(im=>im.complete&&im.width>0&&im.height>0),'all local photographs decode after details expansion');
    const overflow=await page.evaluate(()=>({root:document.documentElement.scrollWidth>innerWidth+1,offenders:[...document.querySelectorAll('main,section,table,details,pre,.check-grid,.facts')].filter(el=>el.scrollWidth>el.clientWidth+2).map(el=>({tag:el.tagName,class:el.className,id:el.id,scroll:el.scrollWidth,width:el.clientWidth}))}));
    ok(!overflow.root && overflow.offenders.length===0,'no document, card, table or JSON horizontal overflow');
    const required=part=>page.locator(`#check-1 tr[data-part="${part}"] td[data-value="required"]`);
    if(sample==='real-demo-copy') {
     ok((await required('bolt').innerText())==='3','old R1 demand remains 3 while current R2 is 2');
     ok((await page.locator('#check-2 tr[data-part="bolt"] td[data-value="required"]').innerText())==='2','R2 demand is 2');
     ok((await page.locator('#check-1 .badge').innerText()).includes('false'),'old R1 validity is false');
     ok((await page.locator('#check-2 .decision').innerText()).includes('仍须本人确认实物'),'ready is visibly pending personal physical confirmation');
     ok((await page.locator('#check-1 tr[data-part="bolt"] td[data-value="delta"]').innerText())==='-1','R1 missing piece is explicit');
     ok((await page.locator('header h1').innerText()).includes('실물 검증 아님'),'recorded public-demo title retained');
     await page.locator('details').evaluateAll(els=>els.forEach(el=>el.open=false));
     await page.evaluate(()=>scrollTo(0,0));
     await page.screenshot({path:`${base}/${device}-real-overview.png`});
     await page.locator('#check-1').evaluate(el=>scrollTo(0,el.offsetTop-18));
     await page.screenshot({path:`${base}/${device}-real-r1.png`});
     await page.locator('#check-1 .counts').evaluate(el=>scrollTo(0,el.getBoundingClientRect().top+scrollY-18));
     await page.screenshot({path:`${base}/${device}-real-counts.png`});
     await page.locator('#check-2').evaluate(el=>scrollTo(0,el.offsetTop-18));
     await page.screenshot({path:`${base}/${device}-real-ready.png`});
    } else {
     ok((await page.locator('#check-1 tr[data-part="bolt"] td[data-value="observed"]').innerText()).includes('未确认'),'final unknown remains unknown despite original pass count');
     ok((await page.locator('#check-1 tr[data-verification-part="bolt"]').innerText()).includes('1\t2'),'two stored directional counts stay distinct');
     ok((await page.locator('#check-2 tr[data-part="nut"] td[data-value="required"]').innerText()).includes('未确认'),'legacy snapshot absence is not filled from current order');
     ok((await page.locator('#check-2 .badge').innerText()).includes('未确认'),'unknown validity is not converted to false');
     ok(await page.locator('.point').count()===1,'only one original point is drawn, no rotated point');
     ok((await page.locator('.point').getAttribute('style'))==='left:20.00000%;top:30.00000%','original coordinates only');
     ok((await page.locator('.demo-source').innerText()).includes('不能记为实体完工'),'public-demo completion boundary visible');
     ok(await page.locator('.demo-source a').count()===0,'source URL is inert text');
     ok((await page.locator('#check-1 .action').innerText()).includes('<script>alert(17)</script>'),'hostile source renders as literal text');
     await page.locator('details.raw,details.pass,.gallery details').evaluateAll(els=>els.forEach(el=>el.open=false));
     await page.locator('#check-1 .verification').evaluate(el=>scrollTo(0,el.getBoundingClientRect().top+scrollY-18));
     await page.screenshot({path:`${base}/${device}-synthetic-verification.png`});
     await page.locator('#check-1 .points').evaluate(el=>scrollTo(0,el.getBoundingClientRect().top+scrollY-18));
     await page.screenshot({path:`${base}/${device}-synthetic-original-points.png`});
     await page.locator('#check-2').evaluate(el=>scrollTo(0,el.offsetTop-18));
     await page.screenshot({path:`${base}/${device}-synthetic-legacy.png`});
    }
    ok(requests.every(r=>r.url.startsWith('file:')&&r.method==='GET'),'only file GET requests; no network or mutation request');
    ok(dialogs.length===0 && errors.length===0,'no executed hostile script, dialogs or page errors');
    results.push({sample,device,viewport,checksPassed:checks.length,checks,requests,errors,dialogs,images,overflow});
    await context.close();
   }
  }
  fs.writeFileSync(base+'/browser-results.json',JSON.stringify({createdAt:new Date().toISOString(),browserVersion:browser.version(),scope:'Actual Google Chrome file:// with offline contexts; real historical MLX demo copy and explicit synthetic safety fixtures; no new model inference.',checksPassed:results.reduce((sum,r)=>sum+r.checksPassed,0),results},null,2));
  console.log(JSON.stringify({runs:results.length,checksPassed:results.reduce((sum,r)=>sum+r.checksPassed,0)}));
 } finally {await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
