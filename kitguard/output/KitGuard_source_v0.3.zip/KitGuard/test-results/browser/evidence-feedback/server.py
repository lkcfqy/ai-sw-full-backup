"""Isolated synthetic engineering fixture; never competition or production data."""
import sys
from pathlib import Path
sys.path[:0] = ['/Users/lkc/Downloads/AI·SW/kitguard', '/Users/lkc/Downloads/AI·SW/kitguard/tests']
from conftest import FakeAnalyzer, REQUIREMENTS
from kitguard.app import create_app
import uvicorn
class SequenceAnalyzer(FakeAnalyzer):
    def __init__(self):
        super().__init__()
        self.sequence = 0
    def observe(self, image_path, requirements, references):
        self.sequence += 1
        observed = dict(REQUIREMENTS)
        observed['washer'] = [None, 1, 2][min(self.sequence - 1, 2)]
        return self.observation(observed, action='separate' if observed['washer'] is None else 'none')
analyzer = SequenceAnalyzer()
app = create_app(data_dir=Path('/tmp/kitguard-feedback-ui-qa/data'), analyzer=analyzer)
uvicorn.run(app, host='127.0.0.1', port=8768)
