// CPU-only authored-content checks. This is not a report renderer or model evaluation.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const compiler = require('/Users/lkc/.codex/plugins/cache/openai-curated-remote/data-analytics/1.0.11/assets/data-app-runtime/compiler.cjs');
const root = path.resolve(__dirname, '../../..');
const contentRoot = path.join(root, 'reports/self-evaluation/src/content/report');
const checks = [];
function test(name, run) { run(); checks.push({name, passed: true}); }
const files = ['V03Progress.jsx', 'ReportContent.jsx', 'v03-progress.css'];
const sources = Object.fromEntries(files.map(name => [name, fs.readFileSync(path.join(contentRoot, name), 'utf8')]));
let transformed;
for (const name of files) test(`official compiler parses ${name}`, () => {
  if (name.endsWith('.css')) compiler.parseCss(sources[name]);
  else {
    const code = compiler.transform(sources[name], {filePath: name});
    compiler.parseJavaScript(code);
    if (name === 'V03Progress.jsx') transformed = code;
  }
});
const jsx = (type, props) => ({type, props: props || {}});
const sdk = Object.fromEntries(['DataComponent','DataTable','ReportSection','RichNarrative'].map(name => [name, name]));
const moduleValue = {exports: {}};
vm.runInNewContext(transformed, {
  exports: moduleValue.exports,
  module: moduleValue,
  require: (name) => {
    if (name === 'react/jsx-runtime') return {jsx, jsxs: jsx, Fragment: 'Fragment'};
    if (name === 'react') return {};
    if (name === '../../data-app-public.jsx') return sdk;
    if (name === './v03-progress.css') return {};
    throw new Error(`Unexpected import ${name}`);
  },
});
const {V03Progress, v03DisplayRows} = moduleValue.exports;
const plain = value => JSON.parse(JSON.stringify(value));
function expand(node) {
  if (Array.isArray(node)) return node.flatMap(expand);
  if (!node || typeof node !== 'object') return node == null || node === false ? [] : [node];
  if (typeof node.type === 'function') return expand(node.type(node.props));
  return [{...node, children: expand(node.props.children)}];
}
function flatten(nodes) { return nodes.flatMap(node => typeof node === 'object' ? [node, ...flatten(node.children || [])] : []); }
function strings(nodes) { return nodes.flatMap(node => typeof node === 'object' ? strings(node.children || []) : [String(node)]).join(' '); }
const real = JSON.parse(fs.readFileSync(path.join(root, 'reports/self-evaluation/src/data.json'), 'utf8'));
const runRows = real.queries.v03_runs.rows;
const selectionRows = real.queries.v03_selection.rows;
const featureRows = real.queries.v03_features.rows;
const before = JSON.stringify(real);
let tree, nodes;
test('current snapshot renders all three source-backed component IDs', () => {
  tree = expand(V03Progress({snapshot: real, reviewedPeriodRows: id => real.queries[id].rows, visible: () => true}));
  nodes = flatten(tree);
  for (const id of ['v03-summary','v03-runs','v03-features']) assert.equal(nodes.filter(n => n.props.id === id).length, 1);
});
test('run source rows preserve exact query scope and detector nulls', () => {
  const component = nodes.find(n => n.props.id === 'v03-runs');
  assert.equal(component.props.sourceRows, runRows);
  assert.equal(component.props.queryId, 'v03_runs');
  const detector = component.props.displayRows.find(row => row.kind === 'detector');
  if (detector) for (const field of ['actionable','wrong','abstained']) assert.equal(detector[field], null);
});
test('selection uses current reviewed row without inventing future state', () => {
  const summary = nodes.find(n => n.props.id === 'v03-summary');
  assert.deepEqual(plain(summary.props.sourceRows), plain(selectionRows.slice(-1)));
  assert.equal(summary.props.queryId, 'v03_selection');
  assert.ok(nodes.some(n => Object.hasOwn(n.props, 'data-reviewed-rows')));
  for (const field of ['headline','holdoutStatus','selectedDefault']) assert.ok(strings(tree).includes(selectionRows.at(-1)[field]));
});
test('feature provenance stays in original reviewed source rows', () => {
  const component = nodes.find(n => n.props.id === 'v03-features');
  assert.equal(component.props.sourceRows, featureRows);
  assert.equal(component.props.queryId, 'v03_features');
});
test('incomplete engineering fixture cannot present partial scores', () => {
  const fixture = [{status:'running', images:64, correct:7, actionable:8, wrong:1, abstained:2, errors:0, medianMs:12}];
  const copy = JSON.stringify(fixture);
  const display = v03DisplayRows(fixture)[0];
  for (const field of ['correct','actionable','wrong','abstained','errors','medianMs']) assert.equal(display[field], null);
  assert.equal(JSON.stringify(fixture), copy);
});
test('wrong rate denominator is actionable; detector missingness is not zero', () => {
  const table = nodes.find(n => n.props.id === 'v03-runs');
  const column = table.props.children.props.columns.find(c => c.field === 'wrong');
  assert.match(strings(expand(column.renderCell(2,{status:'completed', actionable:12, images:16}))), /2 \/ 12/);
  assert.match(strings(expand(column.renderCell(null,{status:'completed', actionable:null, images:16}))), /未提供/);
});
test('completed VLM and detector correctness retain different labels', () => {
  const table = nodes.find(n => n.props.id === 'v03-runs');
  const column = table.props.children.props.columns.find(c => c.field === 'correct');
  assert.match(strings(expand(column.renderCell(1,{status:'completed',kind:'detector',images:12}))), /仅完整计数/);
  assert.match(strings(expand(column.renderCell(1,{status:'completed',kind:'integrated',images:12}))), /正确且可执行/);
});
test('old snapshots without v03 queries remain supported', () => {
  assert.equal(V03Progress({snapshot:{queries:{}}, reviewedPeriodRows:()=>{throw new Error('Unexpected query');}, visible:()=>true}), null);
});
test('parent source retains previous stable IDs and marks historical v0.2 scope', () => {
  for (const id of ['report:stage','report-summary','v02:historical-scope']) assert.ok(sources['ReportContent.jsx'].includes(`id="${id}"`));
  assert.ok(sources['ReportContent.jsx'].includes('v0.2 历史阶段结论'));
});
test('render does not mutate reviewed snapshot', () => assert.equal(JSON.stringify(real), before));
const hashes = Object.fromEntries(files.map(name => [name, crypto.createHash('sha256').update(sources[name]).digest('hex')]));
const result = {scope:'CPU authored-content compilation and source contract checks. No protected runtime replacement, browser rendering, GPU inference, holdout access, or production data mutation.', passed:checks.length, checks, sourceSha256:hashes};
fs.writeFileSync(path.join(__dirname,'content-contract.json'), JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({passed:checks.length, sourceSha256:hashes}));
