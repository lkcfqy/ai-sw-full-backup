/* Browser display tests only. Actual snapshot plus explicitly transient rectangle fixtures. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {chromium}=require('/Users/lkc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const output=__dirname,root=path.resolve(output,'../../..'),base='http://127.0.0.1:8775';
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const order=JSON.parse(fs.readFileSync(path.join(output,'snapshot/order.json'),'utf8'));
const result={scope:'Post-record display QA; copied actual v2 order; no inference or writes. Edge coordinates are transient engineering rendering fixtures only.',checks:[],errors:[],failedRequests:[],requests:[],measurements:[],originalSnapshotSHA:hash(path.join(output,'snapshot/order.json'))};
const ok=(v,msg)=>{assert.ok(v,msg);result.checks.push(msg);};
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
 const context=await browser.newContext({viewport:{width:390,height:844}});const page=await context.newPage();
 page.on('pageerror',e=>result.errors.push(String(e)));page.on('requestfailed',r=>result.failedRequests.push(r.url()));page.on('request',r=>result.requests.push({method:r.method(),url:r.url()}));
 async function load(before,lang,width){
  await page.setViewportSize({width,height:900});await page.goto(base+(before?'/before/':'/')+'?order='+order.id,{waitUntil:'networkidle'});
  await page.waitForFunction(id=>state.initialized&&state.order?.id===id,order.id);
  await page.locator(`[data-action="language"][data-lang="${lang}"]`).click();
  await page.waitForFunction(()=>document.querySelector('.photo-frame img')?.naturalWidth>0);
 }
 const beforeStyles={};
 try{
  for(const lang of ['ko','zh']){
   await load(true,lang,390);
   const m=await page.evaluate(()=>{const label=document.querySelector('.photo-region span').getBoundingClientRect(),stage=document.querySelector('.evidence-stage').getBoundingClientRect();return {labelRight:label.right,stageRight:stage.right,clipped:label.right>stage.right,style:document.querySelector('.photo-region').getAttribute('style'),label:document.querySelector('.photo-region span').textContent};});
   result.measurements.push({phase:'before',lang,width:390,...m});beforeStyles[lang]=m;ok(lang==='ko'?m.clipped:!!m.label,'Before '+lang+' records original label geometry at 390px'+(lang==='ko'?' and reproduces clipping':''));
   await page.locator('.evidence-panel').screenshot({path:path.join(output,`before-390-${lang}.png`)});
  }
  for(const width of [390,320,1440])for(const lang of ['ko','zh']){
   await load(false,lang,width);
   const m=await page.evaluate(()=>{const p=document.querySelector('.photo-region-caption'),s=p.querySelector('span'),r=p.getBoundingClientRect(),sr=s.getBoundingClientRect(),stage=document.querySelector('.evidence-stage').getBoundingClientRect();return{caption:p.textContent.trim(),style:document.querySelector('.photo-region').getAttribute('style'),captionLeft:r.left,captionRight:r.right,textRight:sr.right,textLeft:sr.left,height:r.height,stageBottom:stage.bottom,captionTop:r.top,hiddenOld:getComputedStyle(document.querySelector('.photo-region span')).display==='none',noOverflow:document.documentElement.scrollWidth<=innerWidth,textFits:s.scrollWidth<=s.clientWidth+1};});
   result.measurements.push({phase:'after',lang,width,...m});
   ok(m.caption===beforeStyles[lang].label,`${width} ${lang}: exact original localized label retained`);
   ok(m.style===beforeStyles[lang].style,`${width} ${lang}: region coordinates unchanged`);
   ok(m.hiddenOld&&m.captionTop>=m.stageBottom-1,`${width} ${lang}: complete caption is outside photo with clipped duplicate hidden`);
   ok(m.textFits&&m.textLeft>=0&&m.textRight<=width&&m.noOverflow,`${width} ${lang}: text visible and page has no horizontal overflow`);
   ok(await page.locator('[data-action="inspect"]').isDisabled(),`${width} ${lang}: replay cannot invoke model`);
   await page.locator('.evidence-panel').screenshot({path:path.join(output,`after-${width}-${lang}-evidence.png`)});
   if(width===390||width===1440)await page.screenshot({path:path.join(output,`after-${width}-${lang}-page.png`),fullPage:true});
  }
  await load(false,'ko',390);
  // These exist only in transient DOM and are explicitly not API observations or model outputs.
  const fixtures=await page.evaluate(()=>{
   const saved=state.order,results=[];
   try{
    for(const lang of ['ko','zh']){state.lang=lang;for(const region of [[.98,.01,1,.03],[0,0,.02,.02],[0,.98,.02,1],[.98,.98,1,1]]){
     state.order=structuredClone(saved);state.order.latest_check.action.region=region;
     const holder=document.createElement('div');holder.style.width='330px';holder.innerHTML=renderEvidence(state.order);document.body.append(holder);
     const caption=holder.querySelector('.photo-region-caption'),text=caption.querySelector('span');results.push({lang,region,kind:'transient edge fixture',caption:caption.textContent.trim(),textFits:text.scrollWidth<=text.clientWidth+1,regionRendered:!!holder.querySelector('.photo-region')});holder.remove();
    }}
    for(const type of ['missing','invalid','photo-mismatch','revision-mismatch']){state.order=structuredClone(saved);if(type==='missing')state.order.latest_check.action.region=null;if(type==='invalid')state.order.latest_check.action.region=[.8,.8,.2,.2];if(type==='photo-mismatch')state.order.latest_check.photo_id='engineering-mismatch';if(type==='revision-mismatch')state.order.latest_check.revision=999;const holder=document.createElement('div');holder.innerHTML=renderEvidence(state.order);results.push({kind:type,captionAbsent:!holder.querySelector('.photo-region-caption'),regionAbsent:!holder.querySelector('.photo-region')});}
   }finally{state.order=saved;state.lang='ko';}return results;
  });
  result.fixtures=fixtures;ok(fixtures.filter(f=>f.region).every(f=>f.textFits&&f.regionRendered),'Eight KO/ZH tiny corner rectangle fixtures keep readable captions');ok(fixtures.filter(f=>!f.region).every(f=>f.captionAbsent&&f.regionAbsent),'Absent/invalid/unbound regions do not create a caption');
  ok(await page.evaluate(()=>JSON.stringify(state.order))===JSON.stringify(order),'In-memory actual record remains byte-equivalent in JSON meaning after transient fixtures');
  ok(result.requests.every(r=>r.method==='GET'),'All browser network operations are GET');ok(!result.requests.some(r=>/inspect|propose-revision|complete/.test(r.url)),'No model or completion endpoint requested');
  ok(result.errors.length===0&&result.failedRequests.length===0,'No browser JS errors or failed requests');
  ok(hash(path.join(output,'snapshot/order.json'))===result.originalSnapshotSHA,'Copied actual snapshot unchanged');
  result.status='passed';result.passed=result.checks.length;
 }catch(error){result.status='failed';result.fatal=String(error.stack||error);process.exitCode=1;}
 finally{await browser.close();result.after_sha256={app:hash(path.join(root,'kitguard/static/app.js')),styles:hash(path.join(root,'kitguard/static/styles.css'))};fs.writeFileSync(path.join(output,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:result.status,passed:result.passed,fatal:result.fatal}));}
})();
