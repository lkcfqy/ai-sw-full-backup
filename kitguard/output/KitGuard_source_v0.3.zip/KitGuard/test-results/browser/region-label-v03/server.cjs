/* Read-only replay of copied real v2 state. No inference/backend/store imports. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const dir=__dirname,root=path.resolve(dir,'../../..'),statics=path.join(root,'kitguard/static');
const order=JSON.parse(fs.readFileSync(path.join(dir,'snapshot/order.json'),'utf8'));
const log=[];
function save(){fs.writeFileSync(path.join(dir,'server-requests.json'),JSON.stringify(log,null,2)+'\n');}
const server=http.createServer((req,res)=>{
 const url=new URL(req.url,'http://localhost'); log.push({method:req.method,path:url.pathname});save();
 const send=(status,type,body)=>{res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store'});res.end(body);};
 const json=value=>send(200,'application/json',JSON.stringify(value));
 if(req.method!=='GET')return send(405,'text/plain','Read-only display QA; all writes forbidden');
 if(url.pathname==='/api/health')return json({ok:true,model:{available:false,loaded:false,label:'READ-ONLY POST-RECORD DISPLAY QA'}});
 if(url.pathname==='/api/orders')return json({orders:[order]});
 if(url.pathname===`/api/orders/${order.id}`)return json({order});
 if(url.pathname.startsWith('/api/photos/')){
  const id=url.pathname.split('/').pop();if(!order.photos.some(p=>p.id===id))return send(404,'text/plain','No snapshot photo');
  return send(200,'image/jpeg',fs.readFileSync(path.join(dir,'snapshot',id+'.jpg')));
 }
 if(url.pathname==='/'||url.pathname==='/before/'){
  let html=fs.readFileSync(path.join(statics,'index.html'),'utf8');
  if(url.pathname==='/before/')html=html.replace('/static/app.js','/before/app.js').replace('/static/styles.css','/before/styles.css');
  return send(200,'text/html; charset=utf-8',html);
 }
 let file;
 if(['/before/app.js','/before/styles.css'].includes(url.pathname))file=path.join(dir,'before-static',path.basename(url.pathname));
 else if(url.pathname.startsWith('/static/')){file=path.resolve(statics,url.pathname.slice(8));if(!file.startsWith(statics+path.sep))return send(403,'text/plain','Forbidden');}
 if(file&&fs.existsSync(file)){const ext=path.extname(file);return send(200,ext==='.css'?'text/css':ext==='.js'?'application/javascript':ext==='.svg'?'image/svg+xml':'application/octet-stream',fs.readFileSync(file));}
 return send(404,'text/plain','No read-only route');
});
server.listen(8775,'127.0.0.1',()=>process.stdout.write('Readonly copied-state UI QA on 8775\n'));
process.on('SIGTERM',()=>{save();server.close(()=>process.exit(0));});
