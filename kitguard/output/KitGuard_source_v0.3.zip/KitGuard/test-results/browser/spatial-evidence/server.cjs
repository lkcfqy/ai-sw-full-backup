// Explicit SYNTHETIC HTTP fixture for optional future API fields. No production API or model calls.
const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const project=path.resolve(__dirname,'../../..');
const original=JSON.parse(fs.readFileSync(path.join(project,'test-results/browser/orientation-details/order.json'),'utf8'));
const order=structuredClone(original);order.title='SYNTHETIC ENGINEERING · optional spatial field';
const parts=['bolt','bolt','nut','nut','washer','washer','bracket'];
for(const [i,c] of order.checks.entries()){
 c.backend='test';c.model_label='SYNTHETIC ENGINEERING SPATIAL FIXTURE · NOT REAL MODEL';
 if(i>0)c.object_evidence={protocol:'spatial_inventory_v1',coordinate_frame:'normalized_original',objects:parts.map((part,j)=>({part,center:[.15+(j%4)*.21,.25+Math.floor(j/4)*.45]})),uncertain_parts:i===1?['washer']:[]};
 if(i===2)c.action.region=[.12,.2,.42,.62];
}
order.latest_check=order.checks.at(-1);
fs.writeFileSync(path.join(__dirname,'fixture.json'),JSON.stringify({scope:'Manually specified ENGINEERING ONLY optional field. No real spatial probe output copied.',order},null,2));
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.jpg':'image/jpeg'};
const serve=(res,file)=>{if(!fs.existsSync(file)){res.writeHead(404);return res.end()}res.writeHead(200,{'content-type':types[path.extname(file)]||'application/octet-stream','cache-control':'no-store'});res.end(fs.readFileSync(file))};
const json=(res,data)=>{res.writeHead(200,{'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify(data))};
http.createServer((req,res)=>{if(req.method!=='GET'){res.writeHead(405);return res.end('READ-ONLY SYNTHETIC FIXTURE')}
 const url=new URL(req.url,'http://localhost');
 if(url.pathname==='/')return serve(res,path.join(project,'kitguard/static/index.html'));
 if(url.pathname.startsWith('/static/')){const name=url.pathname.slice(8);if(!/^[a-zA-Z0-9_.-]+$/.test(name)){res.writeHead(400);return res.end()}return serve(res,path.join(project,'kitguard/static',name))}
 if(url.pathname==='/api/health')return json(res,{ok:true,version:'SYNTHETIC UI FIXTURE',model:{available:true,loaded:false,label:'TEST ONLY · no model call'}});
 if(url.pathname==='/api/orders')return json(res,{orders:[order]});
 if(url.pathname===`/api/orders/${order.id}`)return json(res,{order});
 if(url.pathname.startsWith('/api/photos/')){const id=url.pathname.split('/').at(-1);if(!/^img_[a-z0-9]+$/.test(id)){res.writeHead(400);return res.end()}return serve(res,path.join(project,'test-results/browser/orientation-details/data/photos',id+'.jpg'))}
 if(url.pathname===`/api/orders/${order.id}/export`)return json(res,order);
 res.writeHead(404);res.end();
}).listen(8770,'127.0.0.1',()=>console.log('SYNTHETIC READ-ONLY fixture http://127.0.0.1:8770'));
