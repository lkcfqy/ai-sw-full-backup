const fs=require('node:fs'),assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
const {chromium}=require('/Users/lkc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const base=__dirname;
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--disable-gpu']});
 const results=[];
 try{
  for(const [device,viewport] of [['desktop',{width:1440,height:900}],['mobile',{width:390,height:844}]]){
   const context=await browser.newContext({viewport,offline:true});const page=await context.newPage();
   const requests=[],errors=[],dialogs=[],checks=[];
   page.on('request',r=>requests.push({url:r.url(),method:r.method()}));
   page.on('pageerror',e=>errors.push(String(e)));page.on('dialog',async d=>{dialogs.push(d.message());await d.dismiss()});
   const ok=(v,n)=>{assert.ok(v,`${device}: ${n}`);checks.push(n)};
   await page.goto(pathToFileURL(base+'/replay/OPEN_ME.html').href,{waitUntil:'load'});
   ok(await page.evaluate(()=>!navigator.onLine),'offline Chrome context');
   ok((await page.locator('h1').innerText()).includes('非现场 API 实录'),'replay scope prominently labeled');
   ok(await page.locator('.identity-verification').count()===3,'only three explicitly saved reviews are displayed');
   const second=page.locator('#check-2 .identity-verification'),third=page.locator('#check-3 .identity-verification');
   ok((await second.locator('.identity-target').innerText()).includes('垫圈')&&(await second.locator('.identity-target').innerText()).includes('螺母'),'stored washer to nut conflict visible');
   ok((await third.locator('.identity-target').last().innerText()).includes('封闭凹槽'),'saved closed recess is distinct from through hole');
   ok((await third.locator('.facts').first().innerText()).includes('螺纹件')&&(await third.locator('.facts').first().innerText()).includes('垫圈'),'recorded affected categories visible');
   ok((await second.innerText()).includes('不重新赋整数计数')&&(await second.innerText()).includes('不是独立验证或几何实测'),'correlation and no recount boundaries visible');
   ok((await second.innerText()).includes('图像插值不创造新信息'),'interpolation does not create information');
   ok((await page.locator('#check-2 tr[data-part="washer"] td[data-value="observed"]').innerText()).includes('未确认'),'guarded final unknown stays unknown');
   ok((await page.locator('#check-2 tr[data-part="washer"] td[data-value="required"]').innerText()).includes('未确认'),'missing historical BOM not fabricated');
   ok(await page.locator('.identity-verification img,.identity-verification a').count()===0,'crop metadata does not imply attached or remotely loaded crops');
   await page.locator('details').evaluateAll(els=>els.forEach(el=>el.open=true));
   await page.locator('img').evaluateAll(async els=>{els.forEach(el=>el.loading='eager');await Promise.all(els.map(el=>el.decode()))});
   const images=await page.locator('img').evaluateAll(els=>els.map(el=>({src:el.getAttribute('src'),width:el.naturalWidth,height:el.naturalHeight})));
   ok(images.every(i=>i.width>0&&i.height>0),'all original local photographs decode');
   const overflow=await page.evaluate(()=>({root:document.documentElement.scrollWidth>innerWidth+1,offenders:[...document.querySelectorAll('section,table,details,pre,.facts')].filter(el=>el.scrollWidth>el.clientWidth+2).map(el=>({tag:el.tagName,class:el.className,width:el.clientWidth,scroll:el.scrollWidth}))}));
   ok(!overflow.root&&!overflow.offenders.length,'no overflow including expanded tables and JSON');
   await page.locator('details').evaluateAll(els=>els.forEach(el=>el.open=false));
   await second.evaluate(el=>scrollTo(0,el.getBoundingClientRect().top+scrollY-18));
   await page.screenshot({path:`${base}/${device}-identity-overview.png`});
   await third.locator('.identity-table').evaluate(el=>scrollTo(0,el.getBoundingClientRect().top+scrollY-18));
   await page.screenshot({path:`${base}/${device}-identity-table.png`});
   const crop=third.locator('.identity-crop').last();await crop.locator('summary').click();
   await crop.evaluate(el=>scrollTo(0,el.getBoundingClientRect().top+scrollY-18));
   await page.screenshot({path:`${base}/${device}-crop-metadata.png`});
   await crop.locator('dt').filter({hasText:'原始裁剪 SHA-256'}).evaluate(el=>scrollTo(0,el.getBoundingClientRect().top+scrollY-18));
   await page.screenshot({path:`${base}/${device}-crop-hashes.png`});
   ok(requests.every(r=>r.url.startsWith('file:')&&r.method==='GET'),'only local file GETs; no network or writes');
   ok(!errors.length&&!dialogs.length,'zero errors or dialogs');
   results.push({device,viewport,checksPassed:checks.length,checks,requests,images,overflow,errors,dialogs});
   await context.close();
  }
  fs.writeFileSync(base+'/browser-results.json',JSON.stringify({createdAt:new Date().toISOString(),browserVersion:browser.version(),scope:'Actual Chrome offline file://. Fixed development-output display replay, not live API or physical verification. No model call.',checksPassed:results.reduce((n,r)=>n+r.checksPassed,0),results},null,2));
  console.log(JSON.stringify({runs:results.length,checksPassed:results.reduce((n,r)=>n+r.checksPassed,0)}));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
