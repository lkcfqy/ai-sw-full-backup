"""Read fixed development outputs and construct an explicitly labeled display replay."""
import copy
import hashlib
import json
import shutil
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from kitguard.evidence import render_viewer
BASE=Path(__file__).resolve().parent
OUT=BASE/'replay'
(OUT/'photos').mkdir(parents=True,exist_ok=True)
RUN=ROOT/'evaluation-runs/v03_screws_identity_geometry_v2'
INPUTS=ROOT/'evaluation-runs/v03_screws_development_v1/normalized_inputs'
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
metadata=json.loads((RUN/'run.json').read_text())
assert metadata['split']=='development' and metadata['status']=='completed'
rows=[json.loads(s) for s in (RUN/'predictions.jsonl').read_text().splitlines()]
assert len(rows)==12 and all(r['split']=='development' for r in rows)
records=[]; photos=[]; sources=[]
for index in (1,2,12):
 row=rows[index-1]
 source=INPUTS/f'{index:03d}.jpg'
 assert digest(source)==row['normalized_input_sha256']
 photoid=f'replay-dev-{index:03d}'
 shutil.copyfile(source,OUT/'photos'/f'{photoid}.jpg')
 review={
  'protocol':'identity_geometry_v2', 'same_model_correlated_calls':True,
  'response':copy.deepcopy(row['identity_response']),
  'blocked_categories':copy.deepcopy(row['experimental_identity_guard']['blocked_categories']),
  'source_sha256':row['normalized_input_sha256'],
  'full_input_sha256':row['inputs'][0]['sha256'],
  'crops':[{**c,'crop_file':Path(c['crop_file']).name,'pixel_crop_file':Path(c['pixel_crop_file']).name} for c in row['crops']],
 }
 observation=copy.deepcopy(row['observation'])
 observation.pop('verification',None)
 check={
  **observation, 'id':f'development-replay-{index:03d}', 'photo_id':photoid,
  'photo_sha256':row['normalized_input_sha256'],
  'revision':None,'valid':None,'decision':None,
  'observation_verification':copy.deepcopy(row['base_observation']['verification']),
  'identity_verification':review,
  'replay_source_case_id':row['case_id'],
  'replay_note':'DISPLAY REPLAY of stored development outputs. Not a live API check, not physical verification; no new model call. No historical requirement/version/decision invented.',
 }
 records.append(check)
 photos.append({'id':photoid,'archive_path':f'photos/{photoid}.jpg','sha256':digest(source)})
 sources.append({'case_id':row['case_id'],'split':'development','source_file':str(source.relative_to(ROOT)),'sha256':digest(source)})
payload={
 'schema_version':2,'exported_at':None,
 'order':{
  'id':'DISPLAY-REPLAY-NOT-API-ORDER',
  'title':'개발 출력 재생 · 현장 API 실록 아님 / 开发输出回放，非现场 API 实录',
  'revision':None,'status':'DISPLAY_REPLAY_ONLY','checks':records,'completions':[],
  'demo_source':{
   'kind':'public_photo_demo','sample_id':'Screws v2 development replay 001 / 002 / 012',
   'source_case_id':'Multiple development outputs; see each replay_source_case_id',
   'source_url':'https://www.mvtec.com/research-teaching/datasets/mvtec-screws',
   'license':'CC BY-NC-SA 4.0','source_note':'Saved development outputs assembled only to QA the read-only report. No API inspection or physical action was performed; no new inference.',
  },
 },
 'photos':photos,
}
(OUT/'evidence.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
(OUT/'OPEN_ME.html').write_text(render_viewer(payload))
(OUT/'README.txt').write_text('DISPLAY REPLAY ONLY. Fixed Screws-v2 development outputs, not live API checks or physical evidence. No model or holdout reads.\n')
manifest=[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in [OUT/'evidence.json',OUT/'OPEN_ME.html',*sorted((OUT/'photos').glob('*.jpg'))]]
(OUT/'SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
(BASE/'provenance.json').write_text(json.dumps({
 'scope':'Display replay only; no model call, no live API check, no physical replenishment claim.',
 'source_run':str(RUN.relative_to(ROOT)), 'source_run_sha256':digest(RUN/'run.json'),
 'source_predictions_sha256':digest(RUN/'predictions.jsonl'), 'selected_development_sources':sources,
 'not_loaded':['holdout predictions','holdout photographs'],
 'source_file_check':'Every copied normalized image byte matches its saved development prediction SHA.',
 'constructed_fields':['order/check identifiers','demo_source','identity_verification assembled from saved experimental fields'],
 'missing_historical_fields_preserved':['revision','valid','decision','requirements_snapshot','exported_at'],
},ensure_ascii=False,indent=2)+'\n')
print(OUT/'OPEN_ME.html')
