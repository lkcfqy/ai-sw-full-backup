# KitGuard 0.7.0 · source snapshot / 소스 스냅샷 / 源码快照

This source component includes application code, static UI, tests, scripts,
authored text documentation, public dataset manifests, third-party notices, and
exactly three licensed development photographs. It makes no claim of a complete
submission; consult the accompanying delivery manifest for the overall deliverables.
Use this file for package contents; the main README retains earlier version history.

## Run the public-photo workflow on Apple Silicon macOS

```sh
bash scripts/setup.sh
.venv/bin/python scripts/download_candidate_model.py
bash scripts/run.sh
```

Setup requires `uv` and downloads the pinned Python dependencies. The model download
is separate and uses the pinned upstream model revision and file hashes. If the
verified model is already installed, set KITGUARD_MODEL_PATH to its directory and
skip downloading. No model weights or Python environment are in this ZIP.

Open http://127.0.0.1:8765/static/demo.html. All three image previews are included.
Selecting a photo creates a source-tagged order with no cached observation. Run the
real local model, record a human digital opinion, revise the order and explicitly
replay the same photo, then export the offline evidence ZIP. Replay is not a new
capture, physical repair, or completion. The UI can start without weights; actual
inference requires the separately installed local model and sufficient memory.

Windows/Linux model inference is not verified. Package smoke verification uses
existing dependencies, checks imports/routes/images, and does not load MLX or
establish clean-machine installation or recognition accuracy.

## Included public images and license

MVTec authors' images are redistributed under CC BY-NC-SA 4.0; retain attribution,
noncommercial use, and ShareAlike terms. The complete stored notices are in
third_party/datasets/. Source links and image SHA-256 values are also in
SOURCE_MANIFEST.json and kitguard/public_demo_catalog.py.

| Sample | Included photograph | Original source |
| --- | --- | --- |
| bag-revision | datasets/raw/mvtec_loco_ad/screw_bag/train/good/016.png | https://www.mvtec.com/research-teaching/datasets/mvtec-loco-ad |
| small-part | datasets/derived/v0.3/screws_views/v03-screws-screws_222-56eea59f64ca.png | https://www.mvtec.com/research-teaching/datasets/mvtec-screws |
| mixed-screws | datasets/derived/v0.3/screws_views/v03-screws-screws_344-8d389e404b12.png | https://www.mvtec.com/research-teaching/datasets/mvtec-screws |

The two Screws images are integer crops of original photographs. No compositing
or object deletion was performed. Crop coordinates, original file hashes, and
author annotation hashes are recorded in the manifest's crop_provenance, linked
to datasets/manifests/v0.3/source_grouped_v2/screws_new_development_crop_specs_v1.json. These three previously used development examples are not fresh
holdout data, recognition scores, or user feedback.

## External experiment data

scripts/v07/prepare_public_evaluation.py, run_public_paired.py, and
analyze_public_paired.py are included, as are their source-code dependencies.
Full datasets, the new 51-photo set, author raw annotations, historical experiment
outputs, training splits/weights, and browser records are external. Reproducing a
source-disjoint selection requires those exact historical exposure records and
their hashes; do not substitute an empty history or describe these three demo
images as new held-out evidence. Restore verified external inputs according to
docs/v0.7/PUBLIC_EVALUATION_PLAN.md before executing those experiments.

Photo-/history-dependent tests may require these excluded external artifacts.
No private SQLite database, user uploads, participant records, model weights,
cached environment, or generated delivery/report output is packaged.

## Verify and rebuild

SOURCE_MANIFEST.json lists every payload file's byte size, SHA-256, and normalized
mode. The archive uses sorted paths, fixed ZIP metadata, and content-derived
metadata. The same source bytes produce the same archive bytes with the same
Python/zlib toolchain. Checksums are integrity checks, not signatures.

```sh
.venv/bin/python -m scripts.v07.package_source --output /new/path/kitguard-source.zip --verify-runtime
```

The ZIP, .manifest.json, .sha256, and (when requested) .verification.json paths
must all be new. Existing artifacts are never overwritten. The version identifies
the packaged source; create a new explicitly named path for each later package.
Fixed ZIP timestamps serve reproducibility and do not claim a generation or submission date.
