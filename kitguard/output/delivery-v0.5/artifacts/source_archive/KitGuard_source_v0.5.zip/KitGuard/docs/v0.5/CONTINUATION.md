# v0.5 恢复记录

用户授权用剩余额度持续开发；最近账户读数98%已用，未使用重置额度。v0.4不可覆盖交付为output/delivery-v0.4。

v0.5产品后端/前端已冻结。区域选择、整图/裁图来源、同源预算、导出重建与独立反例已完成。全套进度683项通过，后加harness3项和delivery builder测试，须最后全套。Chrome52主流程+16严格绑定视觉通过，另2张底部截图不计入严格绑定全链。

实际模型2次已完成：test-results/browser/inspection-region-real-v05；A41作者区域bracket1/13.046s；mixed全框3/0/0/0/15.173s。0错误0重试source_changedfalse，3ZIP重建和独立批次验收通过。两图都已用于开发，不是新准确率；A41只角码真值，mixed人工栏是脚本，真人N0。8791进程已退出，shutdown.json保留缺少server-exit.json事实。

主服务已切换工作区v0.5：8765 PID54068/session88556。旧v04稳定服务51845正常shutdown。test-results/audit/v05-service-cutover.json确认版本0.5.0、orders仍0、静态字节匹配、模型尚未加载。禁止再启动第二GPU推理进程。UI8790已停止。

wheel已验证：output/wheels-v0.5-final/kitguard-0.5.0-py3-none-any.whl，SHA04b98c1da25ffeba90e9da03d26d7879795ec21d372620d21429571d44059099。34产品成员/38 RECORD/9GET+实际选区POST通过。

最后待完成：runtime_audit正在完成scripts/build_v05_delivery.py与tests；root随后最终全套engineering-v05-final.xml、sourcezip v0.5和verify_source_archive.py --expected-skipped 6（新增author数据测试明确跳过）、final delivery。field_frontend已有test-results/browser/delivery-v05-final/browser.cjs等待最终output/delivery-v0.5/index.html生成通知。source packager已纳入所有v05文本、method记录、final XML。

已有docs/v0.5/FINAL_EVALUATION.md及DEMO_RUNBOOK_KO_ZH.md，最终测试count待补。package_source与verify_source_archive有本轮更新；不要改核心/静态/verify_study_export.py的冻结内容。旧评测/交付/失败保留。私密报名资料不进入代码包；不提交、不代签、不发邮件、不保证名次。

最终套件已完成：696 passed，无skip/fail/error；builder10反例纳入其中。最终源码/交付打包正在执行；版本与方法/真实run/UI冻结均未变。
