"""Read actual built wheel bytes and execute only its extracted product modules."""
import base64
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[2]
DEST=ROOT/'test-results/audit/v05-wheel-final-verification.json'
WHEEL=ROOT/'output/wheels-v0.5-final/kitguard-0.5.0-py3-none-any.whl'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
result={'status':'failed','verified_at':datetime.now(timezone.utc).isoformat(),'wheel':str(WHEEL.relative_to(ROOT)),'scope':'Actual wheel extraction with existing installed dependencies, isolated temporary database, injected unavailable analyzer. No model/GPU, production data or frozen product source edits.'}
try:
    result['wheel_sha256']=sha(WHEEL.read_bytes())
    with zipfile.ZipFile(WHEEL) as archive:
        members=archive.namelist()
        expected={str(p.relative_to(ROOT)) for p in (ROOT/'kitguard').glob('*.py')}|{str(p.relative_to(ROOT)) for p in (ROOT/'kitguard/static').glob('*') if p.is_file()}
        actual={n for n in members if n.startswith('kitguard/') and not n.endswith('/')}
        assert actual==expected, {'missing':sorted(expected-actual),'extra':sorted(actual-expected)}
        result['member_sha256']={n:sha(archive.read(n)) for n in sorted(actual)}
        for name,digest in result['member_sha256'].items():
            assert digest==sha((ROOT/name).read_bytes()),name
        result['workspace_members_matched']=len(actual)
        records=list(csv.reader(io.StringIO(archive.read('kitguard-0.5.0.dist-info/RECORD').decode())))
        assert {r[0] for r in records}==set(members)
        for name,digest,size in records:
            if name.endswith('/RECORD'):
                assert not digest and not size
            else:
                raw=archive.read(name)
                assert digest=='sha256='+base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).decode().rstrip('='),name
                assert int(size)==len(raw),name
        result['record_entries_verified']=len(records)
        assert '\nVersion: 0.5.0\n' in archive.read('kitguard-0.5.0.dist-info/METADATA').decode()
        with tempfile.TemporaryDirectory(prefix='kitguard-v05-wheel-') as temp:
            unpack=Path(temp)/'extracted';archive.extractall(unpack)
            smoke=Path(temp)/'smoke.py'
            smoke.write_text('''import io,json,sys,hashlib
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import kitguard
from kitguard.app import create_app
from fastapi.testclient import TestClient
from PIL import Image
root=Path(sys.argv[1]).resolve()
assert Path(kitguard.__file__).resolve().is_relative_to(root)
assert kitguard.__version__=='0.5.0'
class NoInference:
    def status(self):
        return {'available':False,'loaded':False,'label':'ENGINEERING WHEEL SMOKE NO MODEL','path':None,'error':None}
    def observe(self,*args,**kwargs):
        raise AssertionError('No inference authorized in wheel verification')
checks=[]
app=create_app(data_dir=Path(sys.argv[2]),analyzer=NoInference())
with TestClient(app) as client:
    for route in ['/', '/static/region.js','/static/region.css','/static/study.html','/static/study.js','/static/study.css','/api/health','/api/orders','/api/studies']:
        r=client.get(route);assert r.status_code==200,(route,r.status_code);checks.append({'route':route,'status':r.status_code})
        if route.startswith('/static/'):
            assert r.content==(root/'kitguard'/route.lstrip('/')).read_bytes(),route
    health=client.get('/api/health').json();assert health['version']=='0.5.0' and health['model']['loaded'] is False
    o=client.post('/api/orders',json={'title':'ENGINEERING WHEEL SMOKE','requirements':{'bolt':1,'nut':0,'washer':0,'bracket':0}}).json()['order']
    buf=io.BytesIO();Image.new('RGB',(160,120),(30,70,50)).save(buf,format='PNG')
    r=client.post('/api/orders/'+o['id']+'/photos',data={'expected_revision':1},files={'photo':('engineering.png',buf.getvalue(),'image/png')});assert r.status_code==201,r.text
    o=r.json()['order'];p=o['photos'][-1]
    r=client.post('/api/orders/'+o['id']+'/inspection-region',json={'expected_revision':1,'expected_photo_id':p['id'],'expected_evidence_epoch':o['evidence_epoch'],'root_photo_id':p['id'],'mode':'region','region_xyxy':[20,20,120,100],'confirmed_all_items_inside':True});assert r.status_code==200,r.text
    p2=r.json()['photo'];assert p2['root_photo_id']==p['id'] and p2['width']==100 and p2['height']==80
    assert client.get('/api/photos/'+p2['id']).status_code==200
    checks.append({'route':'POST /api/orders/{id}/inspection-region','status':200,'root_preserved':True,'derived_dimensions':[100,80],'inference_calls':0})
print(json.dumps({'status':'passed','version':kitguard.__version__,'imported_from_extracted_wheel':True,'module_path':str(kitguard.__file__),'routes':checks,'health':health,'gpu_used':False}))
''')
            env={k:v for k,v in os.environ.items() if k!='PYTHONPATH'}
            proc=subprocess.run([sys.executable,str(smoke),str(unpack),str(Path(temp)/'data')],cwd=temp,env=env,text=True,capture_output=True)
            result['smoke_exit_code']=proc.returncode
            result['smoke_stderr']=proc.stderr
            assert proc.returncode==0,proc.stdout+'\n'+proc.stderr
            result['isolated_smoke']=json.loads(proc.stdout)
    freeze=json.loads((ROOT/'test-results/browser/inspection-region-v05/SOURCE_FREEZE.json').read_text())
    assert all(sha((ROOT/'kitguard/static'/n).read_bytes())==h for n,h in freeze['source_sha256'].items())
    result['ui_source_freeze_unchanged']=True
    result['status']='passed'
except Exception as error:
    result['error']=repr(error)
finally:
    DEST.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['member_sha256','smoke_stderr','isolated_smoke']},ensure_ascii=False))
if result['status']!='passed':sys.exit(1)
