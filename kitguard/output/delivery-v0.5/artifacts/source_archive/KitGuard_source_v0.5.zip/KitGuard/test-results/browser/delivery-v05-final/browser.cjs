/* Read-only final-delivery verification. Run only after root confirms the final build. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto'),http=require('node:http');
const {chromium}=require('/Users/lkc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const base=__dirname,root=path.resolve(base,'../../../output/delivery-v0.5'),checks=[],errors=[],external=[],linkResponses=[];
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),ok=(v,n)=>{assert.ok(v,n);checks.push(n)};
const inside=relative=>{const p=path.resolve(root,decodeURIComponent(relative));assert.ok(p.startsWith(root+path.sep),'Path remains in final delivery: '+relative);return p};
(async()=>{
 if(!fs.existsSync(root+'/index.html'))throw new Error('Final delivery is absent. Wait for root; do not build or poll.');
 const manifest=JSON.parse(fs.readFileSync(root+'/BUILD_MANIFEST.json')),hashes=JSON.parse(fs.readFileSync(root+'/SHA256.json')),s=manifest.summary;
 ok(manifest.final===true&&s.release_status==='final','actual v0.5 manifest declares final delivery');
 ok(fs.readFileSync(root+'/SHA256.json.sha256','utf8').split(/\s/)[0]===sha(root+'/SHA256.json'),'hash-list own SHA matches sidecar');
 for(const [name,digest] of Object.entries(hashes))assert.equal(sha(inside(name)),digest,name);checks.push(`all ${Object.keys(hashes).length} file SHA values match actual bytes`);
 for(const a of manifest.artifacts){const f=inside(a.destination);assert.equal(fs.statSync(f).size,a.bytes,a.destination);assert.equal(sha(f),a.sha256,a.destination);}checks.push(`all ${manifest.artifacts.length} copied artifacts match size and SHA`);
 ok(s.human_field_samples===0&&s.new_accuracy_samples_from_public_integration===0,'human field and new public-integration accuracy counts remain zero');
 ok(s.operator_scope_completeness_certified===false,'scope completeness is not falsely certified');
 ok(s.ui_api.assertions===52&&s.ui_visual.assertions===16,'manifest preserves 52 API plus 16 final visual checks');
 ok(s.real_api.planned_requests===2&&s.real_api.attempted_requests===2&&s.real_api.cases.length===2&&s.real_api.verification_status==='passed','exactly two actual prespecified MLX attempts retain independent verification');
 ok(s.real_api.source_changed===false,'real model receipt preserves frozen source');
 ok(s.pending_required_roles.length===0&&s.pending_gates.length===0,'final build has no required pending evidence');
 ok(s.final_tests.failures===0&&s.final_tests.errors===0&&s.source_verification.status==='passed','final engineering suite and actual extracted-source verification passed');
 const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.md':'text/plain; charset=utf-8'};
 const server=http.createServer((req,res)=>{try{const name=new URL(req.url,'http://127.0.0.1').pathname;const file=inside(name==='/'?'index.html':name.slice(1));if(!fs.statSync(file).isFile())throw new Error('Not a file');res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'});fs.createReadStream(file).pipe(res);}catch{res.writeHead(404);res.end('Not found');}});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin=`http://127.0.0.1:${server.address().port}`;
 let browser,page;
 try{
 browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});page=await browser.newPage();page.on('pageerror',e=>errors.push(String(e)));page.on('request',r=>{if(new URL(r.url()).origin!==origin)external.push(r.url());});
 const initial=await page.goto(origin+'/index.html',{waitUntil:'networkidle'});ok(initial.status()===200,'final index serves HTTP 200');
 const body=await page.locator('body').innerText();ok((await page.locator('html').getAttribute('lang'))==='ko','delivery defaults to Korean with Chinese explanation');ok(body.includes('最终交付'),'page identifies final delivery');
 ok(/API:\s*52/.test(body)&&/visual:\s*16/.test(body),'visible UI preserves 52 plus 16 engineering scope');
 ok(body.includes('两次真实 MLX 调用')&&body.includes('不证明准确率改善'),'two actual model calls retain accuracy limitation');
 const metrics=await page.locator('.metric').allInnerTexts();ok(metrics.some(t=>/^0\s/.test(t)&&t.includes('真人现场样本')),'human field zero is visible beside its label');ok(metrics.some(t=>/^0\s/.test(t)&&t.includes('公开集成新增准确率样本')),'new accuracy zero is visible beside its label');
 ok(body.includes('裁剪不是新增物理照片')&&body.includes('框外未核验'),'crop provenance and unchecked outside scope are visible');
 ok(body.includes('不代表真人表现')&&body.includes('不是模型成绩'),'scripted manual and engineering surrogate limits remain visible');
 for(const width of[1440,390,320]){await page.setViewportSize({width,height:1000});await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`${width}px final index has no page overflow`);await page.screenshot({path:base+`/final-${width}.png`,fullPage:true});await page.screenshot({path:base+`/viewport-${width}.png`});}
 const hrefs=await page.locator('a[href]').evaluateAll(es=>es.map(e=>e.getAttribute('href')));ok(hrefs.length>0&&hrefs.every(h=>h&&!h.startsWith('/')&&!/^[a-z][a-z0-9+.-]*:/i.test(h)),'every index link is relative');
 for(const href of hrefs){const target=new URL(href,origin+'/index.html');assert.equal(target.origin,origin);inside(target.pathname.slice(1));const r=await fetch(target);await r.arrayBuffer();linkResponses.push({href,status:r.status});assert.equal(r.status,200,href);}checks.push(`all ${hrefs.length} relative index links return HTTP 200`);
 ok(external.length===0,'Chrome makes zero external requests');ok(errors.length===0,'Chrome has zero JavaScript errors');
 const result={status:'passed',verified_at:new Date().toISOString(),assertions:checks.length,checks,errors,external_requests:external,linkResponses,artifact_count:manifest.artifacts.length,hashed_file_count:Object.keys(hashes).length,index_sha256:sha(root+'/index.html'),manifest_sha256:sha(root+'/BUILD_MANIFEST.json'),hashes_sha256:sha(root+'/SHA256.json'),summary:s,scope:'Read-only final v0.5 delivery, transient loopback HTTP server, actual Chrome. No builder/source/delivery changes, no GPU or production API.'};fs.writeFileSync(base+'/result.json',JSON.stringify(result,null,2));console.log(JSON.stringify({status:'passed',assertions:checks.length,artifacts:manifest.artifacts.length,links:hrefs.length,hashed_files:Object.keys(hashes).length}));
 }catch(e){const stamp=Date.now();if(page)await page.screenshot({path:base+`/failure-${stamp}.png`,fullPage:true});fs.writeFileSync(base+`/failure-${stamp}.json`,JSON.stringify({status:'failed',error:String(e),checks,errors,external,linkResponses},null,2));throw e;}finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));}
})().catch(e=>{console.error(e);process.exitCode=1});
