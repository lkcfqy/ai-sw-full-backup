const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const {pathToFileURL} = require('node:url');
const {chromium} = require('/Users/lkc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const base = __dirname;
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const inputs = JSON.parse(fs.readFileSync(path.join(base, 'inputs.json')));
(async () => {
  const browser = await chromium.launch({headless:true, executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', args:['--disable-gpu']});
  const receipt = {created_at:new Date().toISOString(), browser:browser.version(), status:'running', inputs, results:[], scope:'Read-only real v0.5 archives in offline Google Chrome; no inference or physical/human evidence claim.'};
  try {
    for (const input of inputs) {
      for (const width of [1440, 390]) {
        const context = await browser.newContext({viewport:{width,height:1000},offline:true,deviceScaleFactor:1});
        const page = await context.newPage();
        const row = {sample:input.name,width,checks:[],requests:[],external:[],javascript_errors:[],console_errors:[],failed_requests:[]};
        receipt.results.push(row);
        const ok = (value, message) => {assert.ok(value, `${input.name}/${width}: ${message}`); row.checks.push(message);};
        page.on('pageerror', error => row.javascript_errors.push(String(error)));
        page.on('console', msg => {if(msg.type()==='error') row.console_errors.push(msg.text());});
        page.on('request', request => {row.requests.push({url:request.url(),method:request.method()});if(/^https?:/i.test(request.url()))row.external.push(request.url());});
        page.on('requestfailed', request => row.failed_requests.push({url:request.url(),failure:request.failure()}));
        await page.goto(pathToFileURL(path.join(base,input.name,input.page)).href,{waitUntil:'load'});
        ok(await page.evaluate(()=>navigator.onLine===false),'offline browser context');
        ok(await page.locator('script,iframe,form').count()===0,'static document contains no scripts, frames or forms');
        await page.locator('img').evaluateAll(async images=>{images.forEach(i=>i.loading='eager');await Promise.all(images.map(i=>i.decode()));});
        const decoded = await page.locator('img').evaluateAll(images=>images.map(i=>({src:i.getAttribute('src'),width:i.naturalWidth,height:i.naturalHeight,complete:i.complete})));
        row.images=decoded;
        ok(decoded.length>0 && decoded.every(i=>i.complete&&i.width>0),'all actual JPEG image elements decode');
        const scope=page.locator('figure.inspection-scope').first();
        ok(await scope.count()===1 && await scope.isVisible(),'full normalized root and scope figure are visible');
        const expected=input.name==='a41'?[436,511,170,116]:[0,0,768,576];
        const rectangle=await scope.locator('rect').evaluate(el=>['x','y','width','height'].map(n=>Number(el.getAttribute(n))));
        row.rectangle=rectangle;
        ok(JSON.stringify(rectangle)===JSON.stringify(expected),'visible rectangle equals actual frozen root coordinates');
        const root=await scope.locator('svg image').evaluate(async element=>{const url=new URL(element.getAttribute('href'),document.baseURI).href;const image=new Image();image.src=url;await image.decode();return {src:url,width:image.naturalWidth,height:image.naturalHeight};});
        row.root=root;
        ok(root.width===(input.name==='a41'?1280:768) && root.height===(input.name==='a41'?720:576),'complete normalized root JPEG decodes with expected dimensions');
        const expectedView=input.name==='a41'?[170,116]:[768,576];
        ok(decoded.some(i=>i.width===expectedView[0]&&i.height===expectedView[1]),'actual crop image remains visible in archive');
        ok((await page.locator('body').innerText()).includes('框外未核验'),'outside-region limitation is visible');
        ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'document fits viewport without horizontal scrolling');
        const screenshot=`${input.name}-${width}.png`;
        await page.screenshot({path:path.join(base,screenshot),fullPage:true});
        row.screenshot={path:screenshot,sha256:sha(path.join(base,screenshot))};
        ok(row.external.length===0,'zero external HTTP requests');
        ok(row.javascript_errors.length===0 && row.console_errors.length===0,'zero JavaScript or console errors');
        ok(row.failed_requests.length===0,'zero failed local resources');
        ok(row.requests.every(r=>r.method==='GET'),'read-only GET requests only');
        await context.close();
      }
      assert.equal(sha(path.join(base,'..',input.archive)),input.archive_sha256,'original ZIP changed');
    }
    receipt.status='passed';
    receipt.assertions=receipt.results.reduce((sum,row)=>sum+row.checks.length,0);
  } catch(error) {
    receipt.status='failed';receipt.error=String(error);process.exitCode=1;
  } finally {
    fs.writeFileSync(path.join(base,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
    console.log(JSON.stringify({status:receipt.status,assertions:receipt.assertions,error:receipt.error}));
    await browser.close();
  }
})();
