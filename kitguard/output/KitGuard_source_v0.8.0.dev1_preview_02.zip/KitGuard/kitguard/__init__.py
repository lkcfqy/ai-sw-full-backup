"""KitGuard local application."""

__version__ = "0.8.0.dev1"
