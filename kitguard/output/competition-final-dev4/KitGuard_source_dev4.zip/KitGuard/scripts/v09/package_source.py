"""Package v0.9 with the reviewed v0.8 collector and isolated runtime smoke test."""
from __future__ import annotations

import argparse
import ast
import json
import re
import tomllib
from pathlib import Path

from scripts.v08 import package_source as base

ORIGINAL_NOTE = base.package_note
ORIGINAL_COLLECT = base.collect


def collect(root):
    selected, samples, index = ORIGINAL_COLLECT(root)
    # The live grading ledger changes after package verification. Ship its final
    # snapshot beside the source ZIP, so the ZIP cannot grade its own hash.
    for relative in ("docs/scoring/ledger.json", "docs/scoring/reviewed-snapshot.json"):
        selected.pop(relative, None)
        index["not_scanned_or_bundled"].append(relative + " (final snapshot accompanies delivery)")
    return selected, samples, index


def package_note(version, preview, samples):
    note = ORIGINAL_NOTE(version, preview, samples).decode()
    note = note.replace("bash scripts/run.sh", "bash scripts/run_competition.sh")
    note = note.replace("-m scripts.v08.package_source --preview", "-m scripts.v09.package_source")
    note += "\n## v0.9 review workflow\n\nSee docs/v0.9/DEMO_AND_HANDOFF_ZH.md and RELEASE_NOTES.md. "
    note += "The independent point review preserves original AI, expires on changed evidence/opinions, "
    note += "and exports both count tables and original-photo point positions.\n"
    note += "Public-photo digital tasks: open /static/digital-trials.html. Six fixed tasks per participant, "
    note += "manual/KitGuard order alternation, server timing including inference, current-version checks, "
    note += "and full planned denominators. Engineering rehearsals are never human results.\n"
    note += "Autonomous mission: open /static/autonomy.html. One operator can run all three public-photo scenarios; "
    note += "real local inference, conditional routing, declared R2 replay, persistent execution and evidence ZIP. No participants needed.\n"
    note += "Current photo-document goal: use the order detail's autonomous-review link. The accepted goal binds "
    note += "order ID, revision, evidence epoch and photo ID; the worker also verifies the accepted content. "
    note += "It runs one fresh inspection without rewriting the BOM. Failed execution preserves input and error, "
    note += "without inventing a model result. See docs/scoring/DEV4_HANDOFF.md.\n"
    note += "Five machine tasks and CPU version-binding ablation are engineering evidence, not human efficiency "
    note += "or new-photo accuracy. Final grading ledger and raw execution artifacts accompany this ZIP. "
    note += "Source smoke uses existing dependencies; it does not certify clean-machine installation.\n"
    return note.encode()


def source_version(payload, preview):
    version = tomllib.loads(payload["pyproject.toml"].decode())["project"]["version"]
    tree = ast.parse(payload["kitguard/__init__.py"])
    declared = [n.value.value for n in tree.body if isinstance(n, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == "__version__" for t in n.targets)
                and isinstance(n.value, ast.Constant)]
    if declared != [version] or not re.fullmatch(r"0\.9\.\d+(?:\.dev\d+)?", version):
        raise ValueError("Matching v0.9 package/project versions required")
    if ".dev" in version and not preview:
        raise ValueError("Development source requires explicit --preview")
    return version


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--verify-runtime", action="store_true")
    args = parser.parse_args()
    base.source_version = source_version
    base.package_note = package_note
    base.collect = collect
    base.TOP_FILES = (*base.TOP_FILES, "启动参赛演示.command")
    base.SMOKE_PROGRAM = base.SMOKE_PROGRAM.replace(
        "routes_list = [", "routes_list = ['/static/digital-resolution.js', '/static/digital-resolution.css', "
        "'/static/digital-trials.html', '/static/digital-trials.js', '/static/digital-trials.css', "
        "'/static/autonomy.html', '/static/autonomy.js', '/static/autonomy.css', ")
    base.SMOKE_PROGRAM = base.SMOKE_PROGRAM.replace(
        "assert 'photo-documents.js' in page", "assert 'photo-documents.js' in page and 'digital-resolution.js' in page")
    base.REQUIRED = base.REQUIRED | {"kitguard/digital_resolution.py", "kitguard/static/digital-resolution.js",
                                     "kitguard/static/digital-resolution.css", "tests/test_digital_resolution.py",
                                     "kitguard/digital_task_trials.py", "kitguard/static/digital-trials.html",
                                     "kitguard/static/digital-trials.js", "kitguard/static/digital-trials.css",
                                     "tests/test_digital_task_trials.py", "kitguard/autonomy.py", "tests/test_autonomy.py",
                                     "kitguard/static/autonomy.html", "kitguard/static/autonomy.js", "kitguard/static/autonomy.css",
                                     "docs/scoring/DEV4_HANDOFF.md", "scripts/scoring/run_machine_tasks.py"}
    print(json.dumps(base.build(base.ROOT, args.output, preview=True, smoke=args.verify_runtime), ensure_ascii=False))


if __name__ == "__main__":
    main()
