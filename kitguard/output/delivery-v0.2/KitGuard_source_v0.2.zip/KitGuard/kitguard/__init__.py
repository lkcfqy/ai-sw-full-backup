"""KitGuard local application."""

