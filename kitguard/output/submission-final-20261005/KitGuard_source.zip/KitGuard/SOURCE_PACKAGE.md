# KitGuard 0.9.0.dev4 · FINAL CONTEST SOURCE / 최종 제출 소스 / 最终提交源码

This is a source component, not a complete contest submission or accuracy/safety
certification. Consult the accompanying delivery manifest. Version bytes are read
from this source; fixed ZIP timestamps are reproducibility metadata, not a release date.

## Run / 실행 / 运行

On Apple Silicon macOS, with uv installed:

```sh
bash scripts/setup.sh
.venv/bin/python scripts/download_candidate_model.py
bash scripts/run_competition.sh
```

Model weights and Python dependencies are separate downloads. The downloader uses
the repository's pinned model revision/hashes. An already verified installation may
set KITGUARD_MODEL_PATH instead. Open http://127.0.0.1:8765/?new=photo-document
for a local JPEG/PNG/WebP photo with a required source statement, or
http://127.0.0.1:8765/static/demo.html for the three included development examples.
Follow docs/v0.8/PHOTO_DOCUMENT_GUIDE_KO_ZH.md. A URL is a statement, not a download.
User-declared source/license remain unverified. Digital review is not physical
completion; order revision requires explicit same-photo reuse and a new inspection.

The UI starts without weights. Actual inference requires the separate local model
and adequate memory. Windows/Linux inference and clean-machine installation are
not established by the package smoke test. That test uses existing dependencies,
synthetic pixels and HTTP contracts only; no MLX/model call or human participation.

## Submission reproduction / 제출 재현 / 提交复现

Unzip the source and run all commands from the `KitGuard/` directory. Code version
is `0.9.0.dev4`; this documentation was revised on 2026-10-05 KST. This source is
one component of the accompanying five-material submission. Use this page for
installation and its submission manifest for the report, video and slides.
The source's development version and previously disclosed evidence limits remain.

The verified machine is Apple Silicon macOS, M5 Pro, 64 GB unified memory,
Python 3.12. `scripts/setup.sh` checks macOS/arm64, requires `uv`, creates a local
`.venv` with Python 3.12 and installs the exact `requirements-lock.txt` versions,
then installs this source without resolving dependencies again. First setup needs
network access for Python/packages that are not already cached. The ZIP contains
neither `.venv` nor model weights. No API key or paid cloud model is required.

The model downloader needs network access and anonymously fetches the fixed
`mlx-community/Qwen3.6-27B-4bit` revision
`c000ac2c2057d94be3fa931000c31723aac53282`. Its 16-file snapshot totals
16,081,490,064 bytes; allow additional disk space for dependencies and temporary
download chunks. It verifies every file's size and SHA-256, compares LFS payloads
with upstream SHA-256 and other files with upstream Git blob SHA-1, and checks the
weight index against the three actual shards. It also verifies the upstream
Apache-2.0 declaration and preserves the original license and model card under
`models/licenses/Qwen3.6-27B/`. Included attribution and license text are under
`third_party/models/`. File integrity verification does not establish accuracy.

On this project's existing verified installation, skip setup and download:

```sh
bash scripts/run_competition.sh
```

For a newly unzipped source directory, run setup first. If the fixed verified model
already exists elsewhere, skip its download and launch with its absolute path:

```sh
KITGUARD_MODEL_PATH=/absolute/path/to/Qwen3.6-27B-4bit \
  bash scripts/run_competition.sh
```

The default model path is this source directory's `models/Qwen3.6-27B-4bit/`.
Old absolute paths in preserved provenance records describe their original
acquisition location; the launcher uses the current project path above. Keep one
server and one model worker. The launcher uses `spatial_guarded`, 1536-pixel main
inputs, offline model loading and `data-competition-v09/` for new local state.
Keep that directory when restarting. The first actual check loads the model;
file availability and model-loaded status are different. Stop with Ctrl+C.

For the shortest reproducible demonstration, open
http://127.0.0.1:8765/static/autonomy.html and run the three public-photo scenarios.
The ZIP already includes their exact three development photographs at the paths
listed below; no dataset download or manual image copying is needed. Each model
check executes locally. Results can be differences, insufficient evidence or
matching quantities. The declared R1-to-R2 scenario explicitly reuses its photo
and runs a fresh check; it does not show a physical repair. Download the evidence
ZIP, unzip it and open `index.html` to inspect the saved photos, order versions,
model results and tool steps without the server.

For a current photo-document goal, open
http://127.0.0.1:8765/?new=photo-document, register a local image with its source
statement and BOM, then use the order's autonomous-review action. The goal binds
the current order/revision/evidence/photo; an outdated goal is rejected. See
`docs/scoring/DEV4_HANDOFF.md` for the two paths and failure recovery.

The accompanying CPU acceptance uses an isolated directory, existing dependencies
and synthetic observers; it proves import, HTTP and state contracts. The separate
actual MLX/browser records prove local execution on the verified machine. These
scopes do not prove a clean-machine install, another operating system, new-photo
accuracy or human productivity. Current limitations remain 0 human participants,
0 physical completions and the disclosed three errors on the 51-photo assessment.

After setup, reproduce the packaged autonomous/photo-document CPU contracts:

```sh
cpu_review_dir=$(mktemp -d)
KITGUARD_DATA_DIR="$cpu_review_dir" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
  .venv/bin/python -m pytest -q -p no:cacheprovider \
  tests/test_autonomy.py tests/test_photo_documents.py
```

These tests use injected synthetic observers and temporary state, without loading
the model or adding photographic accuracy evidence. Some other historical tests
require the external research artifacts described below.

Current source/AI disclosure and presentation wording are in
`docs/scoring/SOURCE_AI_DISCLOSURE_KO.md` and
`docs/scoring/PRESENTATION_SCRIPT_KO.md`.

## Included demo photographs

| ID | Package path | Source |
| --- | --- | --- |
| bag-revision | datasets/raw/mvtec_loco_ad/screw_bag/train/good/016.png | https://www.mvtec.com/research-teaching/datasets/mvtec-loco-ad |
| small-part | datasets/derived/v0.3/screws_views/v03-screws-screws_222-56eea59f64ca.png | https://www.mvtec.com/research-teaching/datasets/mvtec-screws |
| mixed-screws | datasets/derived/v0.3/screws_views/v03-screws-screws_344-8d389e404b12.png | https://www.mvtec.com/research-teaching/datasets/mvtec-screws |

Retain MVTec attribution and CC BY-NC-SA 4.0 terms in third_party/datasets/.
Two Screws samples are integer crops with recorded source and annotation hashes;
SOURCE_MANIFEST.json includes crop provenance. The three images are previously
exposed development examples, not new holdout evidence or user feedback. No new
reference crops, FOD/MANTA photos or original training/evaluation collections are bundled.

## External research evidence

EXTERNAL_ARTIFACT_INDEX.json records explicitly omitted research metadata and
historical source text with project-relative path, byte size, SHA-256 and purpose.
Nested frozen source snapshots and normalized evaluation images are external;
small freeze metadata may remain as a dependency map. Excluded evaluation/training
images are not read; the three listed demo images are read and hashed. Full run/raw
outputs, weights and exposure records are also external.
Restoring the correct hashes is required for research replay. This ZIP alone cannot
reproduce all reported experiments. Data-dependent tests may need those artifacts.
Repository-relative links to test-results/evaluation-runs may be absent here; use
the accompanying delivery evidence index rather than interpreting them as packaged.

Private SQLite databases, user uploads, runtime directories and credentials are not
included. Unknown oversized source files fail; no file is dropped because of size.
Every bundled file is listed with byte size and SHA in SOURCE_MANIFEST.json.

## Rebuild to a new path

```sh
.venv/bin/python -m scripts.v09.package_source \
  --output /new/path/kitguard-source-preview.zip --verify-runtime
```

The ZIP and its .manifest.json, .sha256 and .verification.json sidecars must be new.
The same bytes and Python/zlib toolchain yield the same archive. Integrity hashes
are not identity signatures, authorization, or proof of physical capture.

## v0.9 review workflow

See docs/v0.9/DEMO_AND_HANDOFF_ZH.md and docs/v0.9/RELEASE_NOTES.md. The independent point review preserves original AI, expires on changed evidence/opinions, and exports both count tables and original-photo point positions.
Public-photo digital tasks: open /static/digital-trials.html. Six fixed tasks per participant, manual/KitGuard order alternation, server timing including inference, current-version checks, and full planned denominators. Engineering rehearsals are never human results.
Autonomous mission: open /static/autonomy.html. One operator can run all three public-photo scenarios; real local inference, conditional routing, declared R2 replay, persistent execution and evidence ZIP. No participants needed.
Current photo-document goal: use the order detail's autonomous-review link. The accepted goal binds order ID, revision, evidence epoch and photo ID; the worker also verifies the accepted content. It runs one fresh inspection without rewriting the BOM. Failed execution preserves input and error, without inventing a model result. See docs/scoring/DEV4_HANDOFF.md.
Five machine tasks and CPU version-binding ablation are engineering evidence, not human efficiency or new-photo accuracy. Final grading ledger and raw execution artifacts accompany this ZIP. Source smoke uses existing dependencies; it does not certify clean-machine installation.
