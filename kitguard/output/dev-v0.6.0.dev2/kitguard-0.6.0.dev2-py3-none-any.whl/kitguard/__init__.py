"""KitGuard local application."""

__version__ = "0.6.0.dev2"
