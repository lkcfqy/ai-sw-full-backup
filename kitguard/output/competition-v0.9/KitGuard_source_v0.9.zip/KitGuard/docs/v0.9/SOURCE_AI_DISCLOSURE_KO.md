# KitGuard 출처와 AI 활용 공개

팀 해피 / 0.9.0.dev1 / 2026-10-03. 이 문서는 신고 내용의 보충 자료이며 서명·접수 확인서가 아니다.

실제 개발은 2026-09-26 시작했다. 공식 개발기간 09-29~10-06 이전의 사진 처리·공간 관찰·회전/국소 확인·주문·증거 엔진을 재사용했다. 09-30 이후 비동기 검사·복구, 자료 주문, 디지털 의견, 주문 개정과 동일 사진 새 추론, 참고 입력 추적을 추가했다. 10-03에는 사진 위 위치 표시 복검 결론, 의견 변경 시 결론 만료, 독립 AI/복검 수량 표와 오프라인 위치 근거를 추가했다. 정확한 09-29 코드 스냅샷이나 사람별 작성 비율을 보유했다고 주장하지 않는다.

OpenAI Codex를 팀 지시에 따른 코드 생성·수정, 테스트 작성·실행, 연구 분석, 브라우저 조작, 한국어 보고서·발표자료·영상 대본 제작에 광범위하게 사용했다. 자동화 조작자의 이름은 ENGINEERING-AGENT이며 기능 리허설로 표시했다. 실제 사용자 참여나 팀원이 전부 직접 작성한 코드로 표현하지 않는다. 현재 개발은 하위 에이전트에 위임하지 않았다. 이전 실험의 AI 독립 복산은 사람 검토가 아니다.

현재 제품 추론은 기존 장비 Apple M5 Pro 64GB에서 Qwen3.6-27B의 MLX community 4-bit 변환을 사용한다. 기본 VLM을 새로 학습하거나 미세조정하지 않았다. 별도 검출기·분류기 연구 학습은 있었고, 이전 연구 결과와 한계는 아래 기록에 유지한다. 이번 신규 기능이 모델 인식 정확도를 높였다고 주장하지 않는다.

## 원출처와 조건

| 자산 | 원출처와 사용 |
|---|---|
| Qwen3.6-27B / MLX community 4-bit | https://huggingface.co/Qwen/Qwen3.6-27B 및 https://huggingface.co/mlx-community/Qwen3.6-27B-4bit . 저장된 Apache-2.0 고지·모델 manifest를 따른다. 가중치는 소스 ZIP에 포함하지 않는다. |
| MVTec LOCO AD / Screws | https://www.mvtec.com/research-teaching/datasets/mvtec-loco-ad 및 https://www.mvtec.com/research-teaching/datasets/mvtec-screws . CC BY-NC-SA 4.0: https://creativecommons.org/licenses/by-nc-sa/4.0/ . 공개 개발 예시3장과 해당 파생 화면의 출처·조건을 유지한다. |
| 현재 시연 원사진 | screw_bag/train/good/016.png. 기존에 노출된 같은 개발 사진이다. 스크린샷은 실제 저장 화면이며 원사진을 재촬영·생성하지 않았다. 그림 위 표시와 요구 변경은 기능 리허설이다. |
| 제품 라이브러리 | FastAPI, Uvicorn, Pydantic, Pillow, MLX/MLX-VLM, Transformers, SQLite 등. 정확한 버전은 requirements-lock.txt 및 docs/v0.8/PACKAGE_METADATA_20261002.json 참조. |
| 제작 도구 | ReportLab, Artifact Tool, FFmpeg 및 macOS Yuna 합성 음성. 영상은 실제 화면 캡처를 편집하고 대기 시간을 생략한 설명 영상이며 연속 조작 녹화나 사람 목소리로 표시하지 않는다. |

기존 자산 전체의 모델·자료·버전·권리 기록은 `docs/v0.8/SOURCE_AI_DISCLOSURE_KO_20261002.md`와 `SOURCE_AI_DISCLOSURE_ADDENDUM_20261002_1238.md`를 함께 읽는다. 후속 MANTA 분류기 연구는 완료됐으나 교차 출처 진단에서 실패하여 기본 제품에 미채택했다. 해당 옛 초안의 “진행 중” 표기는 그 문서 작성 시점의 상태다.

비상업 연구 자료를 향후 유료 고객 서비스용 데이터 권리로 확대하지 않는다. 고객 도입은 권리를 확보한 별도 자료로 검증해야 한다. 사용자 입력 출처는 미인증 진술이다. 소스 ZIP에는 모델 가중치·개인 DB·연구 전체 사진을 넣지 않는다. 공개 시연 증거 ZIP은 별도 자료로 포함한다.

성과는 기존51 C41/W3/U7, LOCO24 C23/W0/U1로 분리한다. 이번 2회 실제 검사와 1,826개 소프트웨어 회귀는 새 정확도 분모가 아니다. 실제 참여자 0명, 실물 완료 0건, 효율 향상·매출·구매 의향은 미측정이다.
