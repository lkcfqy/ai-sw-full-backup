#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
exec bash scripts/run_detector_lab.sh
