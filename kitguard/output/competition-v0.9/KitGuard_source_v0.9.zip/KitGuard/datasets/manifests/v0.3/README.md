# v0.3 数据清单入口

**仅使用** [CANONICAL_NEW_SOURCE_BENCHMARK_V1.json](./CANONICAL_NEW_SOURCE_BENCHMARK_V1.json)：12 个 Screws 开发裁剪 + 32 个 Screws 留出裁剪 + 原先固定的 LOCO32 留出原图。所有 76case 已通过项目 `read_manifest` / `validate_case`；图像实际存在，SHA 匹配。

SHA-256：`85f331c47d50256e1e98c3b346bef109e30a98e7e101da6ea3f46c9b7b3dcaf2`。

- [权威文件索引](./CANONICAL_FILES.json)
- [独立检查结果](./FINAL_DATA_AUDIT.json)
- [已运行开发子清单与权威清单的逐字段等价审计](./DEVELOPMENT_MANIFEST_EQUIVALENCE.json)
- [完整协议与边界](../../../docs/v0.3/NEW_PUBLIC_DATA_PROTOCOL.md)
- [仅开发集的联系表](../../../docs/v0.3/SCREWS_DEVELOPMENT_CONTACT_SHEET.png)
- [实际派生图说明](../../derived/v0.3/README.md)

根目录的 Screws crop_specs 是初步探索，不是 runner 输入。`source_grouped_v2` 中的 Screws benchmark 是已物化的子集；该目录另有由新 seed 机械产生的 LOCO 候选，**不用于本轮评测**。最终合并清单保留根目录最初 `loco_new_holdout_v1.json` 的 LOCO32，而不是在模型推理后改选。

旧 v0.2 文件未动。新留出必须等 v0.3 模型协议冻结后再运行。没有把裁剪当原图、同源多图当独立样本、合成订单当真实订单，也没有模型生成的真值。
