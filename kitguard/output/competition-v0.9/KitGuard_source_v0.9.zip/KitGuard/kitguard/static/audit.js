/* Read-only inspection audit. Derived explanations are identified separately from stored facts. */
'use strict';

const AUDIT_STRINGS = {
  ko: {
    verificationTitle: '동일 모델의 두 방향 관찰', spatialVerificationTitle: '동일 모델의 두 방향 물체 목록 대조', spatialVerificationNote: '같은 사진을 원래 방향과 반시계 90° 방향으로 같은 모델에 제시하여 각각 물체 목록을 작성한 기록입니다. 수량이 다르거나 불확실성이 남으면 추가 촬영을 요청합니다. 두 호출은 관련되어 있으며 독립 전문가 검증이나 정확도 확률이 아닙니다. 두 목록이 함께 틀릴 수도 있습니다.', spatialFrameNote: '각 호출의 물체 좌표는 해당 호출의 이미지 방향에 속합니다. 회전 방향의 좌표를 원본 사진 위에 그대로 겹치지 않습니다. 위 사진의 번호는 첫 번째 원본 방향 목록만 표시합니다. 사각형은 추정 보완 촬영 영역이며 검증된 탐지 경계가 아닙니다.', spatialRegion: '추정 보완 촬영 영역', verificationNote: '같은 사진을 원래 방향과 회전 방향으로 같은 모델에 제시한 기록입니다. 두 호출은 서로 관련되어 있으며, 독립 전문가의 검증이나 정확도 확률이 아닙니다. 일치해도 함께 틀릴 수 있습니다.', verificationImageNote: '입력 해시는 각 호출에 전달한 이미지 파일을 구분합니다. 회전 이미지는 새로운 실물 촬영이나 물리 작업의 증거가 아닙니다.', verificationMode: '관찰 방식', verificationCounts: '수량 일치', verificationClear: '모두 명확한 상태에서 일치', verificationYes: '예', verificationNo: '아니요', verificationMissing: '기록 없음', verificationOriginal: '원래 방향', verificationRotated: '반시계 90° 회전', verificationPass: '관찰 {number}', verificationInputHash: '호출 입력 SHA-256', verificationIssues: '저장된 확인 사항', verificationAction: '저장된 행동 안내', verificationPassesMissing: '각 방향의 관찰 세부정보가 저장되지 않았습니다.', step_compare_orientation_observations: '두 방향의 관찰 수량·불확실성 대조', step_derive_counts_from_object_list: '저장된 물체 목록에서 프로그램으로 수량 계산',
    checkSnapshotBasis: '이 검증에 저장된 R{revision} 요구사항', feedbackTitle: '증거 보완 피드백', feedbackSnapshot: 'R{revision} 검증 당시 저장된 피드백입니다.', contextUncertain: '이전의 불명확한 부품', feedbackEmpty: '이 검증에는 비교 가능한 이전 사진의 피드백이 없습니다.', feedbackUnrecorded: '이전 형식의 기록에 증거 보완 피드백이 저장되지 않았습니다.', physicalLimit: '두 이미지의 관찰 결과만 비교합니다. 실제 부품 이동·보충 작업을 수행했는지는 증명하지 않습니다.', previousEvidence: '이전 사진', newEvidence: '이번 사진', previousCheck: '이전 검증 상세', previousAction: '이전 행동 안내', resolvedUncertainties: '새로 확인된 부품', remainingUncertainties: '아직 불명확한 부품', remainingMismatches: '남은 수량 차이', noneRecorded: '없음', noObservedChanges: '두 관찰 사이에 저장된 수량 변화가 없습니다.', observedChanges: '저장된 관찰 변화', beforeObservation: '이전 관찰', afterObservation: '이번 관찰', current_requirements_match: '이번 사진의 수량 일치', evidence_improved_quantity_mismatch: '관찰 개선 · 수량 차이 남음', evidence_still_unclear: '추가 확인 필요', quantity_mismatch_remains: '수량 차이 남음', action_none: '추가 행동 없음', action_separate: '분리 배치', action_recapture: '다시 촬영', action_add_remove: '추가·제거 후 재촬영', action_manual: '수동 확인', traceTitle: '실제 실행 단계', traceNote: '서버가 저장한 프로그램 실행 기록입니다. 모델의 내부 추론이나 작업자의 실제 행동 기록이 아닙니다.', traceEmpty: '이 검증에 저장된 실행 단계가 없습니다.', step_observe_image: '이미지 관찰', step_compare_current_requirements: '당시 주문 수량 대조', step_review_previous_evidence: '이전 증거와 비교', step_choose_next_action: '다음 행동 결정', step_commit_current_evidence: '버전·증거 상태 재검사 후 저장', step_completed: '실행 완료', step_not_applicable: '해당 없음', stepUnknown: '기록된 상태', rawStep: '저장된 단계 필드', contextTitle: '저장된 관찰 주의 정보', contextNote: '이전의 불명확한 부품과 행동 종류를 저장한 항목입니다. 실제 모델이 이 항목을 활용했음을 보증하지 않습니다.', referencesThen: '당시 연결된 기준 사진', referencesUnrecorded: '이전 기록에는 기준 사진 ID가 없습니다. 현재 기준 사진으로 대체하지 않습니다.', referenceAbsent: '연결 없음', referenceMissing: '사진 기록 없음', hashMismatch: '검증에 저장된 이미지 해시와 사진 기록의 해시가 다릅니다. 원본 JSON을 확인하세요.',
    records: '검증 기록', events: '작업 이벤트', recordCount: '{count}회', emptyTitle: '아직 저장된 검증이 없습니다', emptyBody: '사진 검증이 응답하면 당시 주문, 사진과 관찰 결과를 여기에서 확인할 수 있습니다. 실패한 요청은 작업 이벤트에 남습니다.',
    ready: '수량 일치', recapture: '증거 보완', correct: '부품 조정', manual: '수동 확인', unknown: '기록 확인 필요', effective: '현재 증거', invalid: '이전 기록', test: '테스트 기록', detail: '검증 기록 상세', openDetail: '검증 상세 보기', capturedAt: '검증 시각', snapshotAt: '상태 조회 시각', currentAtRead: '조회 시점의 현재 버전', readonly: '읽기 전용 기록입니다. 이 창에서는 현재 작업지시를 완료하거나 과거 결과를 다시 적용할 수 없습니다.', storedDecision: '당시 검증 결과', validity: '현재 사용 가능 여부', validReason: '서버의 유효 표시, 현재 주문 버전, 최신 사진 및 검증 기록이 일치합니다. 완료 처리는 현재 작업 화면에서 실물을 확인한 뒤 진행해야 합니다.', invalidReason: '이 결과를 현재 작업지시의 완료 근거로 사용할 수 없습니다.', explanationNote: '아래 설명은 저장된 버전·사진·이벤트 관계를 바탕으로 표시합니다. 별도로 저장된 모델 추론 내용은 아닙니다.',
    versionChanged: '작업지시가 R{before}에서 R{after}(으)로 변경되었습니다.', photoChanged: '이 검증 뒤에 다른 사진이 등록되었습니다.', referenceChanged: '이 검증 뒤에 기준 부품 사진이 변경되었습니다.', inspectionRestarted: '이 검증 뒤에 새 검증이 시작되어 이전 결과가 무효화되었습니다.', superseded: '더 새로운 검증 결과가 있습니다.', activeInspection: '새 검증이 진행 중입니다.', epochChanged: '검증에 연결된 증거 상태가 현재 상태와 다릅니다.', serverInvalidated: '서버가 이 기록을 무효로 표시했습니다. 제공된 이력만으로 더 구체적인 원인을 확정할 수 없습니다.', stateUnknown: '현재 사용에 필요한 상태 정보가 부족합니다. 과거 기록으로만 확인하세요.', testReason: '테스트 백엔드에서 생성된 엔지니어링 기록으로, 실제 모델 검증이나 생산 완료의 근거가 아닙니다.',
    requirementsThen: '당시 요구사항', observedThen: '당시 관찰', differenceThen: '당시 차이', versionBasis: '저장된 R{revision} 요구사항 기준', differenceBasis: '버전 스냅샷이 없어 저장된 차이 항목의 요구 수량을 표시합니다.', missingRequirements: '당시 요구 수량을 확인할 수 없습니다. 현재 주문 수량으로 대체하지 않습니다.', inconsistent: '저장된 요구사항·관찰·차이 값 사이에 불일치가 있습니다. 원본 JSON과 이벤트를 확인하세요.', noDifference: '일치', unavailable: '미확인', photoThen: '검증에 사용된 사진', noPhoto: '해당 사진 기록을 찾을 수 없습니다.', openPhoto: '사진 크게 보기', photoId: '사진 ID', photoHash: '저장 이미지 SHA-256', photoRecorded: '사진 등록 시각', hashNote: '해시는 저장 파일의 식별값입니다. 촬영 시점이나 같은 실물임을 보증하지 않습니다.', actionThen: '당시 안내한 행동', noAction: '추가 행동 없음', noActionRecord: '저장된 행동 안내가 없습니다.', issuesThen: '당시 확인 사항', noIssues: '저장된 추가 확인 사항이 없습니다.',
    runDetails: '실행 정보', checkId: '검증 ID', orderId: '작업지시 ID', model: '모델', backend: '실행 백엔드', latency: '저장된 처리시간', latencyValue: '{seconds}초', epoch: '검증 증거 버전', evidenceNow: '현재 증거 버전', inputsAndRun: '입력 및 실행 이벤트', laterEvents: '이후 관련 이벤트', noLinkedEvents: '직접 연결할 수 있는 이벤트가 없습니다.', linkedEventsNote: '사진·검증 ID, 주문 버전과 이벤트 순서로 연결한 항목만 표시합니다.', completion: '이 기록에 연결된 작업자 확인', completionSaved: '작업자 확인 후 완료 기록이 저장되었습니다.', completionRetained: '과거 완료 기록은 보존됩니다. 이후 변경된 작업지시의 완료를 의미하지 않습니다.', noCompletion: '이 검증에 연결된 완료 기록이 없습니다.', receiptId: '완료 기록 ID', reason: '저장된 사유', loading: '저장된 검증과 최신 상태를 읽고 있습니다.', error: '검증 기록을 읽을 수 없습니다.', missingCheck: '선택한 검증 기록이 응답에 없습니다.', reload: '상태 다시 조회', export: '전체 원본 JSON', close: '닫기', region: '당시 추가 확인 영역', versionInstruction: '당시 작업지시 설명', validFlag: '서버 유효 표시', true: '유효', false: '무효', historical: '과거 확인 결과', tabs: '기록 보기', newWindow: '새 창', metadata: '사진 메타데이터', eventDetails: '이벤트 세부정보', inspectStarted: '검증 시작', inspectFinished: '검증 응답 저장'
  },
  zh: {
    verificationTitle: '同一模型的双方向观察', spatialVerificationTitle: '同一模型的双方向物体清单核对', spatialVerificationNote: '这是同一张照片以原始方向和逆时针 90° 方向交给同一模型，分别生成物体清单的记录。数量冲突或仍有不确定性时请求补拍。两次调用具有相关性，不是独立专家核验或准确率概率；两份清单仍可能一起出错。', spatialFrameNote: '每轮物体坐标属于该轮图像方向，不会把旋转方向的点直接叠在原图上。上方照片编号仅使用首轮原图清单。矩形只是估计补拍区域，不是已验证的检测边界。', spatialRegion: '估计补拍区域', verificationNote: '这是同一张照片以原始方向和旋转方向交给同一模型的记录。两次调用具有相关性，不是独立专家核验，也不是准确率概率；两次一致仍可能同时出错。', verificationImageNote: '输入哈希标识每次调用收到的图像文件。旋转图像不是重新拍摄的实物照片，也不能证明实际物料操作。', verificationMode: '观察方式', verificationCounts: '数量一致', verificationClear: '均明确且一致', verificationYes: '是', verificationNo: '否', verificationMissing: '未记录', verificationOriginal: '原始方向', verificationRotated: '逆时针旋转 90°', verificationPass: '第 {number} 次观察', verificationInputHash: '调用输入 SHA-256', verificationIssues: '已保存的检查问题', verificationAction: '已保存的操作建议', verificationPassesMissing: '未保存各方向的观察详情。', step_compare_orientation_observations: '比较两个方向的观察数量与不确定性', step_derive_counts_from_object_list: '由程序从已保存物体清单计算数量',
    checkSnapshotBasis: '该次核验保存的 R{revision} 需求', feedbackTitle: '补证反馈', feedbackSnapshot: '以下为 R{revision} 核验时保存的反馈。', contextUncertain: '上次不明确的零件', feedbackEmpty: '本次核验没有可比较的上一张照片反馈。', feedbackUnrecorded: '这条旧格式记录未保存补证反馈。', physicalLimit: '仅比较两次图像观察，不能证明实际物料操作。', previousEvidence: '上一次照片', newEvidence: '本次照片', previousCheck: '查看上一次核验', previousAction: '上一次操作建议', resolvedUncertainties: '现已可观察', remainingUncertainties: '仍不明确', remainingMismatches: '仍有数量差异', noneRecorded: '无', noObservedChanges: '两次观察之间没有保存的数量变化。', observedChanges: '已保存的观察变化', beforeObservation: '上次观察', afterObservation: '本次观察', current_requirements_match: '本次照片数量相符', evidence_improved_quantity_mismatch: '观察改善 · 仍有数量差异', evidence_still_unclear: '仍需补充证据', quantity_mismatch_remains: '数量差异仍存在', action_none: '无需追加操作', action_separate: '分开放置', action_recapture: '重新拍摄', action_add_remove: '补充或取出后重拍', action_manual: '人工核验', traceTitle: '实际执行步骤', traceNote: '这是服务器保存的程序执行记录，不是模型内部推理或操作者实际动作的记录。', traceEmpty: '本次核验未保存执行步骤。', step_observe_image: '观察图像', step_compare_current_requirements: '比对当时订单数量', step_review_previous_evidence: '比较先前证据', step_choose_next_action: '确定下一步操作', step_commit_current_evidence: '重新检查版本与证据状态后保存', step_completed: '执行完成', step_not_applicable: '不适用', stepUnknown: '记录的状态', rawStep: '已保存的步骤字段', contextTitle: '保存的观察关注信息', contextNote: '记录上次不明确的零件和操作类型，不保证模型实际利用了这些信息。', referencesThen: '当时关联的参考照片', referencesUnrecorded: '旧记录没有保存参考照片 ID，不会用当前参考图替代。', referenceAbsent: '未关联', referenceMissing: '照片记录缺失', hashMismatch: '核验保存的图片哈希与照片记录不同，请核对原始 JSON。',
    records: '核验记录', events: '操作事件', recordCount: '{count} 次', emptyTitle: '尚无已保存的核验', emptyBody: '照片核验返回结果后，可在这里查看当时的订单、照片和观察结果。失败请求保留在操作事件中。',
    ready: '数量一致', recapture: '需要补证', correct: '调整零件', manual: '人工核验', unknown: '记录待核实', effective: '当前证据', invalid: '历史记录', test: '测试记录', detail: '核验记录详情', openDetail: '查看核验详情', capturedAt: '核验时间', snapshotAt: '状态查询时间', currentAtRead: '查询时的当前版本', readonly: '这是只读记录，不能在此完成当前工单或重新应用过去的结果。', storedDecision: '当时核验结果', validity: '当前能否继续使用', validReason: '服务器有效标记、当前订单版本、最新照片和核验记录一致。完成操作仍需在当前工作台人工核对实物。', invalidReason: '此结果不能用作当前工单的完成依据。', explanationNote: '下方解释来自已存版本、照片和事件的关系，不是额外保存的模型推理内容。',
    versionChanged: '工单已从 R{before} 更新为 R{after}。', photoChanged: '本次核验之后已登记其他照片。', referenceChanged: '本次核验之后参考零件照片已改变。', inspectionRestarted: '本次核验之后已启动新的核验，旧结果失效。', superseded: '已有更新的核验结果。', activeInspection: '新的核验正在进行。', epochChanged: '核验绑定的证据状态已不同于当前状态。', serverInvalidated: '服务器已将此记录标记为失效，现有历史不足以确定更具体的原因。', stateUnknown: '缺少判断当前可用性所需的状态信息，仅供历史查阅。', testReason: '这是测试后端生成的工程记录，不能作为真实模型核验或生产完成的依据。',
    requirementsThen: '当时需求', observedThen: '当时观察', differenceThen: '当时差异', versionBasis: '采用已保存的 R{revision} 需求', differenceBasis: '缺少版本快照，以下需求取自该次核验保存的差异项。', missingRequirements: '无法确认当时的需求数量，不会用当前订单替代。', inconsistent: '已保存的需求、观察或差异数值存在不一致，请核对原始 JSON 与事件。', noDifference: '一致', unavailable: '未确认', photoThen: '本次核验使用的照片', noPhoto: '未找到对应照片记录。', openPhoto: '查看大图', photoId: '照片 ID', photoHash: '存储图片 SHA-256', photoRecorded: '照片登记时间', hashNote: '哈希用于标识保存的文件，不能证明真实拍摄时间或同一实物。', actionThen: '当时建议的操作', noAction: '无需追加操作', noActionRecord: '没有已保存的操作说明。', issuesThen: '当时发现的问题', noIssues: '没有已保存的其他问题。',
    runDetails: '运行信息', checkId: '核验 ID', orderId: '工单 ID', model: '模型', backend: '运行后端', latency: '记录的处理耗时', latencyValue: '{seconds} 秒', epoch: '核验证据版本', evidenceNow: '当前证据版本', inputsAndRun: '输入与执行事件', laterEvents: '后续关联事件', noLinkedEvents: '没有可直接关联的事件。', linkedEventsNote: '只展示通过照片、核验 ID、订单版本和事件顺序关联的条目。', completion: '与本记录关联的人工确认', completionSaved: '人工确认后已保存完成记录。', completionRetained: '历史完成记录仍保留，不代表之后改版的工单已经完成。', noCompletion: '没有与本次核验关联的完成记录。', receiptId: '完成记录 ID', reason: '保存的原因', loading: '正在读取已存核验与最新状态。', error: '无法读取核验记录。', missingCheck: '响应中没有所选的核验记录。', reload: '重新查询状态', export: '完整原始 JSON', close: '关闭', region: '当时需要补证的区域', versionInstruction: '当时的工单说明', validFlag: '服务器有效标记', true: '有效', false: '失效', historical: '历史核验结果', tabs: '查看记录', newWindow: '新窗口', metadata: '照片元数据', eventDetails: '事件详情', inspectStarted: '开始核验', inspectFinished: '保存核验结果'
  }
};
function at(key, values = {}) { let text = AUDIT_STRINGS[state.lang][key] || key; for (const [name, value] of Object.entries(values)) text = text.replaceAll(`{${name}}`, String(value)); return text; }
Object.assign(AUDIT_STRINGS.ko, {
  identityTitle: '국소 부품 종류·구멍 형태 재확인', identityNote: '첫 관찰에서 선택된 지점을 같은 모델이 전체 사진과 확대 자르기로 다시 본 기록입니다. 후보 선택과 재확인은 관련되어 있으며 독립 전문가 검증이 아닙니다. 누락된 물체는 이 단계에서 찾아내지 못할 수 있습니다.',
  identityLimit: '위치와 구멍 형태는 모델의 추정입니다. 자르기·LANCZOS 확대는 새로운 시각 정보를 만들지 않으며 실제 물품 상태를 증명하지 않습니다. 충돌한 종류는 수량 미확인으로 처리하며, 이 화면은 수량을 자동 수정하거나 물체를 삭제하지 않습니다.',
  identityBlocked: '수량을 미확인으로 처리한 종류', identityPoint: '검토 지점', identityClasses: '원래 분류 → 재확인 분류', identityStatus: '물체의 관계', identityOpening: '구멍 형태', identityIssue: '저장된 확인 사항', identityUnknown: '미확인', identityNoIssue: '저장된 문제 없음', identityLocate: '사진에서 #{number} 보기', identityCoordinates: '원본 위치', identityRecordMissing: '연결된 지점 또는 응답 기록이 불완전합니다. 원본 JSON을 확인하세요.', identityMappingNote: '사진 번호는 첫 번째 물체 목록의 순서입니다. 검토 ID와 트레이 번호는 다를 수 있습니다. 연결된 좌표·종류가 일치하는 항목만 원본 사진에서 찾을 수 있습니다.',
  identityIndependent: '독립된 물체', identityAttached: '다른 물체의 일부', identityNoObject: '물체 없음', identityUncertain: '불명확', identityThrough: '관통 구멍', identityClosed: '막힌 홈', identityNotApplicable: '해당 없음',
  identityInputs: '입력·자르기 출처 보기', identityProtocol: '저장된 프로토콜', identityCorrelated: '동일 모델의 관련 호출', identityFullHash: '전체 모델 입력 SHA-256', identitySourceHash: '자르기 원본 SHA-256', identityPixelHash: '원래 픽셀 자르기 SHA-256', identityCropHash: '보간 모델 입력 SHA-256', identityRect: '원본 픽셀 자르기 범위', identitySourceSize: '원본 크기', identityPixelSize: '원래 자르기 크기', identityCropSize: '모델 입력 크기', identityCropCenter: '자르기 내 검토 지점', identityResampling: '확대·축소 방식', identityFilesNote: '파일명과 해시는 저장된 입력의 식별 기록입니다. 자르기 파일이 현재 별도 다운로드로 제공됨을 뜻하지 않습니다.', identityFile: '기록된 모델 입력 파일', identityPixelFile: '기록된 픽셀 자르기 파일'
});
Object.assign(AUDIT_STRINGS.zh, {
  identityTitle: '局部身份与孔形复核', identityNote: '这是同一模型根据首轮选定的位置，同时查看完整照片与放大裁剪的记录。候选选择和复核具有相关性，不是独立专家核验；未被首轮列出的物体仍可能遗漏。',
  identityLimit: '位置和孔形均为模型估计。裁剪及 LANCZOS 插值放大不会创造新的视觉信息，也不能证明实物状态。冲突类别被置为数量未知；本界面不会自动修正数量或删除物体。',
  identityBlocked: '被置为数量未知的类别', identityPoint: '复核点', identityClasses: '原类别 → 复核类别', identityStatus: '物体关系', identityOpening: '孔形', identityIssue: '保存的问题', identityUnknown: '未明确', identityNoIssue: '未记录问题', identityLocate: '在照片中查看 #{number}', identityCoordinates: '原图位置', identityRecordMissing: '关联的点位或响应记录不完整，请核对原始 JSON。', identityMappingNote: '照片编号对应首轮物体清单顺序，可能与复核 ID 不同，也不是真实托盘编号。只有关联坐标和类别一致的记录才能在原图定位。',
  identityIndependent: '独立物体', identityAttached: '其他物体的附属特征', identityNoObject: '没有物体', identityUncertain: '不明确', identityThrough: '贯通孔', identityClosed: '封闭凹槽', identityNotApplicable: '不适用',
  identityInputs: '查看输入与裁剪来源', identityProtocol: '保存的协议', identityCorrelated: '同模型相关调用', identityFullHash: '完整模型输入 SHA-256', identitySourceHash: '裁剪源图 SHA-256', identityPixelHash: '原像素裁剪 SHA-256', identityCropHash: '插值模型输入 SHA-256', identityRect: '源图像素裁剪矩形', identitySourceSize: '源图尺寸', identityPixelSize: '原始裁剪尺寸', identityCropSize: '模型输入尺寸', identityCropCenter: '裁剪内复核位置', identityResampling: '重采样方式', identityFilesNote: '文件名与哈希是已保存的输入标识，不代表这些裁剪文件目前可单独下载。', identityFile: '记录的模型输入文件', identityPixelFile: '记录的原像素裁剪文件'
});

function auditIdentityPosition(center) {
  if (!Array.isArray(center) || center.length !== 2 || center.some(n => typeof n !== 'number' || !Number.isFinite(n) || n < 0 || n > 1)) return null;
  return `x ${(center[0] * 100).toFixed(1)}% · y ${(center[1] * 100).toFixed(1)}%`;
}
function auditIdentityLocateIndex(check, photo, crop, identity) {
  const evidence = spatialEvidence(check, photo);
  if (!evidence || !Number.isInteger(crop?.object_index) || crop.object_index < 1 || crop.object_index > evidence.objects.length || !auditIdentityPosition(crop.center)) return null;
  const hash = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
  if (!hash(identity.source_sha256) || !hash(photo.sha256) || !hash(crop.source_sha256) || identity.source_sha256 !== photo.sha256 || crop.source_sha256 !== identity.source_sha256) return null;
  const object = evidence.objects[crop.object_index - 1];
  return object.part === crop.original_part && object.center.every((n, i) => Math.abs(n - crop.center[i]) < 1e-9) ? crop.object_index : null;
}
function auditIdentityMarkup(order, check) {
  const identity = check.identity_verification;
  if (!identity || typeof identity !== 'object' || Array.isArray(identity) || identity.protocol !== 'identity_geometry_v2') return '';
  const records = value => Array.isArray(value) ? value.filter(item => item && typeof item === 'object' && !Array.isArray(item)) : [];
  const items = records(identity.response?.objects), crops = records(identity.crops), photo = auditFindPhoto(order, check.photo_id);
  const statusKeys = { independent_object: 'identityIndependent', attached_feature: 'identityAttached', no_object: 'identityNoObject', uncertain: 'identityUncertain' };
  const openingKeys = { through_hole: 'identityThrough', closed_recess: 'identityClosed', uncertain: 'identityUncertain', not_applicable: 'identityNotApplicable' };
  const part = value => value === 'unknown' ? at('identityUnknown') : typeof value === 'string' ? partLabel(value) : at('verificationMissing');
  const phrase = (map, value) => typeof value === 'string' ? map[value] ? at(map[value]) : value : at('verificationMissing');
  const vector = value => Array.isArray(value) && value.every(n => typeof n === 'number' && Number.isFinite(n)) ? value.join(' × ') : null;
  const duplicate = items.some(item => items.filter(candidate => candidate.id === item.id).length !== 1);
  const incomplete = !items.length || items.length !== crops.length || duplicate || items.some(item => crops.filter(crop => crop.id === item.id).length !== 1);
  const rows = items.map(item => {
    const matching = crops.filter(crop => crop.id === item.id);
    const crop = matching.length === 1 ? matching[0] : null;
    const index = crop && !duplicate ? auditIdentityLocateIndex(check, photo, crop, identity) : null;
    const position = auditIdentityPosition(crop?.center);
    const cell = (label, text, className = '') => `<td class="${className}"><span class="identity-cell-label">${esc(at(label))}</span>${esc(text)}</td>`;
    return `<tr data-identity-row="${esc(item.id || '')}"><th scope="row"><code>${esc(item.id || at('verificationMissing'))}</code>${index ? `<button type="button" class="audit-inline-link identity-locate" data-identity-index="${index}" data-identity-binding="${esc(spatialBinding(check, photo))}">${esc(at('identityLocate', { number: index }))}</button>` : ''}${position ? `<small>${esc(position)}</small>` : ''}</th>${cell('identityClasses', `${part(crop?.original_part)} → ${part(item.part)}`, 'identity-category')}${cell('identityStatus', phrase(statusKeys, item.status))}${cell('identityOpening', phrase(openingKeys, item.opening))}${cell('identityIssue', typeof item.issue === 'string' && item.issue.trim() ? item.issue : typeof item.issue === 'string' ? at('identityNoIssue') : at('verificationMissing'), 'identity-issue')}</tr>`;
  }).join('');
  return `<section class="audit-identity" aria-labelledby="audit-identity-title"><div class="audit-section-heading"><h3 id="audit-identity-title">${esc(at('identityTitle'))}</h3>${check.backend === 'test' ? `<span class="spatial-test-label">${esc(spatialText('test'))}</span>` : ''}</div><p class="audit-verification-note">${esc(at('identityNote'))}</p><dl class="audit-identity-blocked"><div class="audit-meta-row"><dt>${esc(at('identityBlocked'))}</dt><dd>${auditPartList(identity.blocked_categories)}</dd></div></dl>${incomplete ? `<p class="audit-data-warning">${esc(at('identityRecordMissing'))}</p>` : ''}${items.length ? `<table class="identity-table"><thead><tr>${['identityPoint', 'identityClasses', 'identityStatus', 'identityOpening', 'identityIssue'].map(key => `<th scope="col">${esc(at(key))}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table>` : ''}<p class="audit-muted identity-mapping-note">${esc(at('identityMappingNote'))}</p><p class="audit-physical-limit">${esc(at('identityLimit'))}</p><details class="audit-identity-inputs"><summary>${esc(at('identityInputs'))}</summary><dl>${auditMetadata(at('identityProtocol'), identity.protocol, true)}${auditMetadata(at('identityCorrelated'), at(identity.same_model_correlated_calls === true ? 'verificationYes' : identity.same_model_correlated_calls === false ? 'verificationNo' : 'verificationMissing'))}${auditMetadata(at('identityFullHash'), identity.full_input_sha256, true)}${auditMetadata(at('identitySourceHash'), identity.source_sha256, true)}</dl>${crops.map(crop => `<details class="identity-crop"><summary>${esc(crop.id || at('verificationMissing'))} · ${esc(part(crop.original_part))}</summary><dl>${auditMetadata(at('identityCoordinates'), auditIdentityPosition(crop.center))}${auditMetadata(at('identityCropCenter'), auditIdentityPosition(crop.target_center_crop))}${auditMetadata(at('identityRect'), Array.isArray(crop.rect_source_px) ? crop.rect_source_px.join(', ') : null, true)}${auditMetadata(at('identitySourceSize'), vector(crop.source_size))}${auditMetadata(at('identityPixelSize'), vector(crop.crop_source_size))}${auditMetadata(at('identityCropSize'), vector(crop.crop_size))}${auditMetadata(at('identityResampling'), crop.resampling)}${auditMetadata(at('identityPixelHash'), crop.pixel_crop_sha256, true)}${auditMetadata(at('identityCropHash'), crop.crop_sha256, true)}${auditMetadata(at('identitySourceHash'), crop.source_sha256, true)}${auditMetadata(at('identityPixelFile'), crop.pixel_crop_file, true)}${auditMetadata(at('identityFile'), crop.crop_file, true)}</dl></details>`).join('')}<p class="audit-muted">${esc(at('identityFilesNote'))}</p></details></section>`;
}
// Optional identity buttons reuse the original-frame point layer; no order mutation.
document.addEventListener('click', event => {
  const button = event.target.closest?.('button[data-identity-index]');
  if (!button) return;
  const scope = button.closest('#audit-dialog')?.querySelector('[data-spatial-scope="audit"]');
  const overlay = scope?.querySelector('.spatial-overlay');
  const index = Number(button.dataset.identityIndex);
  if (!overlay || overlay.dataset.spatialBinding !== button.dataset.identityBinding || !Number.isInteger(index) || index < 1) return;
  const point = overlay.querySelectorAll('.spatial-point')[index - 1];
  const toggle = scope.querySelector('[data-action="spatial-toggle"]');
  if (!point || !toggle || toggle.dataset.spatialBinding !== button.dataset.identityBinding) return;
  if (overlay.hidden) spatialToggle(toggle);
  overlay.querySelectorAll('.spatial-point').forEach(item => { item.classList.remove('identity-selected'); item.removeAttribute('tabindex'); });
  point.classList.add('identity-selected'); point.setAttribute('tabindex', '-1');
  scope.querySelector('.audit-photo-stage')?.scrollIntoView({ block: 'center', behavior: 'smooth' });
  point.focus({ preventScroll: true });
});
function auditTime(value) { const d = new Date(value); return value && Number.isFinite(d.getTime()) ? new Intl.DateTimeFormat(state.lang === 'zh' ? 'zh-CN' : 'ko-KR', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(d) : '—'; }
function auditDecision(check, order = null) {
  if (digitalOnlyOrder(order) && ['ready', 'recapture', 'correct', 'manual'].includes(check?.decision)) {
    if (Object.prototype.hasOwnProperty.call(order, 'document_source') && check.decision === 'ready') return at('document_ready');
    return at(`public_${check.decision}`);
  }
  return ['ready', 'recapture', 'correct', 'manual'].includes(check?.decision) ? at(check.decision) : at('unknown');
}
Object.assign(AUDIT_STRINGS.ko, {
  step_verify_local_identity: '선택된 부품의 종류·구멍 형태 재확인',
  document_ready: '사진 자료 수량 일치', public_ready: '공개 사진 수량 일치', public_correct: '사진과 주문의 차이',
  public_recapture: '사진 증거 부족', public_manual: '추가 검토 필요',
  publicValidReason: '현재 주문 버전·최신 사진·검증 기록이 일치합니다. 새 디지털 검토의 저장 가능 여부는 현재 검토 화면에서 확인하세요. 실물 완료 근거가 아닙니다.',
  publicInvalidReason: '현재 주문의 디지털 검토에 적용할 수 없는 이전 기록입니다.',
  publicNext: '사진과 주문의 차이를 검토하고 필요한 자료를 기록하세요. 이 공개 사진 과제는 실물 완료를 기록하지 않습니다.',
  documentNext: '사진과 주문의 차이를 검토하고 필요한 자료를 기록하세요. 이 사진 자료 과제는 실물 완료를 기록하지 않습니다.',
  publicActionTitle: '디지털 자료 후속 검토', publicStoredAction: '원래 저장된 일반 작업 제안',
});
Object.assign(AUDIT_STRINGS.zh, {
  step_verify_local_identity: '复核选中零件的类别与孔形',
  document_ready: '照片资料数量相符', public_ready: '公开照片数量相符', public_correct: '照片与订单有差异',
  public_recapture: '照片证据不足', public_manual: '需要进一步审查',
  publicValidReason: '当前订单版本、最新照片与核验记录一致。能否保存新的数字审查，请以当前审查区状态为准；这不是实物完工依据。',
  publicInvalidReason: '这是历史记录，不能用于当前订单的数字审查。',
  publicNext: '核对照片与订单的差异，并记录所需资料。此公开照片任务不记录实物完工。',
  documentNext: '核对照片与订单的差异，并记录所需资料。此照片资料任务不记录实物完工。',
  publicActionTitle: '数字资料后续审查', publicStoredAction: '原始保存的通用动作建议',
});
function auditActionMarkup(order, check) {
  const original = `<p>${esc(check.action?.message || (check.action?.kind === 'none' ? at('noAction') : at('noActionRecord')))}</p>`;
  const action = digitalOnlyOrder(order)
    ? `<h3>${esc(at('publicActionTitle'))}</h3><p>${esc(at(Object.prototype.hasOwnProperty.call(order, 'document_source') ? 'documentNext' : 'publicNext'))}</p><details><summary>${esc(at('publicStoredAction'))}</summary>${original}</details>`
    : `<h3>${esc(at('actionThen'))}</h3>${original}`;
  const issues = check.issues?.length ? `<ul>${check.issues.map(issue => `<li>${esc(issue)}</li>`).join('')}</ul>` : `<small>${esc(at('noIssues'))}</small>`;
  return `<div class="audit-action">${action}${issues}</div>`;
}
function auditChecks(order) { const items = [...(order.checks || [])]; if (order.latest_check && !items.some(c => c.id === order.latest_check.id)) items.push(order.latest_check); return items.sort((a, b) => new Date(b.created_at) - new Date(a.created_at)); }
function auditEventContext(order, check) {
  const events = order.events || [];
  const end = events.findIndex(e => e.kind === 'inspection_completed' && e.payload?.check_id === check.id);
  const after = end >= 0 ? events.slice(end + 1) : events.filter(e => new Date(e.created_at).getTime() > new Date(check.created_at).getTime());
  let start = -1;
  if (end >= 0) { for (let i = end - 1; i >= 0; i--) { if (events[i].kind === 'inspection_started' && events[i].payload?.photo_id === check.photo_id) { start = i; break; } } }
  const inputEvents = events.filter((event, index) => {
    if (end >= 0 && index > end) return false;
    if (end < 0 && new Date(event.created_at).getTime() > new Date(check.created_at).getTime()) return false;
    return event.kind === 'order_created' && check.revision === 1
      || event.kind === 'revision_approved' && event.payload?.revision === check.revision
      || event.kind === 'photo_uploaded' && event.payload?.photo_id === check.photo_id
      || event.payload?.check_id === check.id
      || index === start;
  });
  const impacting = after.filter(e => ['revision_approved', 'photo_uploaded', 'reference_updated', 'inspection_started'].includes(e.kind));
  const later = after.filter(e => impacting.includes(e) || e.payload?.check_id === check.id);
  return { after, inputEvents, impacting, later };
}
function auditValidity(order, check) {
  const context = auditEventContext(order, check);
  const newestPhoto = (order.photos || []).at(-1);
  const reasons = [];
  if (check.revision !== order.revision) reasons.push({ key: 'versionChanged', text: at('versionChanged', { before: check.revision, after: order.revision }) });
  if (newestPhoto && newestPhoto.id !== check.photo_id) reasons.push({ key: 'photoChanged', text: at('photoChanged') });
  if (context.impacting.some(e => e.kind === 'reference_updated')) reasons.push({ key: 'referenceChanged', text: at('referenceChanged') });
  if (context.impacting.some(e => e.kind === 'inspection_started')) reasons.push({ key: 'inspectionRestarted', text: at('inspectionRestarted') });
  if (order.latest_check && order.latest_check.id !== check.id && !reasons.some(r => r.key === 'inspectionRestarted')) reasons.push({ key: 'superseded', text: at('superseded') });
  if (order.active_inspection && !reasons.some(r => r.key === 'inspectionRestarted')) reasons.push({ key: 'activeInspection', text: at('activeInspection') });
  const epochKnown = Number.isInteger(check.evidence_epoch) && Number.isInteger(order.evidence_epoch);
  if (epochKnown && check.evidence_epoch !== order.evidence_epoch && !reasons.some(r => ['versionChanged', 'photoChanged', 'referenceChanged'].includes(r.key))) reasons.push({ key: 'epochChanged', text: at('epochChanged') });
  const effective = check.valid === true && check.revision === order.revision && order.latest_check?.id === check.id && newestPhoto?.id === check.photo_id && epochKnown && check.evidence_epoch === order.evidence_epoch && !order.active_inspection && reasons.length === 0 && check.backend !== 'test';
  if (!effective && !reasons.length) reasons.push({ key: check.backend === 'test' ? 'testReason' : check.valid === false ? 'serverInvalidated' : 'stateUnknown', text: at(check.backend === 'test' ? 'testReason' : check.valid === false ? 'serverInvalidated' : 'stateUnknown') });
  return { effective, reasons, context };
}
function auditRequirements(order, check) {
  const revision = (order.revisions || []).find(r => r.revision === check.revision);
  const required = {};
  let usedFallback = false;
  for (const part of PARTS) {
    if (Number.isInteger(check.requirements_snapshot?.[part])) required[part] = check.requirements_snapshot[part];
    else if (Number.isInteger(revision?.requirements?.[part])) required[part] = revision.requirements[part];
    else { const diff = (check.differences || []).find(d => d.part === part); required[part] = Number.isInteger(diff?.required) ? diff.required : null; usedFallback = true; }
  }
  const inconsistent = PARTS.some(part => Number.isInteger(check.requirements_snapshot?.[part]) && Number.isInteger(revision?.requirements?.[part]) && check.requirements_snapshot[part] !== revision.requirements[part]) || (check.differences || []).some(d => {
    const observed = check.observed?.[d.part]; const requirement = required[d.part];
    return Number.isInteger(requirement) && Number.isInteger(d.required) && requirement !== d.required
      || d.observed !== undefined && observed !== undefined && d.observed !== observed
      || Number.isInteger(d.delta) && Number.isInteger(observed) && Number.isInteger(requirement) && d.delta !== observed - requirement;
  });
  return { revision, required, usedSnapshot: PARTS.every(part => Number.isInteger(check.requirements_snapshot?.[part])), usedFallback, inconsistent, missing: PARTS.some(p => required[p] === null) };
}
function auditRenderHistory(order) {
  const checks = auditChecks(order);
  const events = [...(order.events || [])].reverse();
  const view = state.historyView || (checks.length ? 'checks' : 'events');
  const rows = checks.map(check => {
    const photo = (order.photos || []).find(p => p.id === check.photo_id);
    const validity = auditValidity(order, check);
    const isTest = check.backend === 'test';
    return `<button class="audit-record" data-action="audit-check" data-check="${esc(check.id)}" aria-label="${esc(`${at('openDetail')} R${check.revision} ${auditTime(check.created_at)}`)}"><span class="audit-record-thumb">${photo ? `<img src="${esc(imageUrl(photo))}" alt="" loading="lazy">` : icon('scan')}</span><span class="audit-record-body"><span class="audit-record-title"><span class="badge revision">R${esc(check.revision)}</span><strong>${esc(auditDecision(check, order))}</strong></span><span class="audit-record-meta"><time datetime="${esc(check.created_at)}">${esc(formatDate(check.created_at))}</time><span>·</span><span>${esc(at('latencyValue', { seconds: Number.isFinite(check.latency_ms) ? (check.latency_ms / 1000).toFixed(1) : '—' }))}</span></span></span><span class="audit-record-end"><span class="badge ${isTest ? 'audit-test' : validity.effective ? 'ready' : 'audit-archived'}">${esc(at(isTest ? 'test' : validity.effective ? 'effective' : 'invalid'))}</span>${icon('chevron')}</span></button>`;
  }).join('');
  return `<section class="panel history-panel" id="audit-history-panel"><div class="panel-header"><div class="panel-title">${icon('clock')}<h2>${esc(t('history'))}</h2></div><a class="audit-link" href="/api/orders/${encodeURIComponent(order.id)}/export" download>JSON ${icon('download')}</a></div><div class="audit-tabs" role="group" aria-label="${esc(at('tabs'))}"><button data-action="audit-tab" data-view="checks" aria-pressed="${view === 'checks'}" class="${view === 'checks' ? 'active' : ''}">${esc(at('records'))}<span>${checks.length}</span></button><button data-action="audit-tab" data-view="events" aria-pressed="${view === 'events'}" class="${view === 'events' ? 'active' : ''}">${esc(at('events'))}<span>${events.length}</span></button></div>${view === 'checks' ? `<div class="audit-records">${rows || `<div class="audit-empty">${icon('file')}<h3>${esc(at('emptyTitle'))}</h3><p>${esc(at('emptyBody'))}</p></div>`}</div>` : `<div class="timeline">${events.length ? events.map(event => auditEventMarkup(event, true)).join('') : `<p class="muted-empty">${esc(t('emptyHistory'))}</p>`}</div>`}</section>`;
}
function auditEventMarkup(event, allowOpen = false) {
  const checkId = event.payload?.check_id;
  const reason = typeof event.payload?.reason === 'string' ? event.payload.reason : null;
  return `<div class="timeline-item audit-event"><span class="timeline-icon">${icon(/complet/.test(event.kind) ? 'check' : /revis/.test(event.kind) ? 'branch' : /photo|reference/.test(event.kind) ? 'image' : /inspect|check/.test(event.kind) ? 'scan' : 'plus')}</span><div class="audit-event-content"><p>${esc(event.message || event.kind)}</p>${reason ? `<details class="audit-event-reason"><summary>${esc(at('reason'))}</summary><p>${esc(reason)}</p></details>` : ''}${allowOpen && checkId && auditChecks(state.order).some(c => c.id === checkId) ? `<button class="audit-inline-link" data-action="audit-check" data-check="${esc(checkId)}">${esc(at('openDetail'))}${icon('chevron')}</button>` : ''}</div><time datetime="${esc(event.created_at)}" title="${esc(auditTime(event.created_at))}">${esc(formatDate(event.created_at, 'time'))}</time></div>`;
}
function auditMetadata(label, value, mono = false) { return `<div class="audit-meta-row"><dt>${esc(label)}</dt><dd class="${mono ? 'audit-mono' : ''}">${esc(value ?? '—')}</dd></div>`; }
function auditPhotoRegion(check) {
  if (!Array.isArray(check.action?.region) || check.action.region.length !== 4) return '';
  const [x1, y1, x2, y2] = check.action.region.map(Number);
  if ([x1, y1, x2, y2].some(n => !Number.isFinite(n) || n < 0 || n > 1) || x2 <= x1 || y2 <= y1) return '';
  return `<div class="photo-region" style="left:${x1 * 100}%;top:${y1 * 100}%;width:${(x2 - x1) * 100}%;height:${(y2 - y1) * 100}%"><span>${esc(at(check.observation_verification?.mode === 'spatial_consensus' ? 'spatialRegion' : 'region'))}</span></div>`;
}
function auditFindPhoto(order, id) {
  if (!id) return null;
  return [...(order.photos || []), ...(order.reference_history || []).map(item => item.photo), ...Object.values(order.references || {})].find(photo => photo?.id === id) || null;
}
function auditActionName(kind) { return ['none', 'separate', 'recapture', 'add_remove', 'manual'].includes(kind) ? at(`action_${kind}`) : kind || '—'; }
function auditObserved(value) { return Number.isInteger(value) ? String(value) : at('unavailable'); }
function auditPartList(parts) { return Array.isArray(parts) ? parts.length ? parts.map(part => `<span class="audit-part-chip">${esc(partLabel(part))}</span>`).join('') : `<span class="audit-muted">${esc(at('noneRecorded'))}</span>` : `<span class="audit-muted">—</span>`; }
function auditFeedbackPhoto(order, photoId, label) {
  const photo = auditFindPhoto(order, photoId);
  return `<div class="audit-feedback-photo"><span class="audit-field-label">${esc(label)}</span>${photo ? `<a href="${esc(imageUrl(photo))}" target="_blank" rel="noopener" aria-label="${esc(`${label} · ${at('openPhoto')}`)}"><img src="${esc(imageUrl(photo))}" alt="${esc(label)}" loading="lazy"></a>` : `<div class="audit-feedback-photo-missing">${icon('image')}<span>${esc(at('noPhoto'))}</span></div>`}<code>${esc(photoId || '—')}</code></div>`;
}
function auditFeedbackMarkup(order, check) {
  const feedback = check.evidence_feedback;
  const heading = `<div class="audit-section-heading"><h3>${esc(at('feedbackTitle'))}</h3><span class="badge revision">R${esc(check.revision)}</span></div>`;
  if (!feedback || typeof feedback !== 'object') return `<section class="audit-feedback">${heading}<p class="audit-muted">${esc(at(Object.hasOwn(check, 'evidence_feedback') ? 'feedbackEmpty' : 'feedbackUnrecorded'))}</p></section>`;
  const previous = auditChecks(order).find(item => item.id === feedback.previous_check_id);
  const outcomes = ['current_requirements_match', 'evidence_improved_quantity_mismatch', 'evidence_still_unclear', 'quantity_mismatch_remains'];
  const changes = Array.isArray(feedback.observed_changes) ? feedback.observed_changes.filter(change => change && typeof change.part === 'string') : [];
  // Feedback compares saved image observations only. Never turn it into a claim about physical action.
  return `<section class="audit-feedback">${heading}<p class="audit-feedback-snapshot audit-muted">${esc(at('feedbackSnapshot', { revision: check.revision }))}</p><div class="audit-feedback-summary"><strong>${esc(outcomes.includes(feedback.outcome) ? at(feedback.outcome) : feedback.outcome || at('unknown'))}</strong>${typeof feedback.message === 'string' ? `<p>${esc(feedback.message)}</p>` : ''}</div><div class="audit-physical-limit">${icon('info')}<p>${esc(at('physicalLimit'))}</p></div><div class="audit-feedback-body"><div class="audit-feedback-photos">${auditFeedbackPhoto(order, feedback.previous_photo_id, at('previousEvidence'))}${auditFeedbackPhoto(order, check.photo_id, at('newEvidence'))}</div><div class="audit-feedback-facts"><dl class="audit-feedback-parts">${[['resolved_uncertainties', 'resolvedUncertainties'], ['remaining_uncertainties', 'remainingUncertainties'], ['remaining_mismatches', 'remainingMismatches']].map(([key, label]) => `<div data-feedback-list="${key}"><dt>${esc(at(label))}</dt><dd>${auditPartList(feedback[key])}</dd></div>`).join('')}</dl><div class="audit-observation-changes"><h4>${esc(at('observedChanges'))}</h4>${changes.length ? `<table class="audit-table"><thead><tr><th scope="col">${esc(t('part'))}</th><th scope="col">${esc(at('beforeObservation'))}</th><th scope="col">${esc(at('afterObservation'))}</th></tr></thead><tbody>${changes.map(change => `<tr data-feedback-part="${esc(change.part)}"><th scope="row">${esc(partLabel(change.part))}</th><td>${esc(auditObserved(change.before))}</td><td>${esc(auditObserved(change.after))}</td></tr>`).join('')}</tbody></table>` : `<p class="audit-muted">${esc(at('noObservedChanges'))}</p>`}</div></div></div><div class="audit-feedback-link"><span>${esc(at('previousAction'))}: ${esc(auditActionName(feedback.previous_action_kind))}</span>${previous ? `<button class="audit-inline-link" data-action="audit-check" data-check="${esc(previous.id)}" data-order="${esc(order.id)}">${esc(at('previousCheck'))}${icon('chevron')}</button>` : `<code>${esc(feedback.previous_check_id || '—')}</code>`}</div></section>`;
}
function auditVerificationMarkup(check) {
  const verification = check.observation_verification;
  if (!verification || typeof verification !== 'object' || Array.isArray(verification)) return '';
  const passes = Array.isArray(verification.passes) ? verification.passes.filter(pass => pass && typeof pass === 'object' && !Array.isArray(pass)) : [];
  const spatialConsensus = verification.mode === 'spatial_consensus';
  const boolText = value => at(value === true ? 'verificationYes' : value === false ? 'verificationNo' : 'verificationMissing');
  const passLabel = (pass, index) => pass.transform === 'original' ? at('verificationOriginal') : pass.transform === 'rotate_90_ccw' ? at('verificationRotated') : `${at('verificationPass', { number: index + 1 })} · ${pass.transform || at('verificationMissing')}`;
  return `<section class="audit-verification"><div class="audit-section-heading"><h3>${esc(at(spatialConsensus ? 'spatialVerificationTitle' : 'verificationTitle'))}</h3><span class="badge revision">R${esc(check.revision)}</span></div><p class="audit-verification-note">${esc(at(spatialConsensus ? 'spatialVerificationNote' : 'verificationNote'))}</p><dl class="audit-verification-facts">${auditMetadata(at('verificationMode'), spatialConsensus ? at('spatialVerificationTitle') : verification.mode)}${auditMetadata(at('verificationCounts'), boolText(verification.counts_agree))}${auditMetadata(at('verificationClear'), boolText(verification.clear_agreement))}</dl>${passes.length ? `<div class="audit-verification-table-wrap"><table class="audit-table"><thead><tr><th scope="col">${esc(t('part'))}</th>${passes.map((pass, index) => `<th scope="col">${esc(passLabel(pass, index))}</th>`).join('')}</tr></thead><tbody>${PARTS.map(part => `<tr data-verification-part="${part}"><th scope="row">${esc(partLabel(part))}</th>${passes.map((pass, index) => `<td data-verification-pass="${index}">${esc(auditObserved(pass.observed?.[part]))}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="audit-verification-passes">${passes.map((pass, index) => `<div class="audit-verification-pass" data-verification-transform="${esc(pass.transform || '')}"><h4>${esc(passLabel(pass, index))}</h4><dl>${auditMetadata(at('verificationInputHash'), pass.input_sha256, true)}${auditMetadata(at('verificationAction'), auditActionName(pass.action?.kind))}</dl>${typeof pass.action?.message === 'string' ? `<p>${esc(pass.action.message)}</p>` : ''}<span class="audit-field-label">${esc(at('verificationIssues'))}</span>${Array.isArray(pass.issues) ? pass.issues.length ? `<ul>${pass.issues.map(issue => `<li>${esc(issue)}</li>`).join('')}</ul>` : `<p class="audit-muted">${esc(at('noneRecorded'))}</p>` : `<p class="audit-muted">${esc(at('verificationMissing'))}</p>`}</div>`).join('')}</div>` : `<p class="audit-muted">${esc(at('verificationPassesMissing'))}</p>`}<p class="audit-muted audit-verification-image-note">${esc(at('verificationImageNote'))}</p>${spatialConsensus ? `<p class="audit-muted audit-verification-image-note">${esc(at('spatialFrameNote'))}</p>` : ''}</section>`;
}
function auditReferencesMarkup(order, check) {
  const refs = check.reference_ids;
  return `<details class="audit-references"><summary>${esc(at('referencesThen'))}</summary>${refs && typeof refs === 'object' && !Array.isArray(refs) ? `<div class="audit-reference-grid">${PARTS.map(part => { const id = typeof refs[part] === 'string' ? refs[part] : null; const photo = auditFindPhoto(order, id); return `<div class="audit-reference-card" data-audit-reference="${part}"><strong>${esc(partLabel(part))}</strong>${photo ? `<a href="${esc(imageUrl(photo))}" target="_blank" rel="noopener" aria-label="${esc(`${at('referencesThen')} · ${partLabel(part)} · ${at('openPhoto')}`)}"><img src="${esc(imageUrl(photo))}" alt="${esc(partLabel(part))}" loading="lazy"></a>` : `<div class="audit-reference-missing">${icon(part)}<span>${esc(at(id ? 'referenceMissing' : 'referenceAbsent'))}</span></div>`}${id ? `<code>${esc(id)}</code>` : ''}</div>`; }).join('')}</div>` : `<p class="audit-muted">${esc(at('referencesUnrecorded'))}</p>`}</details>`;
}
function auditReferenceEvidenceMarkup(check) {
  const zh = state.lang === 'zh';
  const words = zh ? {
    title: '参考图参与记录', missing: '未记录各推理阶段的参考输入；不会由当前参考图补填。',
    note: '记录实际提交给各阶段的类别示例，不计入待检数量，也不证明模型实际利用了示例。',
    stage: '阶段', status: '保存状态', inputs: '类别参考输入', none: '无类别参考输入', unknown: '未记录',
    original: '原始方向', rotate_90_ccw: '旋转方向', identity: '局部身份复核',
    completed: '已完成', attempted: '已尝试', failed: '失败', skipped_base_unclear: '未执行：前序不明确', skipped_no_candidates: '未执行：没有候选',
    technical: '展开输入标识与预处理', source: '原始上传 SHA-256', stored: '存储图 SHA-256', prepared: '实际参考输入 PNG SHA-256',
    size: '实际输入尺寸', protocol: '观察协议 SHA-256', bytes: '仅保存预处理文件的标识，未单独保留其 PNG 字节。'
  } : {
    title: '기준 사진 입력 기록', missing: '단계별 기준 입력은 미기록입니다. 현재 기준 사진으로 채우지 않습니다.',
    note: '각 단계에 실제 제출한 종류별 예시입니다. 검사 수량에 포함하지 않으며 모델의 실제 활용을 증명하지 않습니다.',
    stage: '단계', status: '저장 상태', inputs: '종류별 기준 입력', none: '종류별 기준 입력 없음', unknown: '미기록',
    original: '원래 방향', rotate_90_ccw: '회전 방향', identity: '국소 종류 재확인',
    completed: '완료', attempted: '시도', failed: '실패', skipped_base_unclear: '미실행: 앞선 관찰 불명확', skipped_no_candidates: '미실행: 후보 없음',
    technical: '입력 식별값·전처리 펼치기', source: '원래 업로드 SHA-256', stored: '저장 사진 SHA-256', prepared: '실제 기준 입력 PNG SHA-256',
    size: '실제 입력 크기', protocol: '관찰 프로토콜 SHA-256', bytes: '전처리 파일의 식별 기록만 보존하며 PNG 바이트를 별도 보관하지 않습니다.'
  };
  const evidence = check.reference_evidence;
  if (!evidence || typeof evidence !== 'object' || Array.isArray(evidence)) return `<details class="audit-references" data-reference-evidence="unrecorded"><summary>${esc(words.title)}</summary><p class="audit-muted">${esc(words.missing)}</p></details>`;
  const records = value => Array.isArray(value) ? value.filter(item => item && typeof item === 'object' && !Array.isArray(item)) : [];
  const images = records(evidence.images), stages = records(evidence.stages);
  const inputs = stage => {
    if (!Array.isArray(stage.reference_image_indices)) return words.unknown;
    if (!stage.reference_image_indices.length) return words.none;
    return stage.reference_image_indices.map(index => { const image = images.find(item => item.image_index === index); return `#${index} · ${image && PARTS.includes(image.part) ? partLabel(image.part) : words.unknown}`; }).join(', ');
  };
  return `<details class="audit-references" data-reference-evidence="recorded"><summary>${esc(words.title)}</summary><p class="audit-muted">${esc(words.note)}</p>${stages.length ? `<table class="audit-table"><thead><tr><th>${esc(words.stage)}</th><th>${esc(words.status)}</th><th>${esc(words.inputs)}</th></tr></thead><tbody>${stages.map(stage => `<tr data-reference-stage="${esc(stage.stage)}"><th scope="row">${esc(words[stage.stage] || stage.stage || words.unknown)}</th><td>${esc(words[stage.status] || stage.status || words.unknown)}</td><td>${esc(inputs(stage))}</td></tr>`).join('')}</tbody></table>` : `<p>${esc(words.unknown)}</p>`}<details class="audit-photo-metadata"><summary>${esc(words.technical)}</summary><dl>${auditMetadata(words.protocol, evidence.observer_protocol_sha256, true)}${auditMetadata('Pillow', evidence.pillow_version)}${auditMetadata(zh ? '预处理' : '전처리', evidence.preprocessing)}</dl>${images.map(image => `<div data-reference-input="${esc(image.image_index)}"><h4>#${esc(image.image_index)} · ${esc(PARTS.includes(image.part) ? partLabel(image.part) : image.part)}</h4><dl>${auditMetadata(at('photoId'), image.photo_id, true)}${auditMetadata(words.size, Array.isArray(image.prepared_size) ? image.prepared_size.join(' × ') : null)}${auditMetadata(words.source, image.upload_source_sha256, true)}${auditMetadata(words.stored, image.stored_sha256, true)}${auditMetadata(words.prepared, image.prepared_sha256, true)}</dl></div>`).join('')}${evidence.prepared_bytes_retained === false ? `<p class="audit-muted">${esc(words.bytes)}</p>` : ''}</details></details>`;
}
function auditTraceMarkup(check, order = null) {
  const trace = Array.isArray(check.tool_trace) ? check.tool_trace.filter(step => step && typeof step === 'object') : [];
  const knownSteps = ['observe_image', 'compare_orientation_observations', 'derive_counts_from_object_list', 'verify_local_identity', 'compare_current_requirements', 'review_previous_evidence', 'choose_next_action', 'commit_current_evidence'];
  const context = check.observation_context;
  return `<section class="audit-trace"><div class="audit-section-heading"><h3>${esc(at('traceTitle'))}</h3></div><p class="audit-muted">${esc(at('traceNote'))}</p>${trace.length ? `<ol class="audit-trace-list">${trace.map((step, index) => { const status = ['completed', 'not_applicable'].includes(step.status) ? at(`step_${step.status}`) : step.status || at('stepUnknown'); const details = [typeof step.model === 'string' ? step.model : null, Number.isFinite(step.latency_ms) ? at('latencyValue', { seconds: (step.latency_ms / 1000).toFixed(3) }) : null, Number.isInteger(step.revision) ? `R${step.revision}` : null, Number.isInteger(step.evidence_epoch) ? `${at('epoch')} ${step.evidence_epoch}` : null, typeof step.decision === 'string' ? auditDecision(step, order) : null, typeof step.action_kind === 'string' ? `${digitalOnlyOrder(order) ? `${at('publicStoredAction')}: ` : ''}${auditActionName(step.action_kind)}` : null].filter(Boolean); return `<li data-trace-step="${esc(step.step || '')}"><span class="audit-trace-number">${index + 1}</span><div><div class="audit-trace-heading"><strong>${esc(knownSteps.includes(step.step) ? at(`step_${step.step}`) : step.step || '—')}</strong><span class="audit-trace-status ${step.status === 'not_applicable' ? 'is-skipped' : ''}">${esc(status)}</span></div>${details.length ? `<p>${esc(details.join(' · '))}</p>` : ''}<details class="audit-raw-step"><summary>${esc(at('rawStep'))}</summary><pre>${esc(JSON.stringify(step, null, 2))}</pre></details></div></li>`; }).join('')}</ol>` : `<p class="audit-trace-empty audit-muted">${esc(at('traceEmpty'))}</p>`}${context && typeof context === 'object' ? `<details class="audit-context"><summary>${esc(at('contextTitle'))}</summary><p>${esc(at('contextNote'))}</p><dl>${auditMetadata(at('previousAction'), auditActionName(context.previous_action_kind))}<div class="audit-meta-row"><dt>${esc(at('contextUncertain'))}</dt><dd>${auditPartList(context.uncertain_parts)}</dd></div></dl></details>` : ''}</section>`;
}
function auditDetailMarkup(order, check, fetchedAt) {
  const validity = auditValidity(order, check);
  const requirements = auditRequirements(order, check);
  const photo = (order.photos || []).find(p => p.id === check.photo_id);
  const receipts = (order.completions || []).filter(c => c.check_id === check.id);
  const test = check.backend === 'test';
  const eventList = items => items.length ? `<div class="audit-detail-events">${items.map(e => auditEventMarkup(e)).join('')}</div>` : `<p class="audit-muted">${esc(at('noLinkedEvents'))}</p>`;
  const table = `<table class="audit-table"><thead><tr><th scope="col">${esc(t('part'))}</th><th scope="col">${esc(at('requirementsThen'))}</th><th scope="col">${esc(at('observedThen'))}</th><th scope="col">${esc(at('differenceThen'))}</th></tr></thead><tbody>${PARTS.map(part => { const required = requirements.required[part]; const observed = check.observed?.[part]; const known = Number.isInteger(required) && Number.isInteger(observed); const delta = known ? observed - required : null; return `<tr data-audit-part="${part}"><th scope="row"><span class="part-name"><span class="part-icon">${icon(part)}</span>${esc(partLabel(part))}</span></th><td data-audit-value="required">${required ?? '—'}</td><td data-audit-value="observed">${Number.isInteger(observed) ? observed : `<span class="audit-unknown">${esc(at('unavailable'))}</span>`}</td><td>${known ? delta === 0 ? `<span class="match-mark" aria-label="${esc(at('noDifference'))}">${icon('check')}</span>` : `<span class="delta">${delta > 0 ? '+' : ''}${delta}</span>` : '—'}</td></tr>`; }).join('')}</tbody></table>`;
  return `<div class="modal-header audit-detail-header"><div><p class="eyebrow">INSPECTION RECORD · R${esc(check.revision)}</p><h2 id="audit-dialog-title">${esc(at('detail'))}</h2><p>${esc(order.title)} · ${esc(auditTime(check.created_at))}</p></div><button class="icon-btn" type="button" data-action="close-modal" aria-label="${esc(at('close'))}">${icon('close')}</button></div><div class="audit-detail-content"><div class="audit-readonly">${icon('lock')}<p>${esc(at('readonly'))}</p></div>${test ? `<div class="audit-test-notice">${icon('alert')}<p>${esc(at('testReason'))}</p></div>` : ''}<div class="audit-summary"><div><span class="audit-field-label">${esc(at('storedDecision'))}</span><strong>${esc(auditDecision(check, order))}</strong></div><div><span class="audit-field-label">${esc(at('validity'))}</span><span class="badge ${test ? 'audit-test' : validity.effective ? 'ready' : 'audit-archived'}">${esc(at(test ? 'test' : validity.effective ? 'effective' : 'invalid'))}</span></div><div><span class="audit-field-label">${esc(at('currentAtRead'))}</span><strong>R${esc(order.revision)}</strong></div></div><section class="audit-validity ${validity.effective ? 'is-effective' : ''}"><p>${esc(at(digitalOnlyOrder(order) ? (validity.effective ? 'publicValidReason' : 'publicInvalidReason') : (validity.effective ? 'validReason' : 'invalidReason')))}</p>${validity.reasons.length ? `<ul>${validity.reasons.map(reason => `<li data-reason="${esc(reason.key)}">${esc(reason.text)}</li>`).join('')}</ul>` : ''}<small>${esc(at('explanationNote'))}</small></section><div class="audit-detail-grid"><section class="audit-evidence" data-spatial-scope="audit"><div class="audit-section-heading"><h3>${esc(at('photoThen'))}</h3><span class="badge revision">R${esc(check.revision)}</span></div><div class="audit-photo-stage">${photo ? `<div class="audit-photo-frame"><img src="${esc(imageUrl(photo))}" alt="${esc(`${at('photoThen')} R${check.revision}`)}">${auditPhotoRegion(check)}${spatialOverlayMarkup(check, photo, 'audit')}</div>` : `<div class="audit-empty-photo">${icon('image')}<p>${esc(at('noPhoto'))}</p></div>`}</div>${spatialControlsMarkup(check, photo, 'audit')}${photo ? `<a class="audit-inline-link audit-photo-open" href="${esc(imageUrl(photo))}" target="_blank" rel="noopener">${icon('image')}${esc(at('openPhoto'))}<span>↗</span></a>` : ''}<details class="audit-photo-metadata"><summary>${esc(at('metadata'))}</summary><dl>${auditMetadata(at('photoId'), check.photo_id, true)}${auditMetadata(at('photoRecorded'), photo ? auditTime(photo.created_at) : null)}${auditMetadata(at('photoHash'), check.photo_sha256 || photo?.sha256, true)}</dl><p>${esc(at('hashNote'))}</p>${check.photo_sha256 && photo?.sha256 && check.photo_sha256 !== photo.sha256 ? `<p class="audit-data-warning">${esc(at('hashMismatch'))}</p>` : ''}</details></section><section class="audit-comparison"><div class="audit-section-heading"><h3>${esc(at('requirementsThen'))}</h3><small>${esc(requirements.usedFallback ? `R${check.revision}` : at(requirements.usedSnapshot ? 'checkSnapshotBasis' : 'versionBasis', { revision: check.revision }))}</small></div>${table}${requirements.usedFallback ? `<p class="audit-data-note">${esc(at(requirements.missing ? 'missingRequirements' : 'differenceBasis'))}</p>` : ''}${requirements.inconsistent ? `<p class="audit-data-warning">${esc(at('inconsistent'))}</p>` : ''}${requirements.revision?.instruction ? `<div class="audit-order-instruction"><span class="audit-field-label">${esc(at('versionInstruction'))}</span><p>${esc(requirements.revision.instruction)}</p></div>` : ''}${auditActionMarkup(order, check)}</section></div>${typeof renderDocumentSource === 'function' ? renderDocumentSource(order, true) : ''}${auditReferencesMarkup(order, check)}${auditReferenceEvidenceMarkup(check)}${auditVerificationMarkup(check)}${auditIdentityMarkup(order, check)}${auditFeedbackMarkup(order, check)}${auditTraceMarkup(check, order)}<section class="audit-run"><div class="audit-section-heading"><h3>${esc(at('runDetails'))}</h3><span class="audit-technical-tag">${esc(check.backend || '—')}</span></div><dl class="audit-metadata-grid">${auditMetadata(at('checkId'), check.id, true)}${auditMetadata(at('capturedAt'), auditTime(check.created_at))}${auditMetadata(at('model'), check.model_label)}${auditMetadata(at('latency'), Number.isFinite(check.latency_ms) ? at('latencyValue', { seconds: (check.latency_ms / 1000).toFixed(3) }) : null)}${auditMetadata(at('epoch'), check.evidence_epoch)}${auditMetadata(at('evidenceNow'), order.evidence_epoch)}${auditMetadata(at('validFlag'), typeof check.valid === 'boolean' ? at(String(check.valid)) : null)}${auditMetadata(at('snapshotAt'), auditTime(fetchedAt))}</dl></section><section class="audit-completions"><h3>${esc(at('completion'))}</h3>${receipts.length ? receipts.map(receipt => `<div class="audit-receipt">${icon('shield')}<div><strong>${esc(at('completionSaved'))}</strong><p>R${esc(receipt.revision)} · ${esc(auditTime(receipt.created_at))}</p><code>${esc(receipt.id)}</code>${!validity.effective ? `<p class="audit-muted">${esc(at('completionRetained'))}</p>` : ''}</div></div>`).join('') : `<p class="audit-muted">${esc(at('noCompletion'))}</p>`}</section><div class="audit-events-grid"><section><h3>${esc(at('inputsAndRun'))}</h3>${eventList(validity.context.inputEvents)}</section><section><h3>${esc(at('laterEvents'))}</h3>${eventList(validity.context.later)}</section></div><p class="audit-link-note">${esc(at('linkedEventsNote'))}</p></div><div class="modal-footer audit-footer"><a class="btn btn-secondary" href="/api/orders/${encodeURIComponent(order.id)}/export" download>${icon('download')}${esc(at('export'))}</a><div><button class="btn btn-quiet" data-action="audit-refresh" data-check="${esc(check.id)}" data-order="${esc(order.id)}">${icon('refresh')}${esc(at('reload'))}</button><button class="btn btn-primary" type="button" data-action="close-modal">${esc(at('close'))}</button></div></div>`;
}
async function auditOpenCheck(checkId, orderId = state.order?.id) {
  if (!orderId || !checkId) return;
  const dialog = document.getElementById('audit-dialog');
  const requestId = Symbol('audit-read');
  state.auditRequestId = requestId;
  openModal('audit-dialog', `<div class="modal-header"><h2 id="audit-dialog-title">${esc(at('detail'))}</h2><button class="icon-btn" data-action="close-modal" aria-label="${esc(at('close'))}">${icon('close')}</button></div><div class="modal-content audit-loading" role="status"><span class="spinner"></span>${esc(at('loading'))}</div>`);
  try {
    const data = await api(`/api/orders/${encodeURIComponent(orderId)}`);
    if (state.auditRequestId !== requestId || !dialog.open) return;
    const order = data.order; const check = auditChecks(order).find(item => item.id === checkId);
    if (!check) throw new Error(at('missingCheck'));
    // Keep this read-only snapshot separate; a late audit GET must not overwrite a newer workspace mutation.
    state.auditSnapshot = { order, checkId, fetchedAt: new Date().toISOString() };
    dialog.innerHTML = auditDetailMarkup(order, check, state.auditSnapshot.fetchedAt);
    dialog.scrollTop = 0;
    dialog.querySelector('[data-action="close-modal"]')?.focus();
  } catch (error) {
    if (state.auditRequestId !== requestId || !dialog.open) return;
    dialog.innerHTML = `<div class="modal-header"><h2 id="audit-dialog-title">${esc(at('detail'))}</h2><button class="icon-btn" data-action="close-modal" aria-label="${esc(at('close'))}">${icon('close')}</button></div><div class="modal-content"><p class="modal-message">${esc(at('error'))}</p><div class="modal-error visible" role="alert">${esc(error.message)}</div></div><div class="modal-footer"><button class="btn btn-secondary" data-action="audit-refresh" data-check="${esc(checkId)}" data-order="${esc(orderId)}">${icon('refresh')}${esc(at('reload'))}</button><button class="btn btn-primary" data-action="close-modal">${esc(at('close'))}</button></div>`;
  }
}
