"""CPU-only runtime audit: production dispatch/store, synthetic analyzer output.

All databases and photos live in a TemporaryDirectory. No MLX imports or model calls.
Run with the project Python from the project root.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import sys
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(os.environ.get("KITGUARD_AUDIT_SOURCE_ROOT", Path(__file__).resolve().parents[3]))
sys.path.insert(0, str(ROOT))
temporary = tempfile.TemporaryDirectory(prefix="kitguard-v04-runtime-audit-")
BASE = Path(temporary.name)
os.environ["KITGUARD_DATA_DIR"] = str(BASE / "import-only")

from fastapi.testclient import TestClient
from PIL import Image
from kitguard.app import create_app
from kitguard.spatial import SpatialInventory
from kitguard.vision import LocalVision

REQ = {"bolt": 1, "nut": 0, "washer": 0, "bracket": 0}


def pixels(color):
    out = io.BytesIO()
    Image.new("RGB", (160, 96), color).save(out, format="PNG")
    return out.getvalue()


def observation():
    return {"observed": REQ, "issues": [], "action": {
        "kind": "none", "message": "CPU synthetic fixture", "region": None},
        "model_label": "CPU fixture", "backend": "test", "latency_ms": 1}


def setup(client):
    order = client.post("/api/orders", json={"title": "CPU runtime audit", "requirements": REQ}).json()["order"]
    photo = client.post(f"/api/orders/{order['id']}/photos", data={"expected_revision": 1},
        files={"photo": ("synthetic.png", pixels((150, 110, 90)), "image/png")}).json()["photo"]
    return order, photo


def inspect(client, order, photo):
    return client.post(f"/api/orders/{order['id']}/inspect", json={
        "photo_id": photo["id"], "expected_revision": 1})


class CPUBlockingVision(LocalVision):
    def __init__(self):
        super().__init__(observation_mode="spatial_inventory")
        self.started = threading.Event()
        self.release = threading.Event()
        self.executed = []

    def status(self):
        return {"available": True, "loaded": False, "observation_mode": "spatial_inventory"}

    def _observe(self, image_path, references, context=None):
        self.executed.append({"thread": threading.current_thread().name, "time": time.monotonic()})
        self.started.set()
        if not self.release.wait(5):
            raise RuntimeError("Audit release timeout")
        return observation()


def expired_queue():
    engine = CPUBlockingVision()
    app = create_app(data_dir=BASE / "expired-queue", analyzer=engine, inference_timeout=.05)
    with TestClient(app) as client:
        order, photo = setup(client)
        statuses = [inspect(client, order, photo).status_code for _ in range(3)]
        before = len(engine.executed)
        engine.release.set()
        deadline = time.monotonic() + 2
        while len(engine.executed) < 3 and time.monotonic() < deadline:
            time.sleep(.01)
        saved = app.state.store.get(order["id"])
        result = {"http_statuses": statuses, "calls_started_before_release": before,
            "calls_started_after_all_requests_expired": len(engine.executed),
            "executed": engine.executed, "committed_checks": len(saved["checks"]),
            "active_inspection": saved["active_inspection"]}
        assert statuses == [504] * 3 and before == 1 and len(engine.executed) == 3
        assert saved["checks"] == [] and saved["active_inspection"] is None
        return result


def second_instance():
    engine = CPUBlockingVision()
    data = BASE / "shared-live-instance"
    app = create_app(data_dir=data, analyzer=engine)
    with TestClient(app) as first:
        order, photo = setup(first)
        with ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(inspect, first, order, photo)
            assert engine.started.wait(2)
            before = app.state.store.get(order["id"])["active_inspection"]
            second_app = create_app(data_dir=data, analyzer=engine)
            with TestClient(second_app):
                during = app.state.store.get(order["id"])
                engine.release.set()
                response = future.result(2)
            assert before and during["active_inspection"] is None and response.status_code == 409
            return {"first_instance_active_before_second_start": bool(before),
                "active_after_second_start": during["active_inspection"],
                "status_after_second_start": during["status"],
                "recovery_event": during["events"][-1],
                "first_live_request_response": response.status_code,
                "first_live_request_body": response.json()}


def changed_photo():
    engine = LocalVision(observation_mode="spatial_guarded", image_max_side=1536)
    calls = []
    def generate(system, prompt, images, schema, *, max_tokens):
        calls.append([hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in images])
        engine._last_inference = {"seconds": .001, "synthetic_cpu_fixture": True}
        return SpatialInventory.model_validate({"objects": [{"part": "bolt", "center": [.5, .5]}],
            "uncertain_parts": [], "issues": [],
            "action": {"kind": "none", "message": "CPU synthetic fixture"}})
    engine._generate = generate
    engine.status = lambda: {"available": True, "loaded": False, "observation_mode": "spatial_guarded"}
    app = create_app(data_dir=BASE / "changed-photo", analyzer=engine)
    with TestClient(app, raise_server_exceptions=False) as client:
        order, photo = setup(client)
        image_path = app.state.store.photo_path(photo["id"])
        # Simulated accidentally replaced normalized file, not a production edit.
        Image.new("RGB", (160, 96), (0, 80, 200)).save(image_path, format="JPEG", quality=95)
        actual = hashlib.sha256(image_path.read_bytes()).hexdigest()
        assert actual != photo["sha256"]
        response = inspect(client, order, photo)
        assert response.status_code == 200, response.text
        check = response.json()["check"]
        complete = client.post(f"/api/orders/{order['id']}/complete", json={
            "expected_revision": 1, "check_id": check["id"], "confirmed": True,
            "idempotency_key": "audit-changed-file"})
        archive = client.get(f"/api/orders/{order['id']}/evidence.zip")
        assert check["decision"] == "ready" and check["photo_sha256"] == photo["sha256"]
        assert complete.status_code == 200 and archive.status_code == 409
        return {"stored_metadata_sha256": photo["sha256"], "actual_file_sha256": actual,
            "inspect_status": response.status_code, "decision": check["decision"],
            "check_photo_sha256": check["photo_sha256"], "completion_status": complete.status_code,
            "archive_status": archive.status_code, "archive_detail": archive.json(),
            "real_adapter_cpu_generation_calls": len(calls),
            "identity_review_present": "identity_verification" in check}


result = {"scope": "CPU-only engineering reproduction; no accuracy claim; isolated temp data",
    "expired_queue": expired_queue(), "second_live_instance": second_instance(),
    "changed_photo": changed_photo(), "mlx_imported": "mlx" in sys.modules}
assert result["mlx_imported"] is False
target = Path(os.environ.get("KITGUARD_AUDIT_OUTPUT", Path(__file__).with_name("result.json")))
target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(result, ensure_ascii=False, indent=2))
temporary.cleanup()
