"""Bounded acquisition of the author-pinned InO-10-190 data subtree, no model calls."""
from __future__ import annotations

import hashlib
import json
import tarfile
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[3]
AUDIT = Path(__file__).resolve().parent
DEST = ROOT / "datasets/raw/ino-10-190"
COMMIT = "c733a3543157135c591cbe3f9de27e209964af63"
PROJECT = "https://git.sztaki.hu/emi/sim2real-object-detection"
API = "https://git.sztaki.hu/api/v4/projects/505"
SUBTREE = "test/test_datasets/test_01"
CAP = 1_000_000_000


def sha(data):
    return hashlib.sha256(data).hexdigest()


def get_small(url):
    with urlopen(Request(url, headers={"User-Agent": "KitGuard local research/0.4"}), timeout=60) as response:
        raw = response.read(1_000_001)
    if len(raw) > 1_000_000:
        raise ValueError("Unexpected metadata size")
    return raw


metadata = json.loads((AUDIT / "ino_metadata_only_manifest.json").read_text())
expected = {item["name"].split("/" + SUBTREE + "/", 1)[1]: item for item in metadata["files"]}
assert metadata["actual_total_bytes"] == 288_401_627 < CAP
assert len(expected) == 1141
DEST.mkdir(parents=True, exist_ok=True)
if (DEST / "SOURCE_MANIFEST.json").exists():
    raise SystemExit("Already acquired; verify existing manifest instead of overwriting provenance")

url = API + "/repository/archive.tar.gz?" + urlencode({
    "sha": COMMIT, "path": SUBTREE, "include_lfs_blobs": "true",
})
archive = DEST / "author-test_01.tar.gz"
if not archive.exists():
    part = archive.with_suffix(".gz.part")
    total = 0
    digest = hashlib.sha256()
    with urlopen(Request(url, headers={"User-Agent": "KitGuard local research/0.4"}), timeout=120) as response:
        with part.open("wb") as output:
            while block := response.read(1024 * 1024):
                total += len(block)
                if total + metadata["actual_total_bytes"] >= CAP:
                    raise ValueError("Compressed and expanded data would exceed 1 GB")
                output.write(block)
                digest.update(block)
                if total // (16 * 1024 * 1024) != (total - len(block)) // (16 * 1024 * 1024):
                    print(json.dumps({"downloaded_bytes": total}), flush=True)
    part.rename(archive)
    print(json.dumps({"archive_downloaded_bytes": total, "sha256": digest.hexdigest()}), flush=True)

metadata_payloads = {}
with tarfile.open(AUDIT / "ino_metadata_only.tar.gz", "r:gz") as metadata_tar:
    for member in metadata_tar.getmembers():
        if member.isfile():
            name = member.name.split("/" + SUBTREE + "/", 1)[1]
            if "lfs_sha256" not in expected[name]:
                metadata_payloads[name] = metadata_tar.extractfile(member).read()

files = []
with tarfile.open(archive, "r:gz") as data_tar:
    for member in data_tar.getmembers():
        if member.isdir():
            continue
        if not member.isfile() or "/" + SUBTREE + "/" not in member.name:
            raise ValueError("Unexpected archive member")
        name = member.name.split("/" + SUBTREE + "/", 1)[1]
        if name not in expected or ".." in Path(name).parts:
            raise ValueError("Unexpected source path")
        spec = expected[name]
        size = spec.get("lfs_bytes", spec["archive_bytes"])
        if member.size != size:
            raise ValueError(f"Author size mismatch: {name}")
        raw = data_tar.extractfile(member).read()
        digest = sha(raw)
        if "lfs_sha256" in spec:
            if digest != spec["lfs_sha256"]:
                raise ValueError(f"Author LFS SHA-256 mismatch: {name}")
        elif raw != metadata_payloads[name]:
            raise ValueError(f"Metadata snapshot mismatch: {name}")
        path = DEST / "data" / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        files.append({"local_path": str(path.relative_to(DEST)), "author_path": SUBTREE + "/" + name,
            "bytes": len(raw), "sha256": digest,
            "author_lfs_sha256": spec.get("lfs_sha256"),
            "verification": "author_lfs_sha256" if "lfs_sha256" in spec else "pinned_author_metadata_archive"})
assert len(files) == len(expected)
assert len({item["local_path"] for item in files}) == len(expected)
assert sum(item["bytes"] for item in files) == metadata["actual_total_bytes"]

sources = []
for source, filename in [("README.md", "AUTHOR_README.md"), ("LICENSE", "LICENSE")]:
    source_url = API + "/repository/files/" + quote(source, safe="") + "/raw?ref=" + COMMIT
    raw = get_small(source_url)
    (DEST / filename).write_bytes(raw)
    sources.append({"local_path": filename, "url": source_url, "bytes": len(raw), "sha256": sha(raw)})
(DEST / "CITATION.bib").write_text("""@article{horvath_sim2real_obj_2023,
  title = {Object Detection Using Sim2Real Domain Randomization for Robotic Applications},
  author = {Horváth, Dániel and Erdős, Gábor and Istenes, Zoltán and Horváth, Tomáš and Földi, Sándor},
  journal = {IEEE Transactions on Robotics}, volume = {39}, pages = {1225--1243},
  year = {2023}, doi = {10.1109/TRO.2022.3207619}
}
""")
manifest = {"schema_version": 1, "acquired_at": datetime.now(UTC).isoformat(),
    "dataset": "InO-10-190", "author_repository": PROJECT, "author_commit": COMMIT,
    "license": "MIT (author repository README and LICENSE)",
    "subtree": SUBTREE, "archive_url": url, "archive_file": archive.name,
    "archive_bytes": archive.stat().st_size, "archive_sha256": sha(archive.read_bytes()),
    "expanded_data_bytes": sum(item["bytes"] for item in files), "file_count": len(files),
    "lfs_verified_files": sum(item["author_lfs_sha256"] is not None for item in files),
    "no_model_inference": True, "no_image_truth_relabeling": True,
    "sources": sources, "files": sorted(files, key=lambda item: item["local_path"])}
(DEST / "SOURCE_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({key: value for key, value in manifest.items() if key not in {"sources", "files"}}, indent=2), flush=True)
