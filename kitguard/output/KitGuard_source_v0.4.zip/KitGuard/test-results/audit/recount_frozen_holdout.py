"""Independent read-only saved-run audit. No production metric functions or MLX.

Recompute metrics from observations and frozen truth, replay uploaded JPEG bytes,
and check frozen source/input identity. A call writes only its own audit JSON.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import statistics
from collections import Counter
from pathlib import Path

from PIL import Image, ImageOps

PARTS = ("bolt", "nut", "washer", "bracket")
ROOT = Path(__file__).resolve().parents[2]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    run = read(args.run / "run.json")
    raw = (args.run / "predictions.jsonl").read_bytes()
    rows = [json.loads(line) for line in raw.splitlines() if line.strip()]
    freeze_path = ROOT / "docs/RELEASE_EVALUATION_FREEZE.json"
    freeze = read(freeze_path)
    manifest = read(args.run / "manifest.json")
    cases = {case["id"]: case for case in manifest["cases"]}
    assert run["status"] == "completed"
    assert run["expected_cases"] == run["completed_cases"] == len(rows) == 48
    assert [row["case_id"] for row in rows] == freeze["manifest"]["holdout_ids"] == run["case_ids"]
    results = []
    for index, row in enumerate(rows, 1):
        case = cases[row["case_id"]]
        assert case["split"] == row["split"] == "holdout"
        assert case["ground_truth"] == row["ground_truth"]
        truth = case["ground_truth"]
        obs = row["observation"]
        counts = obs.get("observed") if isinstance(obs, dict) else None
        count_valid = isinstance(counts, dict) and set(counts) == set(PARTS) and all(
            value is None or (type(value) is int and 0 <= value <= 100) for value in counts.values()
        )
        valid = bool(count_valid and not row["error"])
        exact = bool(valid and counts == truth)
        actionable = bool(valid and all(value is not None for value in counts.values())
                          and obs["issues"] == [] and obs["action"]["kind"] == "none")
        assert row["counts_exact"] == exact
        assert row["actionable_counts"] == actionable
        object_consistent = None
        if valid and obs.get("object_evidence") is not None:
            evidence = obs["object_evidence"]
            listed = Counter(obj["part"] for obj in evidence["objects"])
            object_consistent = all(counts[p] is None or counts[p] == listed[p] for p in PARTS)
            assert object_consistent
            assert all(counts[p] is None for p in evidence["uncertain_parts"])
            assert evidence["coordinate_frame"] == "normalized_original"
        perturbation = dict(truth)
        for part in PARTS:
            if perturbation[part] < 3 and sum(perturbation.values()) < 12:
                perturbation[part] += 1
                break
            if perturbation[part] > 0 and sum(perturbation.values()) > 1:
                perturbation[part] -= 1
                break
        targets = {"matched": truth, "mismatched": perturbation, "nominal": case["nominal_requirements"]}
        tasks = {}
        for saved in row["tasks"]:
            target = targets[saved["kind"]]
            assert target == saved["requirements"]
            ready = bool(actionable and counts == target)
            false_ready = bool(ready and truth != target)
            correct_adjustment = bool(actionable and not ready and exact)
            assert false_ready == saved["false_ready"]
            assert ready == (saved["decision"] == "ready")
            assert correct_adjustment == saved["correct_adjustment"]
            tasks[saved["kind"]] = {"ready": ready, "false_ready": false_ready,
                                     "correct_adjustment": correct_adjustment,
                                     "truth_matches_order": truth == target}
        original = ROOT / "datasets" / case["image"]
        upload = args.run / "normalized_inputs" / f"{index:03d}.jpg"
        assert sha(original) == case["sha256"] == row["sha256"]
        assert sha(upload) == row["model_input_sha256"]
        with Image.open(original) as image:
            image.load()
            clean = ImageOps.exif_transpose(image).convert("RGB")
            clean.thumbnail((2048, 2048), Image.Resampling.LANCZOS)
            stream = io.BytesIO()
            clean.save(stream, format="JPEG", quality=95)
        assert hashlib.sha256(stream.getvalue()).hexdigest() == sha(upload)
        with Image.open(upload) as image:
            clean = ImageOps.exif_transpose(image).convert("RGB")
            clean.thumbnail((1536, 1536), Image.Resampling.LANCZOS)
            stream = io.BytesIO()
            clean.save(stream, format="PNG")
        results.append({"case_id": case["id"], "subgroup": case["subgroup"], "exact": exact,
                        "actionable": actionable, "error": bool(row["error"]), "tasks": tasks,
                        "object_list_consistent": object_consistent,
                        "uploaded_sha256": sha(upload),
                        "reconstructed_prepared_png_sha256": hashlib.sha256(stream.getvalue()).hexdigest()})
    metrics = {
        "count_exact": [sum(row["exact"] for row in results), len(results)],
        "actionable_coverage": [sum(row["actionable"] for row in results), len(results)],
        "wrong_actionable_count": [sum(row["actionable"] and not row["exact"] for row in results),
                                   sum(row["actionable"] for row in results)],
        "errors": [sum(row["error"] for row in results), len(results)],
        "matched_order_ready": [sum(row["tasks"]["matched"]["ready"] for row in results), len(results)],
        "mismatched_order_false_ready": [sum(row["tasks"]["mismatched"]["false_ready"] for row in results), len(results)],
        "mismatched_order_correct_adjustment": [sum(row["tasks"]["mismatched"]["correct_adjustment"] for row in results), len(results)],
    }
    summary = run["summary"]
    checks = {name: pair == [summary[name]["numerator"], summary[name]["denominator"]]
              for name, pair in metrics.items()}
    groups = {}
    for label in sorted({row["subgroup"] for row in results}):
        group = [row for row in results if row["subgroup"] == label]
        groups[label] = {"n": len(group), "exact": sum(row["exact"] for row in group),
                         "actionable": sum(row["actionable"] for row in group),
                         "wrong_actionable": sum(row["actionable"] and not row["exact"] for row in group)}
        saved = summary["subgroups"][label]
        checks[label] = (groups[label]["n"] == saved["images"]
                         and groups[label]["exact"] == saved["count_exact"]["numerator"]
                         and groups[label]["actionable"] == saved["actionable_coverage"]["numerator"]
                         and groups[label]["wrong_actionable"] == saved["wrong_actionable_count"]["numerator"])
    normal = [row for row in results if row["tasks"]["nominal"]["truth_matches_order"]]
    anomalies = [row for row in results if not row["tasks"]["nominal"]["truth_matches_order"]]
    nominal = {"matching_images_ready": [sum(row["tasks"]["nominal"]["ready"] for row in normal), len(normal)],
               "quantity_anomalies_false_ready": [sum(row["tasks"]["nominal"]["false_ready"] for row in anomalies), len(anomalies)],
               "quantity_anomalies_correct_adjustment": [sum(row["tasks"]["nominal"]["correct_adjustment"] for row in anomalies), len(anomalies)]}
    for name, pair in nominal.items():
        saved = summary["nominal_order"][name]
        checks["nominal_" + name] = pair == [saved["numerator"], saved["denominator"]]
    latency = {"median": statistics.median(row["latency_ms"] for row in rows),
               "maximum": max(row["latency_ms"] for row in rows)}
    checks["latency"] = latency == summary["latency_ms"]
    source_mismatches = [name for name, digest in run["source_hashes"].items()
                         if sha(args.run / "source_snapshot" / name) != digest]
    freeze_source_mismatches = [name for name, digest in run["source_hashes"].items()
                               if digest != freeze["source_sha256"].get("scripts/" + name if name == "run_benchmark.py" else "kitguard/" + name)]
    model = run["model_before"]
    protocol = hashlib.sha256(json.dumps({"sources": model["observer_source_hashes"],
                              "mode": model["observation_mode"], "image_max_side": model["image_max_side"],
                              "max_tokens": 900 if model["observation_mode"] == "spatial_inventory" else 450}, sort_keys=True).encode()).hexdigest()
    last = run["model_after"]["last_observation_attempt"]["passes"][-1]["input_sha256"]
    assert last == results[-1]["reconstructed_prepared_png_sha256"]
    assert all(checks.values()) and not source_mismatches and not freeze_source_mismatches
    assert protocol == model["observer_protocol_sha256"]
    output = {"scope": "Independent saved holdout recalculation, no production scorer imports, no model rerun",
              "run": str(args.run), "status": run["status"], "source_changed_during_run": run["source_changed_during_run"],
              "metrics": metrics, "subgroups": groups, "nominal": nominal, "latency_ms": latency,
              "all_summary_checks": checks, "source_snapshot_mismatches": source_mismatches,
              "run_sources_different_from_freeze": freeze_source_mismatches,
              "manifest_sha256_matches_freeze": sha(args.run / "manifest.json") == freeze["manifest"]["sha256"],
              "protocol_sha256_recomputed_matches": True, "all_original_and_uploaded_hashes_verified": True,
              "all_upload_jpegs_independently_replayed": True, "last_actual_prepared_png_sha256_verified": True,
              "prepared_png_record_limit": "Other processed PNG hashes are reconstructions; only last pass digest is retained in run metadata",
              "rows": results, "files": {"run_json_sha256": sha(args.run / "run.json"),
              "predictions_jsonl_sha256": hashlib.sha256(raw).hexdigest(), "freeze_sha256": sha(freeze_path),
              "auditor_script_sha256": sha(Path(__file__))}}
    args.output.write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"metrics": metrics, "subgroups": groups, "nominal": nominal, "latency_ms": latency,
                     "summary_matches": all(checks.values()), "source_mismatches": source_mismatches}, indent=2))


if __name__ == "__main__":
    main()
