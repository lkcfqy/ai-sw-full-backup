"""One bounded real 27B MLX integration run, isolated storage, no inference substitutions."""
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
sys.path.insert(0, str(ROOT))
plan = json.loads((BASE / "PLAN_FREEZE.json").read_text())
for name, digest in plan["source_sha256"].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
from kitguard.app import create_app  # noqa: E402
from kitguard.vision import LocalVision  # noqa: E402
import uvicorn  # noqa: E402

engine = LocalVision(model_path=Path(plan["model_path"]), observation_mode="spatial_guarded", image_max_side=1536)
status = engine.status()
assert status["available"] and not status["loaded"]
assert status["repo_id"] == plan["repo_id"] and status["revision"] == plan["model_revision"]
(BASE / "model-before.json").write_text(json.dumps(status, ensure_ascii=False, indent=2))
app = create_app(data_dir=BASE / "data", analyzer=engine, inference_timeout=300, demo_dataset_root=ROOT / "datasets")
uvicorn.run(app, host="127.0.0.1", port=8787, access_log=True)
