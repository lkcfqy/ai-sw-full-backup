"""Freeze sources and author truth before any real-model request."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import socket
import subprocess
from datetime import datetime, UTC
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
import sys
sys.path.insert(0, str(ROOT))
from kitguard.public_demo_catalog import CATALOG  # noqa: E402

assert not (BASE / "PLAN_FREEZE.json").exists()
with socket.socket() as connection:
    connection.bind(("127.0.0.1", 8787))
health = json.load(urlopen("http://127.0.0.1:8765/api/health"))
orders = json.load(urlopen("http://127.0.0.1:8765/api/orders"))["orders"]
assert health["model"]["loaded"] is False
assert not any(order.get("active_inspection") for order in orders)
processes = subprocess.check_output(["ps", "-axo", "pid,args"], text=True)
conflicts = [line for line in processes.splitlines()
             if re.match(r"\s*\d+\s+\S*python\S*\s", line, re.I)
             and re.search(r"(?:run_benchmark|real-api-v03|field-study-real-v04/server)", line)]
assert not conflicts, conflicts
(BASE / "preflight.json").write_text(json.dumps({"main_health": health,
    "main_active_inspection_count": sum(bool(order.get("active_inspection")) for order in orders),
    "main_health_inference_busy_present": "inference_busy" in health,
    "note": "Old main 0.3 process has no explicit inference_busy field. It is unloaded, no order has active inspection, and no benchmark/real-inference Python process is running. Root reserves GPU for this run.",
    "conflicting_processes": conflicts, "port_8787_free": True}, ensure_ascii=False, indent=2))
manifest_paths = [ROOT / "datasets/manifests/mvtec_loco_screw_bag/benchmark_v2.json",
                  ROOT / "datasets/manifests/v0.3/CANONICAL_NEW_SOURCE_BENCHMARK_V1.json"]
records = {case["id"]: (case, path) for path in manifest_paths for case in json.loads(path.read_text())["cases"]}
cases = []
for spec in CATALOG:
    case, manifest = records[spec["source_case_id"]]
    image = ROOT / "datasets" / spec["image"]
    assert hashlib.sha256(image.read_bytes()).hexdigest() == spec["source_sha256"] == case["sha256"]
    assert case["split"] == "development"
    cases.append({"sample_id": spec["sample_id"], "source_case_id": spec["source_case_id"],
        "image": str(image.relative_to(ROOT)), "image_sha256": spec["source_sha256"], "truth": case["ground_truth"],
        "truth_basis": case["ground_truth_basis"], "truth_manifest": str(manifest.relative_to(ROOT))})
sources = sorted((ROOT / "kitguard").glob("*.py")) + sorted((ROOT / "kitguard/static").glob("*"))
sources += [BASE / name for name in ("server.py", "run.py", "prepare.py")]
hashes = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources if path.is_file()}
for path in sources:
    if path.is_file():
        target = BASE / "source_snapshot" / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
plan = {"frozen_at": datetime.now(UTC).isoformat(), "planned_inspections": 3, "retry_inference": False,
    "base_url": "http://127.0.0.1:8787", "model_path": "/Users/lkc/Downloads/AI-Models/Qwen3.6-27B-4bit",
    "repo_id": "mlx-community/Qwen3.6-27B-4bit", "model_revision": "c000ac2c2057d94be3fa931000c31723aac53282",
    "observation_mode": "spatial_guarded", "image_max_side": 1536, "source_sha256": hashes,
    "manifest_sha256": {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in manifest_paths},
    "cases": cases, "scope": "Three existing public development examples, scripted author-truth inputs, no human baseline or field experiment, not new independent accuracy samples. Exactly one actual inspect request per case, all errors preserved, no retries or best-of selection."}
(BASE / "PLAN_FREEZE.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2))
print(json.dumps({"frozen_at": plan["frozen_at"], "cases": cases}, ensure_ascii=False))
