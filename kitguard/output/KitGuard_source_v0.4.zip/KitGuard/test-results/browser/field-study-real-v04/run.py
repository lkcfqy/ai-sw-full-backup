"""Exactly three existing public-development inspect requests, never retry inference."""
import hashlib
import json
import time
import traceback
from datetime import UTC, datetime
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
URL = "http://127.0.0.1:8787"
plan = json.loads((BASE / "PLAN_FREEZE.json").read_text())
http_dir = BASE / "http"
http_dir.mkdir(exist_ok=False)
sequence = []
result = {"status": "running", "scope": plan["scope"], "planned_inspections": 3, "attempted_inspections": 0,
          "cases": [], "errors": [], "started_at": datetime.now(UTC).isoformat()}
study = None


def save():
    (BASE / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2))


def request(name, path, body=None, binary=False):
    index = len(sequence) + 1
    started = time.monotonic()
    request_record = {"name": name, "path": path, "method": "GET" if body is None else "POST", "body": body,
                      "started_at": datetime.now(UTC).isoformat()}
    target = http_dir / f"{index:03d}-{name}"
    target.with_suffix(".request.json").write_text(json.dumps(request_record, ensure_ascii=False, indent=2))
    sequence.append(request_record)
    status = None
    data = b""
    try:
        req = Request(URL + path, data=None if body is None else json.dumps(body).encode(),
                      headers={} if body is None else {"Content-Type": "application/json"})
        with urlopen(req, timeout=360) as response:
            status, data = response.status, response.read()
            request_record["response_headers"] = dict(response.headers)
    except HTTPError as exc:
        status, data = exc.code, exc.read()
    finally:
        request_record.update({"status": status, "elapsed_ms": round((time.monotonic() - started) * 1000),
                               "response_sha256": hashlib.sha256(data).hexdigest()})
        target.with_suffix(".response" if binary else ".response.json").write_bytes(data)
        target.with_suffix(".receipt.json").write_text(json.dumps(request_record, ensure_ascii=False, indent=2))
        (BASE / "http-index.json").write_text(json.dumps(sequence, ensure_ascii=False, indent=2))
    if status is None or status >= 400:
        raise RuntimeError(f"HTTP {status}: {data.decode(errors='replace')[:1500]}")
    return data if binary else json.loads(data)


try:
    health = request("health-before", "/api/health")
    assert health["model"]["loaded"] is False
    assert health["model"]["observation_mode"] == "spatial_guarded"
    assert health["model"]["image_max_side"] == 1536
    source_note = "自动输入作者真值，非真人人工基线、非现场实验、已用开发样例，不增加新准确率样本。Scripted author-truth replay; no human timing claim."
    study = request("create-study", "/api/studies", {"title": "PUBLIC DEVELOPMENT REPLAY · real MLX integration only",
                    "source_kind": "public_replay", "planned_cases": 3, "participant_code": "scripted_replay", "note": source_note})["study"]
    result["study_id"] = study["id"]
    for case in plan["cases"]:
        uploaded = request("create-" + case["sample_id"], f'/api/public-demos/{case["sample_id"]}/orders', {})
        order, photo = uploaded["order"], uploaded["photo"]
        study = request("register-" + case["sample_id"], f'/api/studies/{study["id"]}/cases',
                        {"label": case["sample_id"], "order_id": order["id"], "expected_revision": order["revision"],
                         "photo_id": photo["id"], "truth": case["truth"], "truth_repeat": case["truth"],
                         "confirmed_independent": True, "source_note": source_note + " Source: " + case["source_case_id"]})["study"]
    study = request("freeze-study", f'/api/studies/{study["id"]}/freeze', {"confirmed": True})["study"]
    result["freeze_protocol_sha256"] = study["protocol_sha256"]
    result["frozen_at"] = study["frozen_at"]
    save()
    for spec, case in zip(plan["cases"], study["cases"], strict=True):
        case_result = {"sample_id": spec["sample_id"], "case_id": case["id"], "order_id": case["order_id"], "status": "running"}
        result["cases"].append(case_result)
        ai_trial = None
        try:
            manual = request("manual-start-" + spec["sample_id"], f'/api/studies/{study["id"]}/cases/{case["id"]}/start', {"method": "manual"})["trial"]
            request("manual-scripted-" + spec["sample_id"], f'/api/studies/{study["id"]}/trials/{manual["id"]}/finish',
                    {"outcome": "completed", "manual_counts": spec["truth"], "note": "SCRIPTED AUTHOR COUNTS, NOT A HUMAN TIMING BASELINE"})
            ai_trial = request("ai-start-" + spec["sample_id"], f'/api/studies/{study["id"]}/cases/{case["id"]}/start', {"method": "kitguard"})["trial"]
            result["attempted_inspections"] += 1
            save()
            observed = request("inspect-" + spec["sample_id"], f'/api/orders/{case["order_id"]}/inspect',
                               {"photo_id": case["photo_id"], "expected_revision": case["revision"]})
            check = observed["check"]
            assert check["backend"] == "mlx", "No injected/fallback check permitted"
            request("ai-finish-" + spec["sample_id"], f'/api/studies/{study["id"]}/trials/{ai_trial["id"]}/finish',
                    {"outcome": "completed", "check_id": check["id"]})
            case_result.update({"status": "completed", "check": check})
        except Exception as exc:
            case_result.update({"status": "failed", "error": str(exc)})
            result["errors"].append({"sample_id": spec["sample_id"], "error": str(exc)})
            if ai_trial:
                request("ai-failed-" + spec["sample_id"], f'/api/studies/{study["id"]}/trials/{ai_trial["id"]}/finish',
                        {"outcome": "failed", "note": ("REAL INTEGRATION REQUEST FAILED; NO RETRY: " + str(exc))[:1000]})
        save()
        print(json.dumps({"sample": spec["sample_id"], "status": case_result["status"], "decision": case_result.get("check", {}).get("decision")}), flush=True)
    study = request("close-study", f'/api/studies/{study["id"]}/close', {"confirmed": True})["study"]
    result["study"] = study
    for label, endpoint, filename in [("json", "export", "public-replay.json"), ("html", "report.html", "public-replay.html"),
                                     ("zip", "evidence.zip", "public-replay-evidence.zip")]:
        (BASE / filename).write_bytes(request("export-" + label, f'/api/studies/{study["id"]}/{endpoint}', binary=True))
    result["model_after"] = request("health-after", "/api/health")["model"]
    result["status"] = "completed" if not result["errors"] else "completed_with_errors"
except Exception as exc:
    result["status"] = "execution_failed"
    result["errors"].append({"error": str(exc), "traceback": traceback.format_exc()})
    raise
finally:
    result["finished_at"] = datetime.now(UTC).isoformat()
    result["source_sha256_after"] = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in plan["source_sha256"]}
    result["source_changed"] = result["source_sha256_after"] != plan["source_sha256"]
    save()
