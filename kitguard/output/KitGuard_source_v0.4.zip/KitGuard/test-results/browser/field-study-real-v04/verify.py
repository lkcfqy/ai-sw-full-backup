"""Independent byte/schema audit of the completed real API study; no inference."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
run = json.loads((BASE / "result.json").read_text())
plan = json.loads((BASE / "PLAN_FREEZE.json").read_text())
http = json.loads((BASE / "http-index.json").read_text())
checks = []
assert run["status"] in {"completed", "completed_with_errors"}
assert run["planned_inspections"] == run["attempted_inspections"] == 3
calls = [record for record in http if record["path"].endswith("/inspect")]
assert len(calls) == 3 and len({record["path"] for record in calls}) == 3
checks.append("Exactly three real HTTP inspect requests, one per fixed public-development sample")
assert not any(record["path"].endswith("/complete") for record in http)
checks.append("No physical-completion or retry endpoint invoked")
assert not run["source_changed"]
for name, digest in plan["source_sha256"].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
    assert hashlib.sha256((BASE / "source_snapshot" / name).read_bytes()).hexdigest() == digest
checks.append("All frozen source files equal before/after hashes and archived snapshots")
for name, digest in plan["manifest_sha256"].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
checks.append("Author-truth manifest hashes unchanged")
export = json.loads((BASE / "public-replay.json").read_text())
study = export["study"]
assert study["status"] == "closed" and study["source_kind"] == "public_replay"
assert study["participant_code"] == "scripted_replay" and len(study["cases"]) == 3
assert "非真人人工基线" in study["note"]
checks.append("Closed public replay labels scripted author inputs, not a human or field baseline")
summary = []
for spec, case in zip(plan["cases"], study["cases"], strict=True):
    assert case["label"] == spec["sample_id"] and case["truth"] == spec["truth"]
    assert "不增加新准确率样本" in case["source_note"]
    manual, trial = case["trials"]["manual"], case["trials"]["kitguard"]
    assert manual["manual_counts"] == spec["truth"] and "NOT A HUMAN TIMING BASELINE" in manual["note"]
    assert trial["status"] in {"completed", "failed", "abandoned", "interrupted"}
    if trial["status"] == "completed":
        check = trial["check"]
        assert check["backend"] == "mlx"
        assert check["photo_sha256"] == case["photo_sha256"]
        assert check["photo_id"] == case["photo_id"] and check["revision"] == case["revision"]
        assert check["runtime_identity"]["repo_id"] == plan["repo_id"]
        assert check["runtime_identity"]["revision"] == plan["model_revision"]
        assert check["runtime_identity"]["observation_mode"] == "spatial_guarded"
        summary.append({"sample": spec["sample_id"], "status": trial["status"], "decision": check["decision"],
                        "observed": check["observed"], "truth": case["truth"], "latency_ms": check["latency_ms"],
                        "trial_elapsed_ms": trial["elapsed_ms"]})
    else:
        summary.append({"sample": spec["sample_id"], "status": trial["status"], "note": trial["note"]})
checks.append("Every completed trial binds the actual pinned MLX check to case photo/version; all failures retained")
zip_path = BASE / "public-replay-evidence.zip"
with ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    assert len(names) == len(set(names))
    assert all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in names)
    manifest = json.loads(archive.read("MANIFEST.json"))
    assert manifest["study_id"] == study["id"] and manifest["source_kind"] == "public_replay"
    assert set(names) == {entry["path"] for entry in manifest["files"]} | {"MANIFEST.json"}
    for entry in manifest["files"]:
        raw = archive.read(entry["path"])
        assert len(raw) == entry["bytes"] and hashlib.sha256(raw).hexdigest() == entry["sha256"]
    assert json.loads(archive.read("STUDY.json")) == export
    assert len(manifest["photo_bindings"]) == 3
    for binding, case in zip(manifest["photo_bindings"], study["cases"], strict=True):
        assert binding["case_id"] == case["id"] and binding["photo_id"] == case["photo_id"]
        assert binding["sha256"] == case["photo_sha256"]
        assert hashlib.sha256(archive.read(binding["archive_path"])).hexdigest() == case["photo_sha256"]
    output = BASE / "evidence-extracted"
    assert not output.exists()
    archive.extractall(output)
checks.append("ZIP CRC, complete manifest hashes, exact STUDY JSON and three normalized photos all verify")
receipt = {"status": "passed", "assertions": len(checks), "checks": checks, "cases": summary,
           "inspect_http_elapsed_ms": [record["elapsed_ms"] for record in calls],
           "ai_metrics": study["report"]["methods"]["kitguard"],
           "manual_metrics_interpretation": "Ignore as human performance: counts and timing are automated author-truth input only.",
           "source_changed": False, "scope": plan["scope"],
           "artifact_sha256": {name: hashlib.sha256((BASE / name).read_bytes()).hexdigest() for name in
                               ["PLAN_FREEZE.json", "result.json", "public-replay.json", "public-replay.html", "public-replay-evidence.zip"]}}
(BASE / "verification.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
print(json.dumps(receipt, ensure_ascii=False))
