"""Counterexample-only engineering server. Explicit FakeAnalyzer, no MLX/GPU."""
from pathlib import Path
import socket
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]
from conftest import FakeAnalyzer  # noqa: E402
from kitguard.app import create_app  # noqa: E402
from PIL import Image, ImageDraw  # noqa: E402
import uvicorn  # noqa: E402

with socket.socket() as connection:
    connection.bind(("127.0.0.1", 8789))
image = Image.new("RGB", (640, 480), "#d5e4d7")
ImageDraw.Draw(image).text((40, 80), "ENGINEERING COUNTEREXAMPLE: MANUAL REVIEW", fill="black")
image.save(BASE / "fixture.png")
analyzer = FakeAnalyzer()
analyzer.result = analyzer.observation({"bolt": None, "nut": None, "washer": None, "bracket": None}, action="manual")
app = create_app(data_dir=BASE / "data", analyzer=analyzer)
uvicorn.run(app, host="127.0.0.1", port=8789)
