"""Isolated engineering-only API; no GPU, model files, public data or production DB."""
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]
from conftest import FakeAnalyzer  # noqa: E402
from kitguard.app import create_app  # noqa: E402
from PIL import Image, ImageDraw  # noqa: E402

BASE = Path(__file__).resolve().parent


class FieldFixtureAnalyzer(FakeAnalyzer):
    def observe(self, image_path, requirements, references):
        time.sleep(0.25)
        if requirements["bolt"] == 3:
            raise RuntimeError("ENGINEERING_FIXTURE intentional observer failure")
        counts = dict(requirements)
        if requirements["nut"] == 1:
            counts["nut"] = None
            return self.observation(counts, action="recapture", issues=["ENGINEERING_FIXTURE uncertainty"])
        return self.observation(counts)


for number in range(1, 8):
    image = Image.new("RGB", (640, 480), (234, 241, 233))
    draw = ImageDraw.Draw(image)
    draw.rectangle((40 + number * 11, 65, 220 + number * 11, 250), fill=(40, 80, 110))
    draw.text((24, 330), f"ENGINEERING FIXTURE {number} - NO REAL PARTS", fill=(20, 40, 30))
    image.save(BASE / f"fixture-{number}.png")

app = create_app(data_dir=BASE / "data", analyzer=FieldFixtureAnalyzer())

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8786)
