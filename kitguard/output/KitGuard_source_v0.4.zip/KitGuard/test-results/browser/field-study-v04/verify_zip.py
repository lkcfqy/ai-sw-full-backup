"""Verify a downloaded engineering study ZIP and extract only safe matching entries."""
import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZipFile

archive_path, output = map(Path, sys.argv[1:3])
checks = []
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    checks.append("ZIP CRC verifies every entry")
    names = archive.namelist()
    assert len(names) == len(set(names))
    assert all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in names)
    checks.append("No duplicate or unsafe member paths")
    manifest = json.loads(archive.read("MANIFEST.json"))
    expected = {entry["path"]: entry for entry in manifest["files"]}
    assert set(names) == set(expected) | {"MANIFEST.json"}
    checks.append("Manifest enumerates all members except itself")
    for name, entry in expected.items():
        raw = archive.read(name)
        assert len(raw) == entry["bytes"]
        assert hashlib.sha256(raw).hexdigest() == entry["sha256"]
    checks.append(f"All {len(expected)} manifest files match SHA-256 and byte length")
    payload = json.loads(archive.read("STUDY.json"))
    study = payload["study"]
    assert study["status"] == "closed" and study["source_kind"] == "engineering_fixture"
    assert study["id"] == manifest["study_id"]
    checks.append("Closed study ID and explicit engineering source match")
    cases = {case["id"]: case for case in study["cases"]}
    for binding in manifest["photo_bindings"]:
        raw = archive.read(binding["archive_path"])
        case = cases[binding["case_id"]]
        assert hashlib.sha256(raw).hexdigest() == binding["sha256"]
        if binding["role"] == "target":
            assert binding["photo_id"] == case["photo_id"]
            assert binding["sha256"] == case["photo_sha256"]
        else:
            part = binding["role"].removeprefix("reference:")
            assert binding["photo_id"] == case["reference_ids"][part]
            assert binding["sha256"] == case["reference_sha256"][part]
    checks.append("All archive photos bind to registered case hashes and IDs")
    assert len(manifest["photo_bindings"]) == 6
    assert all(binding["role"] == "target" for binding in manifest["photo_bindings"])
    checks.append("Six actual normalized target JPEGs included; this fixture has no reference images")
    assert all(name in names for name in ["OPEN_ME.html", "PHOTOS.html", "REPORT.html", "STUDY.json", "MANIFEST.json"])
    checks.append("All five portable entry/report/data pages present")
    if output.exists():
        raise RuntimeError("Refuse to overwrite an existing evidence extraction")
    output.mkdir()
    for name in names:
        destination = output / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(archive.read(name))
receipt = {"status": "passed", "checks": checks, "archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
           "archive_bytes": archive_path.stat().st_size, "study_id": study["id"], "files": len(names),
           "photo_bindings": len(manifest["photo_bindings"]), "scope": "Read-only export of existing closed engineering fixtures. No real model/user/field validation."}
print(json.dumps(receipt))
