# KitGuard 0.9.0.dev3 · DEVELOPMENT PREVIEW / 개발 미리보기 / 开发预览

This is a source component, not a complete contest submission or accuracy/safety
certification. Consult the accompanying delivery manifest. Version bytes are read
from this source; fixed ZIP timestamps are reproducibility metadata, not a release date.

## Run / 실행 / 运行

On Apple Silicon macOS, with uv installed:

```sh
bash scripts/setup.sh
.venv/bin/python scripts/download_candidate_model.py
bash scripts/run_competition.sh
```

Model weights and Python dependencies are separate downloads. The downloader uses
the repository's pinned model revision/hashes. An already verified installation may
set KITGUARD_MODEL_PATH instead. Open http://127.0.0.1:8765/?new=photo-document
for a local JPEG/PNG/WebP photo with a required source statement, or
http://127.0.0.1:8765/static/demo.html for the three included development examples.
Follow docs/v0.8/PHOTO_DOCUMENT_GUIDE_KO_ZH.md. A URL is a statement, not a download.
User-declared source/license remain unverified. Digital review is not physical
completion; order revision requires explicit same-photo reuse and a new inspection.

The UI starts without weights. Actual inference requires the separate local model
and adequate memory. Windows/Linux inference and clean-machine installation are
not established by the package smoke test. That test uses existing dependencies,
synthetic pixels and HTTP contracts only; no MLX/model call or human participation.

## Included demo photographs

| ID | Package path | Source |
| --- | --- | --- |
| bag-revision | datasets/raw/mvtec_loco_ad/screw_bag/train/good/016.png | https://www.mvtec.com/research-teaching/datasets/mvtec-loco-ad |
| small-part | datasets/derived/v0.3/screws_views/v03-screws-screws_222-56eea59f64ca.png | https://www.mvtec.com/research-teaching/datasets/mvtec-screws |
| mixed-screws | datasets/derived/v0.3/screws_views/v03-screws-screws_344-8d389e404b12.png | https://www.mvtec.com/research-teaching/datasets/mvtec-screws |

Retain MVTec attribution and CC BY-NC-SA 4.0 terms in third_party/datasets/.
Two Screws samples are integer crops with recorded source and annotation hashes;
SOURCE_MANIFEST.json includes crop provenance. The three images are previously
exposed development examples, not new holdout evidence or user feedback. No new
reference crops, FOD/MANTA photos or original training/evaluation collections are bundled.

## External research evidence

EXTERNAL_ARTIFACT_INDEX.json records explicitly omitted research metadata and
historical source text with project-relative path, byte size, SHA-256 and purpose.
Nested frozen source snapshots and normalized evaluation images are external;
small freeze metadata may remain as a dependency map. Excluded evaluation/training
images are not read; the three listed demo images are read and hashed. Full run/raw
outputs, weights and exposure records are also external.
Restoring the correct hashes is required for research replay. This ZIP alone cannot
reproduce all reported experiments. Data-dependent tests may need those artifacts.
Repository-relative links to test-results/evaluation-runs may be absent here; use
the accompanying delivery evidence index rather than interpreting them as packaged.

Private SQLite databases, user uploads, runtime directories and credentials are not
included. Unknown oversized source files fail; no file is dropped because of size.
Every bundled file is listed with byte size and SHA in SOURCE_MANIFEST.json.

## Rebuild to a new path

```sh
.venv/bin/python -m scripts.v09.package_source \
  --output /new/path/kitguard-source-preview.zip --verify-runtime
```

The ZIP and its .manifest.json, .sha256 and .verification.json sidecars must be new.
The same bytes and Python/zlib toolchain yield the same archive. Integrity hashes
are not identity signatures, authorization, or proof of physical capture.

## v0.9 review workflow

See docs/v0.9/DEMO_AND_HANDOFF_ZH.md and RELEASE_NOTES.md. The independent point review preserves original AI, expires on changed evidence/opinions, and exports both count tables and original-photo point positions.
Public-photo digital tasks: open /static/digital-trials.html. Six fixed tasks per participant, manual/KitGuard order alternation, server timing including inference, current-version checks, and full planned denominators. Engineering rehearsals are never human results.
Autonomous mission: open /static/autonomy.html. One operator can run all three public-photo scenarios; real local inference, conditional routing, declared R2 replay, persistent execution and evidence ZIP. No participants needed.
